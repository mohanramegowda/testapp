import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { SpsUtility } from '../common/SpsUtility';
import { RolesAndActionsService } from 'app/common/roles-actions.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  canCreate: boolean = false;
  canInvoice: boolean = false;
  loginUserDetails: {};
  role: string = '';
  loginUserName;

  constructor(private router: Router, private rolesAndActionsService: RolesAndActionsService) {
    this.loginUserDetails = SpsUtility.userDetails;
    this.role = SpsUtility.userDetails.role;
  }



  ngOnInit() {
    this.loginUserName = SpsUtility.userDetails.usrFstNm;
    if (this.rolesAndActionsService.authorisationStatus) {
      this.rolesAndActionsService.authorisationStatus.subscribe(() => {
        this.canCreate = this.rolesAndActionsService.CanViewInCreate();
        this.canInvoice = this.rolesAndActionsService.CanViewOrderInInvoice();
      })
    }

    $(document).on('user-obj', () => {
      this.loginUserName = SpsUtility.userDetails.usrFstNm;
    });

  }
  addQuote() {
    this.router.navigateByUrl('/create');
  }

  addInvoice() {
    this.router.navigateByUrl('/invoice');
  }

}
