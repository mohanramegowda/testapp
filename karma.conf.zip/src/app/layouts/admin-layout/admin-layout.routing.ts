import { Routes } from '@angular/router';

import { DashboardComponent } from '../../dashboard/dashboard.component';
import { ShipmentdetailsComponent } from '../../shipment/shipmentdetails.component';
import { SPSCustomerComponent } from '../../sps-customer/sps-customer.component';
// import { ActivityViewsComponent } from '../../activity-views/activity-views.component';
import { ManageComponent } from '../../manage/manage.component'
import { InvoicingComponent } from '../../invoicing/invoicing.component';
// import { TableListComponent } from '../../table-list/table-list.component';
// import { ActivityViewComponent } from '../../activity-view/activity-view.component';
// import { GenerateTariffComponent } from 'app/generate-tariff/generate-tariff.component';
// import { SneakPreviewComponent } from 'app/sneak-preview/sneak-preview.component';
import { from } from 'rxjs';
import { IsAuthorized } from 'app/common/guards/auth-guard';

export const AdminLayoutRoutes: Routes = [
  // {
  //   path: '',
  //   loadChildren: '../../dashboard/dashboard.module#DashboardModule'
  // },
  // {
  //   path: 'create',
  //   loadChildren: '../../dashboard/dashboard.module#DashboardModule'
  // },


    { path: '', component: DashboardComponent, canActivate: [IsAuthorized]},
    { path: 'create', component: DashboardComponent, canActivate: [IsAuthorized],
      children: [ ]
        },
    { path: 'manage', component: ManageComponent, canActivate: [IsAuthorized]},
    { path: 'shipment', component: ShipmentdetailsComponent },
    { path: 'managequote', component: SPSCustomerComponent },
    // { path: 'activity', component: ActivityViewsComponent },
    // { path: 'booking', component: BookingComponent },
    { path: 'invoice', component: InvoicingComponent, canActivate: [IsAuthorized]},
    // { path: 'generate', component: GenerateTariffComponent },
    // { path: 'list/:profileConfig', component: TableListComponent },
    // { path: 'list', component: TableListComponent }
];
