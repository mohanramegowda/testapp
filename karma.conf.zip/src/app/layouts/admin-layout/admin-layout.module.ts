import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AdminLayoutRoutes } from './admin-layout.routing';
import { DashboardComponent } from '../../dashboard/dashboard.component';
// import { TableListComponent } from '../../table-list/table-list.component';
import { MaterialModule } from '../../material.module';
import { ComponentsModule } from 'app/components/components.module';
import { PendingInterceptorModule } from 'app/components/loading-indicator/pending-interceptor.module';
// import { TableListDetailModule } from '../../table-list/table-list-detail/table-list-detail.module';
// import { ActivityViewModule } from '../../activity-views/activity-view.module';
// import { GenerateTariffModule } from 'app/generate-tariff/generate-tariff-module';
// import { SneakPreviewModule } from 'app/sneak-preview/sneak-preview.module';
// import { TableListService } from 'app/table-list/table-list.service';
// import { DefineCustomerModule } from 'app/define-customer/define-customer.module';
import { SPSCustomerModule } from 'app/sps-customer/sps-customer.module';
import { SPSSCustomerModule } from 'app/shipment/spss-customer.module';
import { InvoiceModule } from 'app/invoicing/invoice.module'
import { ManageModule } from 'app/manage/manage.module'
@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(AdminLayoutRoutes),
    FormsModule,
    MaterialModule,
    PendingInterceptorModule,
    ComponentsModule,
    // TableListDetailModule,
    ReactiveFormsModule,
    // ActivityViewModule,
    // GenerateTariffModule,
    // SneakPreviewModule,
    // DefineCustomerModule,
    SPSCustomerModule,
    SPSSCustomerModule,
    InvoiceModule,
    ManageModule
  ],
  declarations: [
    DashboardComponent,
    // TableListComponent    
  ],
  providers : [
    // TableListService
  ]
})

export class AdminLayoutModule { }
