export class STConfig {
    static config = {
        'title': 'Standard Tariff Settings',
        'subTitle': 'Configure Standard Tariff',
        'advancedFilterTitle': 'Filter Standard Tariff',
        'isInlineEdit': true,
        'filters': [{
                'field': 'CTRY_NM',
                'displayName': 'Country',
                'defaultValue': '',
                'type': 'dropdown',
                'values': [],
                'hierarchyRoot': true
            },
            {
                'field': 'CTRY_CD_NM',
                'displayName': 'Country Code',
                'defaultValue': '',
                'type': 'input',
                'disabled': true,
                'inputType': 'text',
                'hierarchyParent': 'CTRY_NM'
            },
            {
                'field': 'CURR_CD_NM',
                'displayName': 'Currency',
                'defaultValue': '',
                'type': 'input',
                'disabled': true,
                'inputType': 'text',
                'hierarchyParent': 'CTRY_NM'
            },
            {
                'field': 'availableDates',
                'displayName': 'Available Dates',
                'defaultValueField': 'currentDate',
                'defaultValue': '',
                'type': 'dropdown',
                'dateDropDown': true,
                'disabled': false,
                'hierarchyParent': 'CTRY_NM'
            },
            {
                'field': 'typNm',
                'displayName': 'Revenue Type',
                'defaultValueField': 0,
                'defaultValue': 'A',
                'type': 'dropdown',
                'disabled': false,
                'kvp': true,
                'values': [{
                    'name': 'All',
                    'value': 'A'
                }, {
                    'name': 'International',
                    'value': 'I'
                }, {
                    'name': 'Domestic',
                    'value': 'D'
                }],
                'hierarchyParent': 'CTRY_NM'
            }
        ],
        'ajaxUrls': {
            'defaultGet': {
                'url': 'countrySTSettings',
                'defaultParams': {
                    'type': 'GET'
                },
                'params': {
                    'CTRY_CD_NM': 'country',
                    'availableDates': 'startDate',
                    'typNm': 'typNm'
                }
            },
            'filterGet': {
                'url': 'postAdminDetl',
                'defaultParams': {
                    'type': 'GET'
                },
                'params': {
                    'CTRY_CD_NM': 'ctryCd',
                    'availableDates': 'startdate',
                    'typNm': 'typNm'
                }
            },
            'update': 'saveST',
            'add': 'saveST',
            'delete': 'deleteSTRow',
            'init': {
                'countryDetails': {
                    'url': 'CountryDetails',
                    'filterFieldMap': {
                        'CTRY_NM': 'CTRY_NM'
                    },
                    'defaultRequest': {
                        'type': 'ALL'
                    },
                    'dynamicParam': null
                },
                'availableDates': {
                    'url': 'stSettingsAvailableDates',
                    'filterFieldMap': {
                        'AVAILABLE_DATE_ARRAY': 'availableDates'
                    },
                    'defaultRequest': {
                        'type': 'GET'
                    },
                    'dynamicParam': {
                        'ctryCd': 'loggedInCountryCode'
                    }
                },
                'closestDate': {
                    'url': 'closestStandardTariffDiscInfo',
                    'dynamicModelMap': {
                        'CLOSESTDATE': 'availableDates'
                    },
                    'defaultRequest': {
                        'type': 'GET'
                    },
                    'dynamicParam': {
                        'ctryCd': 'loggedInCountryCode',
                        'inputValue': 'newSpsFormatedDate'
                    }
                },
                'url': null
            }
        },
        'eventConfig': {
            'init': 'if(payload && payload.component) { if(payload.initResponse) { payload.component.dynamicHierarchy["countryName"] = payload.initResponse; payload.component.filterFieldMap["countryName"].values = Object.keys(payload.initResponse); Object.keys(payload.initResponse).map(function(key) { if(payload.initResponse[key] && (payload.initResponse[key].countryCode === payload.component.loggedInCountryCode)) { payload.component.dynamicModel["countryName"] = key; payload.component.dynamicModel["countryCode"] = payload.initResponse[key].countryCode; payload.component.dynamicModel["currencyCode"] = payload.initResponse[key].currencyCode; payload.component.filterFieldMap["availableDates"].values = payload.initResponse[key].availableDates; payload.component.dynamicModel["availableDates"] = payload.initResponse[key].currentDate;} }); payload.component.filterData(); } }',
            'get': 'if(payload && payload.component) { if(payload.getResponse) { payload.getResponse.map(function(response){ if(response.TYP_NM === "D") { response.TYP_NM = "Domestic"; } else { response.TYP_NM = "International"; } }); } } return payload.getResponse;',
            'add': 'var data = new FormData(); if(payload && payload.component) { if(payload.createData) { var obj = payload.createData; var formData = new FormData(); formData.append("cntryCd ", obj.CTRY_CD_NM); formData.append("startDate", payload.utility.formatDateTime(new Date(obj.EFF_DT), "MM/DD/YYYY")); if (obj.files_file_content && (obj.FILE_EXT_TYP_NM || !obj.STD_TRF_DISC_ID_NBR)) {  formData.append(\'replaceFile\', "true"); formData.append("attachedFile", payload.utility.files[0]); } else { formData.append("replaceFile", "false"); } formData.append("attachedFileNm", "testFile.pdf"); formData.append("ldapId", obj.UPLD_LDAP_ID_NBR || 3535076); formData.append("positionNbr", obj.NET_REV_POS_NBR); formData.append("description", obj.DESC_TXT); formData.append("ratingCategoryCd", obj.RTNG_CTGY_ID_NM); formData.append("localMaxRev", obj.MAX_CURR_AMT); formData.append("localMinRev", obj.MIN_CURR_AMT); formData.append("typeNm", obj.TYP_NM);  data = formData; } } return data;',
            'update': 'var data = new FormData(); if(payload && payload.component) { if(payload.updateArr) { payload.updateArr.map(function(obj) { var formData = new FormData(); formData.append("cntryCd ", obj.CTRY_CD_NM); formData.append("startDate", payload.utility.formatDateTime(new Date(obj.EFF_DT), "MM/DD/YYYY")); if (obj.files && (obj.FILE_EXT_TYP_NM || !obj.STD_TRF_DISC_ID_NBR)) {  formData.append(\'replaceFile\', "true"); formData.append("attachedFile", obj.files); } else { formData.append("replaceFile", "false"); } formData.append("attachedFileNm", obj.FILE_EXT_TYP_NM); formData.append("ldapId", obj.UPLD_LDAP_ID_NBR || 3535076); formData.append("positionNbr", obj.NET_REV_POS_NBR); formData.append("description", obj.DESC_TXT); formData.append("ratingCategoryCd", obj.RTNG_CTGY_ID_NM); formData.append("localMaxRev", obj.MAX_CURR_AMT); formData.append("localMinRev", obj.MIN_CURR_AMT); var typeNm = (obj.TYP_NM === "International") ? "I" : "D"; formData.append("typeNm", typeNm); data = formData; }); } } return data;',
            'delete': 'var obj = {}; if(payload && payload.component) { if(payload.deleteData) { obj.cntryCd = payload.deleteData.CTRY_CD_NM; obj.ratingCategoryCd= payload.deleteData.RTNG_CTGY_ID_NM; obj.startDate= payload.utility.formatDateTime(new Date(payload.deleteData.EFF_DT), "DD/MM/YYYY"); obj.typeNm= payload.deleteData.TYP_NM=="International"?"I":"D"; } } return obj;'
        },
        'crudConfig': {},
        'table': [
            {
                'name': 'ID',
                'property': 'STD_TRF_DISC_ID_NBR',
                'visibleType': 'STD_TRF_DISC_ID_NBR',
                'type': 'number',
                'inputType': 'text',
                'visible': false,
                'editable': false,
                'isModelProperty': true,
                'showEdit': false,
                'isPrimaryKey': true
            },
            {
                'name': 'Display Order',
                'property': 'NET_REV_POS_NBR',
                'visibleType': 'doc',
                'type': 'number',
                'inputType': 'text',
                'visible': true,
                'editable': true,
                'isModelProperty': true
            },
            {
                'name': 'Type',
                'property': 'TYP_NM',
                'visibleType': 'type',
                'type': 'dropdown',
                'transformMap': {
                    'Domestic': 'D',
                    'International': 'I'
                },
                'values': [
                    {
                        'value': 'Domestic',
                        'name': 'Domestic'
                    },
                    {
                        'value': 'International',
                        'name': 'International'
                    }
                ],
                'visible': true,
                'editable': true,
                'isModelProperty': true,
                'showEdit': false
            },
            {
                'name': 'Minimum',
                'property': 'MIN_CURR_AMT',
                'visibleType': 'min_rev',
                'type': 'number',
                'inputType': 'text',
                'visible': true,
                'editable': true,
                'isModelProperty': true,
                'showEdit': false
            },
            {
                'name': 'Maximum',
                'property': 'MAX_CURR_AMT',
                'visibleType': 'max_rev',
                'inputType': 'text',
                'type': 'number',
                'visible': true,
                'editable': true,
                'isModelProperty': true
            },
            {
                'name': 'Rating Category',
                'property': 'RTNG_CTGY_ID_NM',
                'visibleType': 'cat',
                'inputType': 'text',
                'type': 'text',
                'visible': true,
                'editable': true,
                'isModelProperty': true
            },
            {
                'name': 'Description',
                'property': 'DESC_TXT',
                'visibleType': 'desc',
                'type': 'text',
                'inputType': 'text',
                'visible': true,
                'editable': true,
                'isModelProperty': true
            },
            {
                'name': 'Effective Date',
                'property': 'EFF_DT',
                'visibleType': 'EFF_DT',
                'type': 'date',
                'visible': true,
                'editable': true,
                'isModelProperty': true
            },
            {
                'name': 'Document',
                'property': 'FILE_EXT_TYP_NM',
                'visibleType': 'doc',
                'type': 'file',
                'inputType': 'file',
                'visible': true,
                'editable': true,
                'isModelProperty': true
            },
            {
                'name': 'Country',
                'property': 'CTRY_CD_NM',
                'visibleType': 'countryCode',
                'type': 'dropdown',
                'utilFieldNm': 'countryCodeArr',
                'values': [],
                'visible': false,
                'editable': true,
                'isModelProperty': true,
                'showEdit': true
            }
        ],
        'createUpdateForm': {
            'name': 'Test',
            'submitUrl': '',
            'form_name': 'sts',
            'entity': 'sts',
            'fields': [
                {
                    'label': 'Country',
                    'name': 'CTRY_CD_NM',
                    'type': 'select',
                    'required': true,
                    'inputType': 'text',
                    'value': '',
                    'utilFieldNm': 'countryCodeArr',
                    'defaultValueRef': 'filteredCountryCode',
                    'options': [],
                    'validations': [
                        {
                            'name': 'required',
                            'validator': '',
                            'message': 'country Required'
                        }
                    ]
                },
                {
                    'label': 'Type',
                    'name': 'TYP_NM',
                    'type': 'select',
                    'required': true,
                    'inputType': 'text',
                    'value': 'D',
                    'options': [
                        {
                            'value': 'D',
                            'name': 'Domestic'
                        },
                        {
                            'value': 'I',
                            'name': 'International'
                        }
                    ],
                    'validations': [
                        {
                            'name': 'required',
                            'validator': '',
                            'message': 'Tariff Type Required'
                        }
                    ]
                },
                {
                    'label': 'Rating Category',
                    'name': 'RTNG_CTGY_ID_NM',
                    'type': 'input',
                    'required': true,
                    'value': 0,
                    'inputType': 'text',
                    'validations': [
                        {
                            'name': 'required',
                            'validator': '',
                            'message': 'Rating Category Required'
                        }
                    ]
                },
                {
                    'label': 'Description',
                    'name': 'DESC_TXT',
                    'type': 'input',
                    'value': 0,
                    'required': true,
                    'inputType': 'text',
                    'validations': [
                        {
                            'name': 'required',
                            'validator': '',
                            'message': 'Description Required'
                        }
                    ]
                },
                {
                    'label': 'Minimum',
                    'name': 'MIN_CURR_AMT',
                    'type': 'input',
                    'required': true,
                    'inputType': 'number',
                    'value': 0,
                    'validations': [
                        {
                            'name': 'required',
                            'validator': '',
                            'message': 'Minimum value Required'
                        },
                        {
                            'name': 'pattern',
                            'validator': '^[1-9]+[0-9]*$',
                            'message': 'Only Positive Whole Numbers Required'
                        }
                    ]
                },
                {
                    'label': 'Maximum',
                    'name': 'MAX_CURR_AMT',
                    'type': 'input',
                    'required': true,
                    'value': 0,
                    'inputType': 'number',
                    'validations': [
                        {
                            'name': 'required',
                            'validator': '',
                            'message': 'Maximum Value Required'
                        },
                        {
                            'name': 'pattern',
                            'validator': '^[1-9]+[0-9]*$',
                            'message': 'Only Positive Whole Numbers Required'
                        }
                    ]
                },
                {
                    'label': 'Effective Date',
                    'name': 'EFF_DT',
                    'type': 'date',
                    'required': true,
                    'value': 0,
                    'inputType': 'date',
                    'validations': [{
                        'name': 'required',
                        'validator': '',
                        'message': 'Effective Date Required'
                    }]
                },
                {
                    'name': 'files',
                    'property': 'files',
                    'visibleType': 'doc',
                    'type': 'fileInput',
                    'inputType': 'file',
                    'visible': true,
                    'editable': true,
                    'isModelProperty': true,
                    'validations': [
                        {
                            'name': 'required',
                            'validator': '',
                            'message': 'File Required'
                        }
                    ]
                },
                {
                    'label': 'Display order',
                    'name': 'NET_REV_POS_NBR',
                    'type': 'input',
                    'required': true,
                    'value': 0,
                    'inputType': 'number',
                    'validations': [
                        {
                            'name': 'required',
                            'validator': '',
                            'message': 'Display order Required'
                        },
                        {
                            'name': 'pattern',
                            'validator': '^$|^([0-9]|[1-9][0-9]|[1][0][0])?',
                            'message': 'Only Positive Numbers Required'
                        }
                    ]
                },
                {
                    'type': 'button',
                    'inputType': 'submit',
                    'styleColor': 'primary',
                    'styleClass': 'float-right',
                    'label': 'Add Setting'
                }
            ]
        }
    }
}
