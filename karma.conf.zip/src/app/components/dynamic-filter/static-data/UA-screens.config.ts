export class UAConfig {
    static config = {
        'title': 'Manage User Access',
        'subTitle': 'Configure User Access',
        'advancedFilterTitle': 'Filter Users',
        'noDateConfiguration': true,
        'clientFilter': true,
        'filters': [
            {
                'field': 'userId',
                'displayName': 'User ID/LDAP ID(Enter 0 to get all results)',
                'type': 'input',
                'inputType': 'number',
                'hierarchyRoot': true
            },
            {
                'displayName': 'Role Name',
                'field': 'roleNm',
                'defaultValueField': 0,
                'defaultValue': 0,
                'type': 'dropdown',
                'disabled': false,
                'kvp': true,
                'values': [
                    {
                        'value': 0,
                        'name': 'ALL'
                    },
                    {
                        'value': 'Sales User',
                        'name': 'Sales User'
                    },
                    {
                        'value': 'Pricing User',
                        'name': 'Pricing User'
                    }
                ]
            }
        ],
        'isInlineEdit': true,
        'ajaxUrls': {
            'defaultGet': {
                'url': 'getUserAccessDetails',
                'isAdminUrl': true,
                'defaultParams': {
                    'type': 'GET',
                    'userId': '0',
                    'roleNm': 'Sales User'
                },
                'params': {
                    'userId': 'userId'
                },
                'storeData': true
            },
            'filterGet': {
                'url': 'getUserAccessDetails',
                'isAdminUrl': true,
                'defaultParams': {
                    'type': 'GET',
                    'userId': '0',
                    'roleNm': 'Sales User'
                },
                'params': {
                    'userId': 'userId',
                    'roleNm': 'roleNm'
                }
            },
            'update': 'UpdateUserDetails',
            'add': 'saveUser',
            'delete': '',
            'init': {
                'countryDetails': {
                    'url': 'CountryDetails',
                    'filterFieldMap': {
                        'CTRY_NM': 'CTRY_NM'
                    },
                    'defaultRequest': {
                        'type': 'ALL'
                    },
                    'dynamicParam': null
                },
                'url': null
            }
        },
        'crudConfig': {},
        'table': [
            {
                'name': 'ID',
                'property': 'userId',
                'visibleType': 'userId',
                'type': 'number',
                'inputType': 'text',
                'visible': true,
                'editable': false,
                'isModelProperty': true,
                'showEdit': false,
                'isPrimaryKey': true
            },
            {
                'name': 'Name',
                'property': 'fullName',
                'visibleType': 'userId',
                'type': 'number',
                'inputType': 'text',
                'visible': true,
                'editable': false,
                'isModelProperty': true,
                'showEdit': false,
                'isPrimaryKey': false
            },
            {
                'name': 'ROLE',
                'property': 'roleNm',
                'visibleType': 'roleNm',
                'type': 'text',
                'inputType': 'text',
                'visible': true,
                'editable': false,
                'isModelProperty': true,
                'showEdit': false,
                'isPrimaryKey': true
            },
            {
                'name': 'Country',
                'property': 'countryList',
                'visibleType': 'countryList',
                'type': 'dropdown',
                'utilFieldNm': 'countryCodeArr',
                'multiSelect': true,
                'values': [],
                'visible': true,
                'editable': true,
                'isModelProperty': true,
                'showEdit': true
            }
        ],
        'createUpdateForm': {
            'name': 'Test',
            'submitUrl': '',
            'form_name': 'UA',
            'entity': 'UA',
            'fields': [
                {
                    'label': 'User Name',
                    'name': 'userName',
                    'type': 'input',
                    'required': true,
                    'inputType': 'text',
                    'value': '',
                    'validations': []
                },
                {
                    'label': 'User ID',
                    'name': 'userId',
                    'type': 'input',
                    'required': true,
                    'inputType': 'number',
                    'value': '',
                    'validations': [
                        {
                            'name': 'required',
                            'validator': '',
                            'message': 'UserID Required'
                        },
                        {
                            'name': 'pattern',
                            'validator': '^[1-9]+[0-9]*$',
                            'message': 'Only Positive Whole Numbers Required'
                        }
                    ]
                },
                {
                    'label': 'Accesible Countries',
                    'name': 'countryCodes',
                    'type': 'select',
                    'multiSelect': true,
                    'required': true,
                    'inputType': 'text',
                    'value': [],
                    'utilFieldNm': 'countryCodeArr',
                    'options': [],
                    'validations': [
                        {
                            'name': 'required',
                            'validator': '',
                            'message': 'Country Required'
                        }
                    ]
                },
                {
                    'label': 'Role Name',
                    'name': 'roleName',
                    'type': 'select',
                    'required': true,
                    'inputType': 'text',
                    'value': 'Sales User',
                    'options': [
                        {
                            'value': 'Sales User',
                            'name': 'Sales User'
                        },
                        {
                            'value': 'Pricing User',
                            'name': 'Pricing User'
                        }
                    ],
                    'validations': [
                        {
                            'name': 'required',
                            'validator': '',
                            'message': 'Role Name Required'
                        }
                    ]
                },
                {
                    'type': 'button',
                    'inputType': 'submit',
                    'styleColor': 'primary',
                    'styleClass': 'float-right',
                    'label': 'Add User'
                }
            ]
        }
    }
}
