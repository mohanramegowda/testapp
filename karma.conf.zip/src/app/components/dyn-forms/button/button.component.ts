import { Component, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { FieldConfig } from '../field.interface';
@Component({
  selector: 'app-dynamic-button',
  template: `
<div class="demo-full-width margin-top {{field.styleClass}}" [formGroup]="group">
<button type="{{field.inputType}}"
 (click)="onClick()" mat-raised-button color="{{field.styleColor}}">{{field.label}}</button>
</div>
`,
  styles: []
})
export class ButtonComponent implements OnInit {
  field: FieldConfig;
  group: FormGroup;
  constructor() {}
  ngOnInit() {}
  onClick() {
    console.log('onClick');
  }
}
