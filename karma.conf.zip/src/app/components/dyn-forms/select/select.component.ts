import { Component, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { FieldConfig } from '../field.interface';
declare var $: any;

@Component({
    selector: 'app-dynamic-select',
    template: `
<mat-form-field class="demo-full-width margin-top {{field.styleClass}}" [formGroup]="group">
<mat-select [ngClass]= "{'fa-disabled' : (field?.options && (field?.options?.length != 0))?false:true }"
[placeholder]="field.label" [formControlName]="field.name" [multiple] = "field.multiSelect === true? true : false">
<button mat-raised-button class="mat-primary ml-2 mt-1" *ngIf="field.multiSelect==true?true:false"
(click)="selectAll(field.name, field.options, true, $event)">Select All</button>

<button mat-raised-button class="mat-accent ml-2 mt-1"
*ngIf="field.multiSelect==true?true:false"
(click)="selectAll(field.name, field.options, false, $event)">
Deselect All
</button>
<mat-option *ngFor="let item of field.options" [value]="item.value">{{item.name}}</mat-option>
</mat-select>
</mat-form-field>
`,
    styles: []
})
export class SelectComponent implements OnInit {
    field: FieldConfig;
    group: FormGroup;
    constructor() { }
    ngOnInit() {

    }

    selectAll(fieldName, arr, select, event) {
        this.group.get(fieldName).patchValue([]);
        if (select) {
            const row = [];
            arr.map((val) => {
                if (val.value) {
                    row.push(val.value);
                }
            });
            this.group.get(fieldName).patchValue(row);
            $(event.target).parents().find('.mat-select-panel').find('mat-pseudo-checkbox').addClass('mat-pseudo-checkbox-checked');
            return;
        }
        $(event.target).parents().find('.mat-select-panel').find('mat-pseudo-checkbox').removeClass('mat-pseudo-checkbox-checked');
    }
}
