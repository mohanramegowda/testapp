import { Component, OnInit, Input } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { FieldConfig } from '../field.interface';
@Component({
    exportAs: 'app-dynamic-radiobutton',
    selector: 'app-dynamic-radiobutton',
    template: `
<div class="demo-full-width margin-top {{field.styleClass}}" id="{{field.id}}" style="{{field.style}}" [formGroup]="group">
<label class="radio-label-padding">{{field.label}} <span style="padding:0px 5px;">:</span> </label>
<mat-radio-group [formControlName]="field.name">
<mat-radio-button [disabled]="disabled" *ngFor="let item of field.options" [value]="item">{{item}}</mat-radio-button>
</mat-radio-group>
</div>
`,
    styles: [`#payer{text-align:right}`]
})
export class RadiobuttonComponent implements OnInit {
    @Input() field: FieldConfig[] = [];
    group: FormGroup;
    disabled: boolean;
    constructor() { }
    ngOnInit() { }
}
