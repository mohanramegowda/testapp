import { Component, OnInit } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { FieldConfig } from '../field.interface';
@Component({
    selector: 'app-dynamic-input',
    template: `
<mat-form-field class="demo-full-width {{field.styleClass}}" [formGroup]="group">
<input matInput [required]="required"
[formControlName]="field.name" [placeholder]="field.label" [type]="field.inputType">
<ng-container *ngFor="let validation of field.validations;" ngProjectAs="mat-error">
<mat-error *ngIf="group.get(field.name).hasError(validation.name)">{{validation.message}}</mat-error>
</ng-container>
</mat-form-field>
`,
    styles: []
})
export class InputComponent implements OnInit {
    field: FieldConfig;
    group: FormGroup;
    required: boolean;
    constructor() { }
    ngOnInit() {
        if (this.field.validations && this.field.validations.length) {
            this.field.validations.map((ele) => {
                if (ele.name === 'required') {
                    this.required = true;
                }
            })
        } else {
            this.required = false;
        }
    }
}
