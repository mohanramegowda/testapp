import { Component, OnInit, } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { SpsUtility } from 'app/common/SpsUtility';
import { MatDialog } from '@angular/material/dialog';
import { CommonService } from 'app/common/common.service';

declare const $: any;
declare const window: any;
declare interface RouteInfo {
    path: string;
    title: string;
    icon: string;
    class: string;
    isOld: boolean;
}
declare interface ParentRouteInfo {
    path: string;
    title: string;
    icon: string;
    name: string;
    class: string;
    isOld: boolean;
    children: RouteInfo[];
    show: boolean;
    actions: string[];
}
export const ROUTES: ParentRouteInfo[] = [
    {
        path: '/dashboard',
        name: 'dashboard',
        isOld: false,
        title: 'Dashboard',
        icon: 'dashboard',
        class: '',
        children: null,
        show: true,
        actions: []
    },
    // {
    //     path: '/generate',
    //     isOld: false,
    //     name: 'generate',
    //     title: 'Generate Tariff',
    //     icon: 'add',
    //     class: '',
    //     children: null,
    //     show: true,
    //     actions: []
    // },
    // {
    //     path: '/activity',
    //     isOld: false,
    //     name: 'activity',
    //     title: 'Activity View',
    //     icon: 'dehaze',
    //     class: '',
    //     children: null,
    //     show: true,
    //     actions: []
    // },
    // {
    //     path: '/define',
    //     name: 'define',
    //     isOld: false,
    //     title: 'DOM Customer',
    //     icon: 'person',
    //     class: '',
    //     children: null,
    //     show: true,
    //     actions: []
    // },
    {
        path: '/create',
        name: 'create',
        isOld: false,
        title: 'SPS',
        icon: 'person',
        class: '',
        children: null,
        show: true,
        actions: []
    },
    {
        path: '/manage',
        name: 'manage',
        isOld: false,
        title: 'SPS',
        icon: 'person',
        class: '',
        children: null,
        show: true,
        actions: []
    }
];


// {
//     path: '',
//     isOld: false,
//     name: 'admin',
//     title: 'Admin - Settings',
//     icon: 'layers',
//     class: '',
//     show: false,
//     actions: [],
//     children: [{
//         path: '/list/TTS',
//         isOld: false,
//         title: 'Tariff Type',
//         icon: 'content_paste',
//         class: '',
//     }, {
//         path: '/list/STS',
//         isOld: false,
//         title: 'Standard Tariff',
//         icon: 'content_paste',
//         class: '',
//     },
//     {
//         path: '/#/Admin',
//         isOld: true,
//         title: 'Fast Track Tariff',
//         icon: 'content_paste',
//         class: '',
//     },
//     {
//         path: '/#/Admin',
//         isOld: true,
//         title: 'Personalised Tariff',
//         icon: 'content_paste',
//         class: '',
//     },
//     {
//         path: '/list/UA',
//         isOld: false,
//         title: 'User Access',
//         icon: 'content_paste',
//         class: '',
//     }]
// },


@Component({
    selector: 'app-sidebar',
    templateUrl: './sidebar.component.html',
    styleUrls: ['./sidebar.component.css']
})
export class SidebarComponent implements OnInit {
    menuItems: any[];
    fullOriginPath: any = '';

    constructor(
        private route: ActivatedRoute,
        private router: Router,
        private commonservice: CommonService,
    ) {
    }

    ngOnInit() {
        this.getOldAdminScreenPath();
        this.menuItems = ROUTES.filter(menuItem => menuItem);
        const actions = SpsUtility.roleActions.actions;
        this.menuItems.map((menuItem) => {
            if (1 === 1 || (SpsUtility.roleActions && SpsUtility.roleActions.roles
                && SpsUtility.roleActions.roles.indexOf(menuItem.name) > -1)) {
                menuItem.show = true;
                menuItem.actions = actions;
            } else {
                menuItem.show = false;
                menuItem.actions = [];
            }
        });
    }

    isMobileMenu() {
        if ($(window).width() > 991) {
            return false;
        }
        return true;
    }

    getOldAdminScreenPath() {
        const fullPath = SpsUtility.fullOriginPath;
        this.fullOriginPath = fullPath + window.location.pathname.substring(0, window.location.pathname.indexOf('/', 2));
        this.fullOriginPath += '/old';
    }

    routeTo(path) {
        this.router.navigate(path);
    }
}
