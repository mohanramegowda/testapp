import { HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
// tslint:disable-next-line:import-blacklist
import { Observable } from 'rxjs/Rx';
import * as moment from 'moment';
import { user } from '../../config/userConfig';
import { environment }  from  '../../environments/environment'
@Injectable()
export class SpsUtility {
    static isLocal = true;
    static userDetails: any = {};
    static userInfo: any = {};    
    static countryList: any = {};
    static roleDetails: any = {};
    static accessibleRouts : any = {};
    static loggedInCountryDetails: any = {};
    static countryCodeNameMap: any = {};
    static countryCodeDetailMap: any = {};
    static countryAccessMap: any = {};
    static countryIdMap: any = {};
    static countryIdCodeMap: any = {};
    static displayCountriesMap = {};
    static redirection: any;
    static commonStaticObject: any = {};
    static fullOriginPath = window.location.origin;
    static roleActions: any = {};
    static files: FileList;
    // static localUrl = 'https://ca-uat-cluster.emea.fedex.com:8443/preprod/ftt';
    static localUrl = 'https://knight.emea.fedex.com/sps';
    static localEmailUrl = ''
    static user = (SpsUtility.isLocal) ? '3798147' : ''; // 926643
    
    static baseParams = {        
        businessServiceBaseUrl: {
            url:
                (SpsUtility.isLocal) ? `${SpsUtility.localUrl}/v1` : (`${SpsUtility.getContextPath()}/v1`),
            type: 'GET'
        },
        adminServiceBaseUrl: {
            url:
                (SpsUtility.isLocal) ? `${SpsUtility.localUrl}/admin/v1` :
                    (`${SpsUtility.getContextPath()}/admin/v1`),
            type: 'GET'
        },
        uiBaseUrl: {
            url: (SpsUtility.isLocal) ? `${SpsUtility.localUrl}/user/v1` : `${SpsUtility.getContextPath()}/user/v1`
        },
        customerBaseUrl : {
            url: (SpsUtility.isLocal) ? `https://dione.emea.fedex.com:8989/sps-customer/sps-customer/v1`: `${SpsUtility.getContextPath()}/sps-customer/v1`
        },
        userServiceBaseUrl: {
            url:
                (SpsUtility.isLocal) ? `https://dione.emea.fedex.com:8989/sps-userservice/v1` : `${SpsUtility.getContextPath()}/sps-userservice/v1`,
            type: 'GET'
        },
        SpSshipmentserviceBaseUrl: {
            url:
                (SpsUtility.isLocal) ? `https://dione.emea.fedex.com:8989/sps-shipmentservice/sps-shipmentservice/v1` : `${SpsUtility.getContextPath()}/sps-shipmentservice/v1`,
            type: 'GET'
        }
        //  loginUrl : {url:'./assets/sample_files/user.json', type: 'GET' },        
    }

    static urlParams = {
        loginUrl : {url:`${SpsUtility.baseParams.uiBaseUrl.url}/profile/signeduser/`, type: 'GET' },
        authorize : {url: `${SpsUtility.baseParams.uiBaseUrl.url}/profile/authorize/user/`, type: 'GET' },
        wssoLogoutUrl: { url: '/logout', type: 'GET' },
        escUrl : { url:'/', type: 'GET' },
        customerUrl : {url:`${SpsUtility.baseParams.customerBaseUrl.url}/sps/customer/search`, type: 'POST' },
        saveUserUrl : {url:`${SpsUtility.baseParams.userServiceBaseUrl.url}/sps/user/saveuser`, type: 'POST' },
        saveCallerUrl : {url:`${SpsUtility.baseParams.customerBaseUrl.url}/sps/customer/saveCustomer`, type: 'POST' },
        checkAddrUrl : {url:`${SpsUtility.baseParams.userServiceBaseUrl.url}/sps/address/tnt/town?`, type: 'GET' },
        specialServiceUrl: {url:`${SpsUtility.baseParams.SpSshipmentserviceBaseUrl.url}/sps/shipment/specialService`, type: 'GET' },
        tntspecialServiceUrl: {url:`${SpsUtility.baseParams.SpSshipmentserviceBaseUrl.url}/sps/shipment/tntspecialService?`, type: 'GET' },
        saveconsignmentDetails: {url:`${SpsUtility.baseParams.SpSshipmentserviceBaseUrl.url}/sps/shipment/save`, type: 'POST' },
        saveconsignmentDetailsToGLServer: {url:`${SpsUtility.baseParams.SpSshipmentserviceBaseUrl.url}/sps/shipment/submit`, type: 'POST' },
        managequoteUrl : {url:`${SpsUtility.baseParams.SpSshipmentserviceBaseUrl.url}/sps/shipment/managequotes?`, type: 'GET' },
        saveQuotePriceUrl : {url:`${SpsUtility.baseParams.SpSshipmentserviceBaseUrl.url}/sps/shipment/update`, type: 'POST' },
        getDetailsByOrderIdUrl : {url:`${SpsUtility.baseParams.SpSshipmentserviceBaseUrl.url}/sps/shipment/getquote?`, type: 'GET' },
        invoiceUrl :  {url:`${SpsUtility.baseParams.SpSshipmentserviceBaseUrl.url}/sps/invoice?`, type: 'GET' },
        custMailUrl : {url:`${SpsUtility.baseParams.SpSshipmentserviceBaseUrl.url}/sps/shipment/sendemail`, type: 'POST' },
        getCustInfoByReqIdUrl : {url:`${SpsUtility.baseParams.customerBaseUrl.url}/sps/customer/getcustinfo?`, type: 'GET' },
        getCustOrderInfoByReqIdUrl : {url:`${SpsUtility.baseParams.SpSshipmentserviceBaseUrl.url}/sps/shipment/orderdetails?`, type: 'GET' },   
        getCustOrderInfoByQuoteUrl : {url:`${SpsUtility.baseParams.SpSshipmentserviceBaseUrl.url}/sps/shipment/quoteprice?`, type: 'GET' },
    }

    static getContextPath() {
       // return window.location.pathname.substring(0, window.location.pathname.indexOf('/', 2));
       return window.location.pathname.substring(0, window.location.pathname.lastIndexOf('/', window.location.pathname.length));
    }

    static formatDateTime(date: Date = new Date(), format: string = 'dd/mm/yyyy') {
        return moment(date).format(format);
    }

    static toHttpParams(obj: object): HttpParams {
        // convert class/json/object to HttpParams
        let params = new HttpParams();
        for (const key in obj) {
            if (obj.hasOwnProperty(key)) {
                const val = obj[key];
                if (val !== null && val !== undefined) {
                    params = params.append(key, val.toString());
                }
            }
        }
        return params;
    }

    static seSessionStorageItem(itemName: string, item: string): void {
        sessionStorage.setItem(itemName, item);
    }

    static getSessionStorageItem(itemName: string): string {
        return sessionStorage.getItem(itemName);
    }

    static getLocalStorageItem(itemName: string): string {
        return localStorage.getItem(itemName);
    }

    static setLocalStorageItem(itemName: string, item: string): void {
        localStorage.setItem(itemName, item);
    }

    static clearAllSessionStorageItems() {        
        return sessionStorage.clear();
    }

    static errorHandler(error): Observable<string> {
        if (error.status === 500) {
            return Observable.throw(new Error('Error while processing request'));
        } else if (error.status === 400 || error.status === 401) {
            return Observable.throw(new Error('Invalid username and password'));
        } else if (error.status === 409) {
            return Observable.throw(new Error(error.status));
        } else if (error.status === 406) {
            return Observable.throw(new Error(error.status));
        }
    }
}
