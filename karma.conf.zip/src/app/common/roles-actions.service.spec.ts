import { TestBed } from '@angular/core/testing';
import { RolesAndActionsService } from './roles-actions.service';

describe('RolesServiceService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: RolesAndActionsService = TestBed.get(RolesAndActionsService);
    expect(service).toBeTruthy();
  });
});
