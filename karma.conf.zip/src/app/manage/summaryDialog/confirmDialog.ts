import { Component, Inject, OnInit } from '@angular/core';
import { VERSION, MatDialogRef, MatDialog, MatSnackBar, MAT_DIALOG_DATA } from '@angular/material';
import { SpsUtility } from '../../common/SpsUtility';
import { CommonService } from '../../common/common.service';


@Component({
  selector: 'confirmDialog',
  templateUrl: './confirmDialog.html',
  styleUrls: []

})
export class confirmDialog implements OnInit {


  constructor(
    @Inject(MAT_DIALOG_DATA) private data: any, private commonService: CommonService,
    private dialogRef: MatDialogRef<confirmDialog>, private dialog: MatDialog) {
    // if(data){            
    // }

  }

  ngOnInit(): void {

  }

  confirm() {
    console.log(this.data.quote_price);

    // SAVE QUOTE vaLUE
    if (this.data.title == 'Quote Price') {
      const saveQuotePriceUrl = SpsUtility.urlParams.saveQuotePriceUrl.url;
      const saveQuotePriceObject = {
        "requestId": this.data.requestId,
        "orderId": this.data.orderId,
        "price": this.data.value
      };
      this.commonService.getAPIResponse(saveQuotePriceUrl, saveQuotePriceObject, SpsUtility.urlParams.saveQuotePriceUrl.type).subscribe((saveQuotePriceResponse: any) => {
        // SpsUtility.commonStaticObject.specialServiceResponse = specialServiceResponse;        
        console.log("saveQuotePriceResponse ", saveQuotePriceResponse);
        if (saveQuotePriceResponse.price == this.data.value) {
          this.commonService.showNotifier("Quote Price is saved Successfully.", 'success');
          this.dialogRef.close(true);
        }
      });
    }

    // SAVE Connote Number
    if (this.data.title == 'Connote Number') {
      const saveConnoteNumberUrl = SpsUtility.urlParams.saveQuotePriceUrl.url;
      const saveConnoteNumberObject = {
        "requestId": this.data.requestId,
        "orderId": this.data.orderId,
        "consignmentNumber": this.data.value
      };
      this.commonService.getAPIResponse(saveConnoteNumberUrl, saveConnoteNumberObject, SpsUtility.urlParams.saveQuotePriceUrl.type).subscribe((saveConnoteNumberResponse: any) => {
        // SpsUtility.commonStaticObject.specialServiceResponse = specialServiceResponse;        
        console.log("saveConnoteNumberResponse ", saveConnoteNumberResponse);
        if (saveConnoteNumberResponse.consignmentNumber == this.data.value) {
          //change status to "CANCELLED"
          const saveConnoteStatusUrl = SpsUtility.urlParams.saveQuotePriceUrl.url;
          const saveConnoteStatusObject = {
            "requestId": this.data.requestId,
            "orderId": this.data.orderId,
            "status": "BOOKED"
          };
          this.commonService.getAPIResponse(saveConnoteStatusUrl, saveConnoteStatusObject, SpsUtility.urlParams.saveQuotePriceUrl.type).subscribe((saveConnoteStatusObjectResponse: any) => {
            // SpsUtility.commonStaticObject.specialServiceResponse = specialServiceResponse;        
            console.log("saveConnoteStatusObjectResponse ", saveConnoteStatusObjectResponse);
            this.commonService.showNotifier("Connote Number is saved Successfully.", 'success');          
            this.dialogRef.close(true);
          });          
        }
      });
      

    }


    // CANCEL ORDER 
    if (this.data.title == 'Cancel Order') {
      console.log(this.data.sendMailObj);

      const custOfferMailUrl = SpsUtility.urlParams.custMailUrl.url;
      this.commonService.getAPIResponse(custOfferMailUrl, this.data.sendMailObj, SpsUtility.urlParams.custMailUrl.type).subscribe((getMailResponse: any) => {
        // SpsUtility.commonStaticObject.specialServiceResponse = specialServiceResponse;      
        console.log("getMailResponse ", getMailResponse);
        if (getMailResponse.responses[0].messages[0] == "Queued") {
          this.commonService.showNotifier("Order : " + this.data.orderId +  " is cancelled. Email sent Successfully.", 'success');

          //change status to "CANCELLED"
          const saveQuoteStatusUrl = SpsUtility.urlParams.saveQuotePriceUrl.url;
          const saveQuoteStatusObject = {
            "requestId": this.data.requestId,
            "orderId": this.data.orderId,
            "status": "CANCELED"
          };
          this.commonService.getAPIResponse(saveQuoteStatusUrl, saveQuoteStatusObject, SpsUtility.urlParams.saveQuotePriceUrl.type).subscribe((saveQuoteStatusResponse: any) => {
            // SpsUtility.commonStaticObject.specialServiceResponse = specialServiceResponse;        
            console.log("saveQuoteStatusResponse ", saveQuoteStatusResponse);
            this.dialogRef.close(true);
          });

        }
      }, (error) => {
        this.commonService.showNotifier("Error while sending Email. Please,Cancel again.", 'error');
      });

    }

    if (this.data.title == 'Booked') {
      console.log(this.data.sendMailObj);

      const custOfferMailUrl = SpsUtility.urlParams.custMailUrl.url;
      this.commonService.getAPIResponse(custOfferMailUrl, this.data.sendMailObj, SpsUtility.urlParams.custMailUrl.type).subscribe((getMailResponse: any) => {
        // SpsUtility.commonStaticObject.specialServiceResponse = specialServiceResponse;      
        console.log("getMailResponse ", getMailResponse);
        if (getMailResponse.responses[0].messages[0] == "Queued") {
          this.commonService.showNotifier("Order : " + this.data.orderId +  " is Booked. Email sent Successfully.", 'success');

          //change status to "CANCELLED"
          const saveQuoteStatusUrl = SpsUtility.urlParams.saveQuotePriceUrl.url;
          const saveQuoteStatusObject = {
            "requestId": this.data.requestId,
            "orderId": this.data.orderId,
            "status": "BOOKED"
          };
          this.commonService.getAPIResponse(saveQuoteStatusUrl, saveQuoteStatusObject, SpsUtility.urlParams.saveQuotePriceUrl.type).subscribe((saveQuoteStatusResponse: any) => {
            // SpsUtility.commonStaticObject.specialServiceResponse = specialServiceResponse;        
            console.log("saveQuoteStatusResponse ", saveQuoteStatusResponse);
            this.dialogRef.close(true);
          });

        }

else{

  if (this.data.title == 'Not PickUP Cancel Order') {
    console.log(this.data.sendMailObj);

    const custOfferMailUrl = SpsUtility.urlParams.custMailUrl.url;
    this.commonService.getAPIResponse(custOfferMailUrl, this.data.sendMailObj, SpsUtility.urlParams.custMailUrl.type).subscribe((getMailResponse: any) => {
      // SpsUtility.commonStaticObject.specialServiceResponse = specialServiceResponse;      
      console.log("getMailResponse ", getMailResponse);
      if (getMailResponse.responses[0].messages[0] == "Queued") {
        this.commonService.showNotifier("Order : " + this.data.orderId +  " is cancelled. Email sent Successfully.", 'success');

        //change status to "CANCELLED"
        const saveQuoteStatusUrl = SpsUtility.urlParams.saveQuotePriceUrl.url;
        const saveQuoteStatusObject = {
          "requestId": this.data.requestId,
          "orderId": this.data.orderId,
          "status": "CANCELED"
        };
        this.commonService.getAPIResponse(saveQuoteStatusUrl, saveQuoteStatusObject, SpsUtility.urlParams.saveQuotePriceUrl.type).subscribe((saveQuoteStatusResponse: any) => {
          // SpsUtility.commonStaticObject.specialServiceResponse = specialServiceResponse;        
          console.log("saveQuoteStatusResponse ", saveQuoteStatusResponse);
          this.dialogRef.close(true);
        });

      }
    }, (error) => {
      this.commonService.showNotifier("Error while sending Email. Please,Cancel again.", 'error');
    });

  }

}
      }, (error) => {
        this.commonService.showNotifier("Error while sending Email. Please,Cancel again.", 'error');
      });

    }






  }

  close() {
    this.dialogRef.close();
  }





}