import { Component, Inject, OnInit } from '@angular/core';
import { VERSION, MatDialogRef, MatDialog, MatSnackBar, MAT_DIALOG_DATA } from '@angular/material';
import { Router, ActivatedRoute } from '@angular/router';
import { SpsUtility } from '../../common/SpsUtility';
import { CommonService } from '../../common/common.service';
import { confirmDialog } from './confirmDialog'
import { RolesAndActionsService } from '../../common/roles-actions.service';


@Component({
  selector: 'summaryDialog',
  templateUrl: './summaryDialog.html',
  styleUrls: ['./summaryDialog.scss']

})
export class summaryDialog implements OnInit {

  formGroups = { fromAddress: null };
  fromAddressDetails;
  message: any; price; selectedOrderDetails; cNumber;
  confirmButtonText = "SAVE"
  cancelButtonText = "CANCEL"
  CNumberVisibility; QPriceVisibility; agentObj = [];
  customerObj = [];
  canCancelOrder: boolean;
  canSendToCustomer: boolean;

  SpSAgentDetails = [
    {
      "Country": "SG",
      "Email_ID": "sps.sg@fedex.com",
      "SpS_Telephone": "1800-214-1111",
      "Conditions": "https://www.fedex.com/en-sg/conditions-of-carriage.html"
    },
    {
      "Country": "TW",
      "Email_ID": "sps.tw@fedex.com",
      "SpS_Telephone": "+886-2-55686120",
      "Conditions": "https://www.fedex.com/en-tw/conditions-of-carriage.html"
    },
    {
      "Country": "KR",
      "Email_ID": "sps.kr@fedex.com",
      "SpS_Telephone": "+82-2-330-5845",
      "Conditions": "https://www.fedex.com/en-kr/conditions-of-carriage.html"
    },
    {
      "Country": "JP",
      "Email_ID": "JP.SPS@corp.ds.fedex.com",
      "SpS_Telephone": "+81-80-5520-1947",
      "Conditions": "https://www.fedex.com/en-jp/conditions-of-carriage.html"
    },
    {
      "Country": "HK",
      "Email_ID": "sps.hk@fedex.com",
      "SpS_Telephone": "+852 2331 4709",
      "Conditions": "https://www.fedex.com/en-hk/conditions-of-carriage.html"
    },
    {
      "Country": "CN",
      "Email_ID": "cn_sps@tnt.com",
      "SpS_Telephone": "",
      "Conditions": "https://www.fedex.com/en-cn/conditions-of-carriage.html"
    }
  ];

  constructor(
    @Inject(MAT_DIALOG_DATA) private data: any, private commonService: CommonService, private rolesServices: RolesAndActionsService,
    private dialogRef: MatDialogRef<summaryDialog>, private dialog: MatDialog, private router: Router) {
    // if(data){            
    // }

  }

  ngOnInit(): void {
    console.log("summay....... ", this.data);
    console.log(SpsUtility.userDetails.countryInfo.ctryCd);
    //set agent Object by country logged in
    this.SpSAgentDetails.forEach(item => {
      //if (SpsUtility.userDetails.countryInfo.ctryCd == item.Country) {
      if (item.Country === 'TW') {
        console.log(item);
        this.agentObj.push(item);
      }
    });
    console.log(this.agentObj);

    //get details by selected order
    const getDetailsByOrderIdUrl = SpsUtility.urlParams.getDetailsByOrderIdUrl.url + 'orderId=' + this.data.message.orderId;
    this.canCancelOrder = this.rolesServices.CanCancelOrderInManage();
    this.canSendToCustomer = this.rolesServices.CanSendInManage();
    this.commonService.getAPIResponse(getDetailsByOrderIdUrl, null, SpsUtility.urlParams.getDetailsByOrderIdUrl.type).subscribe((getDetailsByOrderIdResponse: any) => {
      // SpsUtility.commonStaticObject.specialServiceResponse = specialServiceResponse;
      this.selectedOrderDetails = getDetailsByOrderIdResponse;
      console.log("getDetailsByOrderIdResponse ", getDetailsByOrderIdResponse);
    });

    //get customer inforamtion by req id
    const getCustInfoByReqIdUrl = SpsUtility.urlParams.getCustInfoByReqIdUrl.url + 'reqId=' + this.data.message.requestId
    this.commonService.getAPIResponse(getCustInfoByReqIdUrl, null, SpsUtility.urlParams.getCustInfoByReqIdUrl.type).subscribe((getCustResponse: any) => {
      console.log("getCustResponse ", getCustResponse);
      this.customerObj.push(getCustResponse);
    });


  }

  resubmitOrder() {
    this.dialogRef.close();
    console.log("resubmit....... ");

    //get customer and order inforamtion by req id
    const getCustOrderInfoByReqIdUrl = SpsUtility.urlParams.getCustOrderInfoByReqIdUrl.url + 'requestId=' + this.data.message.requestId;
    this.commonService.getAPIResponse(getCustOrderInfoByReqIdUrl, null, SpsUtility.urlParams.getCustOrderInfoByReqIdUrl.type).subscribe((getCustOrderResponse: any) => {
      console.log("getCustOrderResponse ", getCustOrderResponse);
      SpsUtility.commonStaticObject.manageToShipmentDetails = getCustOrderResponse;
      this.router.navigate(['/shipment'], { queryParams: { route: 'manage' }, skipLocationChange: true });
    });

  }

  cancelOrder() {
    const date = new Date();
    date.setHours(date.getHours() + 24);
    console.log(this.agentObj);
    console.log(this.customerObj);

    //send mail    
    const sendMailObj = {
      "To": {
        "Address": "mohan.ramegowda.osv@fedex.com",
        "SubscriberKey": "mohan.ramegowda.osv@fedex.com",
        "ContactAttributes": {
          "SubscriberAttributes": {
            "CANCEL_EMAIL": "FedEx Special Services Cancellation Confirmation",
            "FROM_COUNTRY": this.selectedOrderDetails.fromCountry,
            "TO_COUNTRY": this.selectedOrderDetails.toCountry,
            "ORDER_NUMBER": this.selectedOrderDetails.orderNo,
            "LOCAL_PERCOUNTRY_TEL_NBR": this.agentObj[0].SpS_Telephone,
            "PERCOUNTRY_EMAIL_ID": this.agentObj[0].Email_ID,
            "AGENT_NAME": SpsUtility.userDetails.usrFstNm + " " + SpsUtility.userDetails.usrLstNm,
            "CUSTOMER_EMAIL": "mohan.ramegowda.osv@fedex.com",
            "TERMSC_PER_COUNTRY_LINK": this.agentObj[0].Conditions
          }
        }
      },
      "OPTIONS": {
        "RequestType": "SYNC"
      }
    }

    //open dialog
    const dialogRef = this.dialog.open(confirmDialog, {
      disableClose: true,
      height: '200px',
      width: '500px',
      data: {
        requestId: this.data.message.requestId,
        orderId: this.data.message.orderId,
        sendMailObj: sendMailObj,
        title: 'Cancel Order'
      }
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log(result);
      if (result) {
        //get updated data after save quote price
        const getDetailsByOrderIdUrl = SpsUtility.urlParams.getDetailsByOrderIdUrl.url + 'orderId=' + this.data.message.orderId;
        this.commonService.getAPIResponse(getDetailsByOrderIdUrl, null, SpsUtility.urlParams.getDetailsByOrderIdUrl.type).subscribe((getDetailsByOrderIdResponse: any) => {
          // SpsUtility.commonStaticObject.specialServiceResponse = specialServiceResponse;
          this.selectedOrderDetails = getDetailsByOrderIdResponse;
          console.log("getDetailsByOrderIdResponse ", getDetailsByOrderIdResponse);
        });
      }
    });

  }

  sendMailToCustomer() {
    const date = new Date();
    date.setHours(date.getHours() + 24);
    console.log(this.agentObj);
    console.log(this.customerObj);    
    const countrycode = SpsUtility.userDetails.countryInfo.ctryCd;
    console.log(("https://tlxbeba0042.emea.fedex.com/spsfecustomer/?code="+this.selectedOrderDetails.orderNo+"&ctry="+countrycode+"&status=accepted").toString());
    console.log(("https://tlxbeba0042.emea.fedex.com/spsfecustomer/?code="+this.selectedOrderDetails.orderNo+"&ctry="+countrycode+"&status=accepted").toString());
    console.log(`countrycode = ${countrycode}`);
    //send mail    
    const sendMailObj = {
      "To": {
        "Address": "mohan.ramegowda.osv@fedex.com", //this.customerObj[0].customerEmail,
        "SubscriberKey": "mohan.ramegowda.osv@fedex.com", //this.customerObj[0].customerEmail,
        "ContactAttributes": {
          "SubscriberAttributes": {
            "OFFEREMAIL_SUBJECT": "FedEx Special Services Shipment Quote",
            "OFFERVALIDITY_TIME": "24:00 Hours",
            "LOCAL_PERCOUNTRY_TEL_NBR": this.agentObj[0].SpS_Telephone,
            "FROM_COUNTRY": this.selectedOrderDetails.fromCountry,
            "TO_COUNTRY": this.selectedOrderDetails.toCountry,
            "ORDER_NUMBER": this.selectedOrderDetails.orderNo,
            "COLLECTION_ADDRESS": this.selectedOrderDetails.fromAddress,
            "DELIVERY_ADDRESS": this.selectedOrderDetails.deliveryAddress,
            "GROSS_VOLUME": this.selectedOrderDetails.volume + "m³",
            "GROSS_WEIGHT": this.selectedOrderDetails.grossWeight + " kg",
            "NUMBER_OF_PACKAGES": this.selectedOrderDetails.packages.length + " pieces",
            "TOTAL_RATE": "$ " + this.selectedOrderDetails.quotedPrice.toFixed(2),
            "PERKG_RATE": "$ " + (this.selectedOrderDetails.quotedPrice / this.selectedOrderDetails.grossWeight).toFixed(2) + "/kg",
            "COLLECTION_DATE": this.selectedOrderDetails.picupDate,
            "FEDEX_PRODUCT_CODE": this.selectedOrderDetails.fedExServiceName,
            "VALID_UNTIL": this.commonService.formatDateTime(date, 'YYYY-MM-DD hh:mm'),
            "PERCOUNTRY_EMAIL_ID": this.agentObj[0].Email_ID,
            "AGENT_NAME": SpsUtility.userDetails.usrFstNm + " " + SpsUtility.userDetails.usrLstNm,
            "CUSTOMER_EMAIL": "mohan.ramegowda.osv@fedex.com", //this.customerObj[0].customerEmail,
            "TERMSC_PER_COUNTRY_LINK": this.agentObj[0].Conditions,
            "ACCEPT_LP_URL": ("https://tlxbeba0042.emea.fedex.com/spsfecustomer/?code="+this.selectedOrderDetails.orderNo+"&ctry="+countrycode+"&status=accepted").toString(),
            "DECLINE_LP_URL": ("https://tlxbeba0042.emea.fedex.com/spsfecustomer/?code="+this.selectedOrderDetails.orderNo+"&ctry="+countrycode+"&status=declined").toString()
          }
        }
      },
      "OPTIONS": {
        "RequestType": "SYNC"
      }

    }

    console.log(sendMailObj);
    const custOfferMailUrl = SpsUtility.urlParams.custMailUrl.url;
    this.commonService.getAPIResponse(custOfferMailUrl, sendMailObj, SpsUtility.urlParams.custMailUrl.type).subscribe((getMailResponse: any) => {
      // SpsUtility.commonStaticObject.specialServiceResponse = specialServiceResponse;      
      console.log("getMailResponse ", getMailResponse);
      if (getMailResponse.responses[0].messages[0] == "Queued") {
        this.commonService.showNotifier("Email sent Successfully.", 'success');

        //change status to "SENT TO CUSTOMER"
        const saveQuoteStatusUrl = SpsUtility.urlParams.saveQuotePriceUrl.url;
        const saveQuoteStatusObject = {
          "requestId": this.data.message.requestId,
          "orderId": this.data.message.orderId,
          "status": "SENT TO CUSTOMER"
        };
        this.commonService.getAPIResponse(saveQuoteStatusUrl, saveQuoteStatusObject, SpsUtility.urlParams.saveQuotePriceUrl.type).subscribe((saveQuoteStatusResponse: any) => {
          // SpsUtility.commonStaticObject.specialServiceResponse = specialServiceResponse;        
          console.log("saveQuoteStatusResponse ", saveQuoteStatusResponse);
          this.dialogRef.close(true);
        });

      }
    }, (error) => {
      this.commonService.showNotifier("Error while sending Email. Please,Send again.", 'error');
    });

  }

  //quote price confirm popup
  onSaveQPrice(price) {
    //open dialog
    const dialogRef = this.dialog.open(confirmDialog, {
      disableClose: true,
      height: '200px',
      width: '500px',
      data: {
        value: price,
        requestId: this.data.message.requestId,
        orderId: this.data.message.orderId,
        title: 'Quote Price'
        // sendToCustomerValue :(row.status == 'QUOTED' || row.status == 'SENT TO CUSTOMER')  ? true : false 
      }
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log(result);
      if (result) {
        this.QPriceVisibility = true;
        //get updated data after save quote price
        const getDetailsByOrderIdUrl = SpsUtility.urlParams.getDetailsByOrderIdUrl.url + 'orderId=' + this.data.message.orderId;
        this.commonService.getAPIResponse(getDetailsByOrderIdUrl, null, SpsUtility.urlParams.getDetailsByOrderIdUrl.type).subscribe((getDetailsByOrderIdResponse: any) => {
          // SpsUtility.commonStaticObject.specialServiceResponse = specialServiceResponse;
          this.selectedOrderDetails = getDetailsByOrderIdResponse;
          console.log("getDetailsByOrderIdResponse ", getDetailsByOrderIdResponse);
        });
        this.price = '';
      }
    });
  }


  getQuote(){
 
    this.dialogRef.close(true);
    console.log("getQuote....... ");

    //get customer and order inforamtion by req id
    const getCustOrderInfoByQuotePriceUrl = SpsUtility.urlParams.getCustOrderInfoByQuoteUrl.url + 'orderId=' + this.data.message.orderId ;
    this.commonService.getAPIResponse(getCustOrderInfoByQuotePriceUrl, null, SpsUtility.urlParams.getCustOrderInfoByQuoteUrl.type).subscribe((getCustOrderResponse: any) => {
        console.log("getCustOrderResponse ", getCustOrderResponse);
        SpsUtility.commonStaticObject.manageToShipmentDetails = getCustOrderResponse ; 

        this.commonService.showNotifier("QuotePrice saved Successfully.", 'success');

        // if (getCustOrderResponse == "OPEN") {
        
  
        //   //change status to "SENT TO CUSTOMER"
        //   const saveQuoteStatusUrl = SpsUtility.urlParams.saveQuotePriceUrl.url;
        //   const saveQuoteStatusObject = {
        //    // "requestId": this.data.message.requestId,
        //     "orderId": this.data.message.orderId,
        //     "status": "QUOTED"
        //   };
        //   this.commonService.getAPIResponse(saveQuoteStatusUrl, saveQuoteStatusObject, SpsUtility.urlParams.saveQuotePriceUrl.type).subscribe((saveQuoteStatusResponse: any) => {
        //     // SpsUtility.commonStaticObject.specialServiceResponse = specialServiceResponse;        
        //     console.log("saveQuoteStatusResponse ", saveQuoteStatusResponse);
        //     this.dialogRef.close(true);
        //   });
  
        // }

       // this.router.navigate(['/shipment'], { queryParams: { route: 'manage' }, skipLocationChange: true });
        // this.router.navigate(['/manage'], { queryParams: {route : 'manage'} , skipLocationChange: true});
    });
  }



  //clear quote price
  clearprice() {
    const saveQuotePriceUrl = SpsUtility.urlParams.saveQuotePriceUrl.url;
    const saveQuotePriceObject = {
      "requestId": this.data.message.requestId,
      "orderId": this.data.message.orderId,
      "price": 0
    };
    this.commonService.getAPIResponse(saveQuotePriceUrl, saveQuotePriceObject, SpsUtility.urlParams.saveQuotePriceUrl.type).subscribe((saveQuotePriceResponse: any) => {
      // SpsUtility.commonStaticObject.specialServiceResponse = specialServiceResponse;        
      console.log("saveQuotePriceResponse ", saveQuotePriceResponse);
      if (saveQuotePriceResponse.price == 0) {
        this.commonService.showNotifier("Quote Price is saved Successfully.", 'success');
        this.dialogRef.close(true);
      }
    });
  }

  //Cannote number confirm popup
  onSaveCNumber(number) {
    //open dialog
    const dialogRef = this.dialog.open(confirmDialog, {
      disableClose: true,
      height: '200px',
      width: '500px',
      data: {
        value: number,
        requestId: this.data.message.requestId,
        orderId: this.data.message.orderId,
        title: 'Connote Number',
        // sendToCustomerValue :(row.status == 'QUOTED' || row.status == 'SENT TO CUSTOMER')  ? true : false 
      }
    });

    dialogRef.afterClosed().subscribe(result => {
      console.log(result);
      if (result) {
        this.CNumberVisibility = true;
        //get updated data after save quote price
        const getDetailsByOrderIdUrl = SpsUtility.urlParams.getDetailsByOrderIdUrl.url + 'orderId=' + this.data.message.orderId;
        this.commonService.getAPIResponse(getDetailsByOrderIdUrl, null, SpsUtility.urlParams.getDetailsByOrderIdUrl.type).subscribe((getDetailsByOrderIdResponse: any) => {
          // SpsUtility.commonStaticObject.specialServiceResponse = specialServiceResponse;
          this.selectedOrderDetails = getDetailsByOrderIdResponse;
          console.log("getDetailsByOrderIdResponse ", getDetailsByOrderIdResponse);
        });
        this.cNumber = '';
      }
    });
  }

  close() {
    this.dialogRef.close(true);
  }

}