import { Component, OnInit } from '@angular/core';
import { CommonService } from '../app/common/common.service';
import { SpsUtility } from './common/SpsUtility';
import { Idle, DEFAULT_INTERRUPTSOURCES } from '@ng-idle/core';
import { Keepalive } from '@ng-idle/keepalive';
import { Router, ActivatedRoute } from '@angular/router';
import { RolesAndActionsService } from './common/roles-actions.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {

  activate: Boolean = true;
  idleState = 'Not started.';
  timedOut = false;
  lastPing?: Date = null;
  roles = [{ name: "", path: "/" }];
  actions = [];
  roleName = '';
  roleUser = '';
  countryAccessDetails: any;
  isSalesManager: any;

  constructor(private commonService: CommonService, private idle: Idle,
    public rolesServices: RolesAndActionsService,
    private keepalive: Keepalive, private router: Router,
    private activatedRoute: ActivatedRoute) {
    this.getLoginDetails();
    // sets an idle timeout of 1800 seconds (30min)
    idle.setIdle(1800);
    // sets a timeout period of 5 seconds. after 1805 seconds of inactivity, the user will be considered timed out.
    idle.setTimeout(5);
    // sets the default interrupts, in this case, things like clicks, scrolls, touches to the document
    idle.setInterrupts(DEFAULT_INTERRUPTSOURCES);
    idle.onIdleEnd.subscribe(() => this.idleState = 'No longer idle.');
    idle.onTimeout.subscribe(() => {

      this.idleState = 'Timed out!';
      this.timedOut = true;
      this.logOut()
    });
    idle.onIdleStart.subscribe(() => this.logOut());
    idle.onTimeoutWarning.subscribe((countdown) => console.log('You will time out in ' + countdown + ' seconds!'));
    // sets the ping interval to 15 seconds
    keepalive.interval(15);
    keepalive.onPing.subscribe(() => this.lastPing = new Date());
    this.reset();
  }

  ngOnInit() {
  }
  computeURL() {
    const path = SpsUtility.getLocalStorageItem('DATA');
    SpsUtility.setLocalStorageItem('DATA', '');
    // Check for URL
    if (path && path.indexOf('?') > 1) {
      const params = this.getParams(path);
      if (params['page'] && params['page'] === 'activity') {
        this.router.navigate([params['page'], params['feed'], params['ctry']]);
      }
    } else {
      if (SpsUtility.redirection) {
        this.router.navigate([SpsUtility.redirection]);
        SpsUtility.redirection = '';
      }
    }
  }

  getParams(url) {
    const params = {};
    const parser = document.createElement('a');
    parser.href = url;
    const query = parser.search.substring(1);
    const vars = query.split('&');
    for (let i = 0; i < vars.length; i++) {
      const pair = vars[i].split('=');
      params[pair[0]] = decodeURIComponent(pair[1]);
    }
    return params;
  }

  reset() {
    this.idle.watch();
    this.idleState = 'Started.';
    this.timedOut = false;
  }

  getLoginDetails() {
    // const url = SpsUtility.urlParams.userServiceBaseUrl.url + SpsUtility.urlParams.wssoLoginHdr.url;
    const loginUrl = SpsUtility.urlParams.loginUrl.url;
    //  const loginUrl = 'https://knight.emea.fedex.com/sps/user/v1/profile/signeduser/';    
    this.commonService.getHttpLoginResponse(loginUrl).subscribe((response: any) => {
      SpsUtility.userDetails = response;
      if (response) {
        //const authrizeURL = 'https://devsso.secure.fedex.com/qp/qaas/authorize/user/' + response.id;
        this.activate = true;
        let userObj =
        {
          "usrWssoId": response.id,
          "usrFstNm": response.firstName,
          "usrLstNm": response.lastName,
          "usrAbbrn": "",
          "usrDesktopPh": response.telephoneNumber,
          "usrEmail": response.email.toLowerCase(),
          "usrCrteById": response.id,
          "usrMdfyById": response.id,
          "countryInfo": {
            "ctryNm": response.internationalcountry.toUpperCase(),
            "ctryCd": response.countryCode
          },
          "usrDeptNm": response.departmentname,
          "usrTitle": response.title
        }
        this.rolesServices.procesRolesAndActions(response);
        SpsUtility.userDetails = userObj;
        $(document).trigger('user-obj');
        const consumerURL = SpsUtility.urlParams.saveUserUrl.url
        this.commonService.getAPIResponse(consumerURL, userObj, SpsUtility.urlParams.saveUserUrl.type)
        .subscribe((consumerResponse: any) => {
          SpsUtility.countryList = consumerResponse.countriesList;
          SpsUtility.userInfo = consumerResponse;
        });

      } else {
        this.activate = false;
      }
    },
      (error) => {
        if (error && error.toString().indexOf('Error: 401') > -1) {
          this.activate = false;
        }
        console.log(error);
        this.activate = false;
      });
  }
  logOut() {
    this.commonService.logoutSPS();
  }
}
