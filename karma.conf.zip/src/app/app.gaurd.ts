import { Injectable } from '@angular/core';
import { CanActivateChild, ActivatedRouteSnapshot, RouterStateSnapshot, Router } from '@angular/router';
import { SpsUtility } from './common/SpsUtility';
import { CommonService } from './common/common.service'
@Injectable({
    providedIn: 'root',
})
export class AuthGuard implements CanActivateChild {
    constructor(private router: Router, private commonService : CommonService) { }
    canActivateChild(
        next: ActivatedRouteSnapshot,
        state: RouterStateSnapshot): boolean {
        const url: string = state.url;
        var res =  this.checkLogin(url);  
        console.log("state...",state);
        return res;
        
    }

    // && Object.keys(SpsUtility.loggedInCountryDetails).length !== 0 && SpsUtility.loggedInCountryDetails.constructor === Object
    checkLogin(url) {
      //  let accessibleRoles = this.checkPermission(url);
       // console.log("accessibleRoles... ",accessibleRoles);
        if (Object.keys(SpsUtility.userDetails).length !== 0 && SpsUtility.userDetails.constructor === Object
           ) {
            return true;
        } else {
            SpsUtility.redirection = url;
            this.commonService.showNotifier("You are not a Authorized user to go","error");
            return false;
        }
    }

    checkPermission(url){
        let roles = SpsUtility.commonStaticObject.accessibleRoles;
        let checkPath ;
        console.log("roles",roles);        

        roles.forEach(role => {
            if(role.path == url)
                checkPath = true; })

        if(checkPath == true) return true
        else return false;      
}
}