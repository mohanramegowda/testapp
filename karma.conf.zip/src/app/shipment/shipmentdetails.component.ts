import { Component, OnInit, AfterViewInit, ViewChild, ElementRef, ViewChildren, QueryList } from '@angular/core';
import { CommonService } from '../common/common.service';
import { NestedTreeControl } from '@angular/cdk/tree';
import { MatTreeNestedDataSource } from '@angular/material/tree';
import { MatDialog, MatStepper } from '@angular/material';
import { Router, ActivatedRoute } from '@angular/router';
import { FormControl, Validator, FormGroup, FormBuilder, Validators } from '@angular/forms';

import { DynamicFormComponent } from 'app/components/dyn-forms/dynamic-form/dynamic-form.component';
import { COMMA, ENTER } from '@angular/cdk/keycodes';
import { MatAutocompleteSelectedEvent, MatChipInputEvent, MatAutocomplete, MatExpansionPanel } from '@angular/material';
import { Observable } from 'rxjs';
import { map, startWith } from 'rxjs/operators';
import { SpsUtility } from '../common/SpsUtility';
import { FieldConfig } from 'app/components/dyn-forms/field.interface';
import { customerConfig } from './customerConfig'
import { FromAddressDialog } from './fromAddress/fromAddressDialog'
import { ToAddressDialog } from './toAddress/toAddressDialog'
import { DatePipe } from '@angular/common';
import { OrderCreationDialog } from './orderCreated/orderCreationDialog'
import { forEach } from '@angular/router/src/utils/collection';
import { RolesAndActionsService } from 'app/common/roles-actions.service';

declare var $: any;
interface FoodNode {
    name: string;
    style?: string;
    children?: FoodNode[];
}

@Component({
    selector: 'app-shipmentdetails',
    templateUrl: './shipmentdetails.component.html',
    styleUrls: ['./shipmentdetails.component.scss']
})
export class ShipmentdetailsComponent implements AfterViewInit {

    @ViewChild(DynamicFormComponent) form: DynamicFormComponent;
    @ViewChild('genModal')
    genModal: any;
    @ViewChild('timeModal')
    timeModal: any;
    showCustomerInvoice: boolean = false;
    showCustomerInvoiceDate: boolean = false;
    @ViewChild('stepper')
    stepper: MatStepper;
    cvselected = 'aircharter';
    filter: any = '';
    filterLevel: any = '';
    showResult = false;
    showonecustomer: boolean = false;
    dialogRef: any;
    canUdate: boolean;
    treeControl = new NestedTreeControl<FoodNode>(node => node.children);
    dataSource = new MatTreeNestedDataSource<FoodNode>();
    deliveryTime: any;
    collectionTime: any;
    visible = true;
    selectable = true;
    removable = true;
    addOnBlur = true;
    separatorKeysCodes: number[] = [ENTER, COMMA];
    fruitCtrl = new FormControl();
    filteredFruits: Observable<string[]>;
    fruits: string[] = ['Netherlands'];
    allFruits: string[] = ['Great Britain', 'Germany', 'Netherlands', 'Belgium', 'Austria'];
    tiles: any = [
        { text: 'Two', cols: 1, rows: 2, color: '#ab70b7' },
        { text: 'One', cols: 3, rows: 2, color: '#ffd7b5' },
    ]
    dropdownDisc = 8;
    changeDisc = [8, 8, 8, 8, 8];
    qualityType = 'Shipments';
    imperial_val: boolean = false;
    selectedStatus = 'PreApproved';
    discArr = { 59: '#ffffff', 60: '#FFBF00', 70: '#CD5C5C' };
    discStyle = ['#ffffff', '#ffffff', '#ffffff', '#ffffff', '#ffffff'];
    discType = 1;
    addcustomers: boolean = false;
    errNotification = 'Pre Approved';
    @ViewChild('fruitInput') fruitInput: ElementRef<HTMLInputElement>;
    @ViewChild('auto') matAutocomplete: MatAutocomplete;
    showcusquotebookingscnd: boolean = false;
    showcusquotebookingfirst: boolean = false;
    showcusquotefirst: boolean = false;
    showcusquotescnd: boolean = false;
    someDate: Date = new Date;
    deliveryFromTimeVal: boolean = false;
    deliveryToTimeVal: boolean = false;
    collectionFromTimeVal: boolean = false;
    collectionToTimeVal: boolean = false;
    collectionTimeVal: boolean = false;
    collectionFromTime_minutes; collectionToTime_minutes;
    collectionTimeValidation: boolean = true;
    displayLoader: boolean = false;
    unitDisabledFlag: boolean = false;
    previousRoute: string; reqIddata;
    orderbyReqData;

    formGroups = { customer: null, shipmentForm: null, collectionAddressFormFields: null, deliveryAddressToFields: null };
    custDynamicConfig: FieldConfig[] = [];
    fieldConfigMap: any = {};
    fromAddressDetails; toAddressDetails;
    FromAddressDynamicConfig: FieldConfig[] = [];
    ToAddressDynamicConfig: FieldConfig[] = [];
    addressErrorMessage = ''; deliveryTimeErrorMessage = '';
    fullPath; specialityList; TNTList;
    productTypeList; packageTypeList; reqId;
    dangerousLevelList; myFilter;
    packgeDetails = [];
    total = { "packages": 1, "volume": 0, "weight": 0 };
    pckgDiv_visibility: boolean = false;
    package_index: number = 1; updatePckgIndex;
    del_pckgs_set = new Set(); pckgError: boolean = false; deletepckFuncall: string; deletingpck;
    Unitselection: string;
    UpdatedIndex; editIconVisibility: boolean = false; deleteIconVisibility: boolean = true;
    lasteditedIndex; startDate: Date = new Date(); savebtnDisabled: boolean;
    customerPanelOpen: boolean = true; fromToAddressFlag: boolean = false;
    orderCreationReqObj; orderId;
    shipmentFromAddress = {
        "custFstNm": "",
        "custCoNm": "",
        "custAddr": "",
        "custCty": "",
        "custprov": "",
        "country": "",
        "custPstlCd": ""
    };
    shipmentToAddress = {
        "custFstNm": "",
        "custCoNm": "",
        "custAddr": "",
        "custCty": "",
        "custprov": "",
        "country": "",
        "custPstlCd": ""
    };

    shipmentObject = {
        "specialityselected": "",
        "specialityselectedId": "",
        "TNTselected": "",
        "TNTselectedId": "",
        "TNTselectedcode": "",
        "collectionAddr": "",
        "deliveryAddr": "",
        "collectionContactName": "",
        "collectionContactNo": "",
        "collectionDate": "",
        "collectionFromTime": "",
        "collectionToTime": "",
        "receiverContactName": "",
        "receiverContactNo": "",
        "deliveryFromDate": "",
        "deliveryToDate": "",
        "deliveryFromTime": "",
        "deliveryToTime": ""
    };
    orderObject = {
        "goodsDescription": "",
        "shippingInstructions": "",
        "dryIce": false,
        "customClear": false,
        "CPLIndicator": false,
        "stackable": false,
        "awkward": false,
        "dangerousGoods": false,
        "packageselected": "",
        "productselected": "",
        "dangerousselected": "",
        "UN_NRselected": "",
        "custRef": ""
    }

    customerDetailsData = {
        "custId": "",
        "custFstNm": "",
        "custLstNm": "",
        "custCoNm": "",
        "custVatNbr": 0,
        "custAddr": "",
        "custAptSteName": "",
        "custPstlCd": "",
        "custCty": "",
        "custSt": "",
        "countryId": 0,
        "custPh": "",
        "custPhExt": "",
        "custMail": "",
        "custStatNbr": 0,
        "custCrtBy": 0,
        "userId": 0,
        "custLstMdfyBy": 0,
        "countryInfo": {
            "ctryId": 0,
            "ctryName": "",
            "ctryCd": "",
            "glPlusEan": "",
            "isActId": 0,
            "createdByid": 0,
            "createdDt": "",
            "lastModifiedById": 0,
            "lastModifiedDt": ""
        },
        "fedExCustomer": false,
        "qpFedExCustomer": false,
        "accountStatus": "",
        "creditLimit": 0,
        "languageCode": "",
        "creditStatus": "",
        "allowQuoteCreation": false,
        "newCustomer": false
    };
    customerDetails = this.customerDetailsData;
    addressErrorMessage2: string;
    addressErrorMessage1: string;
    deliveryFromTime_minutes: number;
    deliveryTimeValidation: boolean;
    deliveryToTime_minutes: number;

    constructor(private commonService: CommonService, private dialog: MatDialog, private router: Router,
        private rolesAndActionsService: RolesAndActionsService,
        private formBuilder: FormBuilder, private datePipe: DatePipe, private activatedRoute: ActivatedRoute) {

        this.activatedRoute.queryParams.subscribe(params => {
            this.previousRoute = params['route'];

        });




    }

    ngOnInit(): void {
        if (!(this.previousRoute == 'customer' || this.previousRoute == 'manage')) {
            this.router.navigate(['/']);
        }

        // this.reqId = 101;
        this.collectionFromTime_minutes = 0;
        this.collectionToTime_minutes = 0;

        //   this.formGroups.customer = this.generateTariffService.buildField(this.screenConfig.customerDetail, availableObject.custDetail);
        this.fullPath = SpsUtility.fullOriginPath + window.location.pathname;
        this.canUdate = this.rolesAndActionsService.CanUpdateOrderInManage();
        //shipment form
        this.formGroups.shipmentForm = this.formBuilder.group({
            weight: ['', [Validators.required]],
            length: ['', Validators.required],
            width: ['', Validators.required],
            height: ['', Validators.required]
        });

        this.updatePckgIndex = this.package_index;
        this.formGroups.shipmentForm.value['pckgDiv_visibility'] = false;


        this.productTypeList = [{ "name": "Document", "value": "D" },
        { "name": "Non-Document", "value": "N" }];
        this.packageTypeList = [{ "name": "Bag", "value": "1" },
        { "name": "Box", "value": "2" }];
        this.dangerousLevelList = [{ "name": "Highly Dangerous", "value": "1" },
        { "name": "Medium Dangerous", "value": "2" },
        { "name": "Low Dangerous", "value": "3" },
        { "name": "Non Dangerous", "value": "0" }];


        //set reqid based on route
        if (this.previousRoute == 'customer') {
            this.reqId = SpsUtility.commonStaticObject.callerResponse.reqId;
            this.customerDetails = SpsUtility.commonStaticObject.customerDetails;


            //set shipment collection address
            this.shipmentFromAddress.custFstNm = this.customerDetails.custFstNm ? this.customerDetails.custFstNm : '';
            this.shipmentFromAddress.custCoNm = this.customerDetails.custCoNm ? this.customerDetails.custCoNm : '';
            this.shipmentFromAddress.custAddr = this.customerDetails.custAddr ? this.customerDetails.custAddr : '';
            this.shipmentFromAddress.custCty = this.customerDetails.custCty ? this.customerDetails.custCty : '';
            this.shipmentFromAddress.country = this.customerDetails.countryInfo.ctryName ? this.customerDetails.countryInfo.ctryName : '';
            this.shipmentFromAddress.custPstlCd = this.customerDetails.custPstlCd ? this.customerDetails.custPstlCd : '';
            // this.shipmentFromAddress.custCoNm = this.orderbyReqData.quote. ;
            //this.shipmentFromAddress.custprov = this.customerDetails.custFstNm ? this.customerDetails.custFstNm : '';
            SpsUtility.commonStaticObject.fromAddress = this.shipmentFromAddress;

            // this.shipmentFromAddress = this.customerDetails;
            this.shipmentFromAddress['country'] = this.customerDetails.countryInfo.ctryName;

            //Customer details form config
            const cofigJSON = JSON.parse(JSON.stringify(customerConfig.config.customerDetailsForm));
            this.formGroups.customer = this.buildField(cofigJSON, this.customerDetails);

            this.custDynamicConfig = this.formGroups.customer.fieldsConfig;

            this.shipmentObject.collectionAddr = this.customerDetails.custAddr + ', ' + this.customerDetails.custCty + ', ' + this.customerDetails.countryInfo.ctryName + ', ' + this.customerDetails.custPstlCd;
            SpsUtility.commonStaticObject.fromAddress = this.customerDetails;
            this.formGroups.collectionAddressFormFields = this.formGroups.customer.value;
            this.formGroups.deliveryAddressToFields = null;

            this.packgeDetails.push({ "id": this.package_index++, "value": this.formGroups.shipmentForm.value });
            this.Unitselection = "mtrc";

        } else if (this.previousRoute == 'manage') {
            this.reqId = SpsUtility.commonStaticObject.manageToShipmentDetails.quote.reqId;
            this.orderbyReqData = SpsUtility.commonStaticObject.manageToShipmentDetails;

            this.customerDetails = {
                "custId": "",
                "custFstNm": this.orderbyReqData.customerInfo.customerName,
                "custLstNm": "",
                "custCoNm": "",
                "custVatNbr": 0,
                "custAddr": this.orderbyReqData.customerInfo.customerAddress,
                "custAptSteName": "",
                "custPstlCd": this.orderbyReqData.customerInfo.customerPostCode,
                "custCty": this.orderbyReqData.customerInfo.customerCity,
                "custSt": "",
                "countryId": 0,
                "custPh": this.orderbyReqData.customerInfo.customerTelNo,
                "custPhExt": "",
                "custMail": this.orderbyReqData.customerInfo.customerEmail,
                "custStatNbr": 0,
                "custCrtBy": 0,
                "userId": 0,
                "custLstMdfyBy": 0,
                "countryInfo": {
                    "ctryId": 0,
                    "ctryName": this.orderbyReqData.customerInfo.countryInfo.ctryName,
                    "ctryCd": this.orderbyReqData.customerInfo.countryInfo.ctryCd,
                    "glPlusEan": "",
                    "isActId": 0,
                    "createdByid": 0,
                    "createdDt": "",
                    "lastModifiedById": 0,
                    "lastModifiedDt": ""
                },
                "fedExCustomer": false,
                "qpFedExCustomer": false,
                "accountStatus": "",
                "creditLimit": 0,
                "languageCode": "",
                "creditStatus": "",
                "allowQuoteCreation": false,
                "newCustomer": false
            };

            this.shipmentObject = {
                "specialityselected": this.orderbyReqData.quote.fedExServiceName,
                "specialityselectedId": this.orderbyReqData.quote.fedExServiceId,
                "TNTselected": this.orderbyReqData.quote.tntServiceName,
                "TNTselectedId": this.orderbyReqData.quote.tntServiceId,
                "TNTselectedcode": this.orderbyReqData.quote.tntServiceCd,
                "collectionAddr": this.orderbyReqData.quote.fromAddress + ', ' + this.orderbyReqData.quote.fromTown + ', ' + this.orderbyReqData.quote.fromCountry + ', ' + this.orderbyReqData.quote.fromPostCode,
                "deliveryAddr": this.orderbyReqData.quote.deliveryAddress + ', ' + this.orderbyReqData.quote.deliveryTown + ', ' + this.orderbyReqData.quote.toCountry + ', ' + this.orderbyReqData.quote.deliveryPostCode,
                "collectionContactName": this.orderbyReqData.quote.senderName ? this.orderbyReqData.quote.senderName : 'vipul',
                "collectionContactNo": this.orderbyReqData.quote.collectionTelephone ? this.orderbyReqData.quote.collectionTelephone : '2213234324',
                "collectionDate": this.orderbyReqData.quote.picupDate,
                "collectionFromTime": this.commonService.formatDateTime(this.orderbyReqData.quote.collectionFromTime, 'hh:mm'),
                "collectionToTime": this.commonService.formatDateTime(this.orderbyReqData.quote.collectionToTime, 'hh:mm'),
                "receiverContactName": this.orderbyReqData.quote.receiverName,
                "receiverContactNo": this.orderbyReqData.quote.deliveryTelephone,
                "deliveryFromDate": this.orderbyReqData.quote.deliveryFromDate,
                "deliveryToDate": this.orderbyReqData.quote.deliveryToDate,
                "deliveryFromTime": this.commonService.formatDateTime(this.orderbyReqData.quote.deliveryFromTime, 'hh:mm'),
                "deliveryToTime": this.commonService.formatDateTime(this.orderbyReqData.quote.deliveryToTime, 'hh:mm')
            }

            let danSelected;
            this.dangerousLevelList.forEach(element => {
                if (element.value == this.orderbyReqData.quote.packages[0].pkgDangerousTypeId) {
                    danSelected = element.name;
                }
            });

            this.orderObject = {
                "goodsDescription": this.orderbyReqData.quote.goodsDesc,
                "shippingInstructions": "",
                "dryIce": false,
                "customClear": this.orderbyReqData.quote.customClearance == 'Y' ? true : false,
                "CPLIndicator": false,
                "stackable": this.orderbyReqData.quote.isStackable == 'Y' ? true : false,
                "awkward": false,
                "dangerousGoods": this.orderbyReqData.quote.dangerous == 'Dangerous' ? true : false,
                "packageselected": (this.orderbyReqData.quote.packages[0].pkgTypeId) == 1 ? 'Bag' : 'Box',
                "productselected": "",
                "dangerousselected": danSelected,
                "UN_NRselected": "",
                "custRef": ""
            }

            //Customer details form config
            const cofigJSON = JSON.parse(JSON.stringify(customerConfig.config.customerDetailsForm));
            this.formGroups.customer = this.buildField(cofigJSON, this.customerDetails);

            this.custDynamicConfig = this.formGroups.customer.fieldsConfig;

            // this.formGroups.collectionAddressFormFields = this.formGroups.customer.value;
            this.Unitselection = this.orderbyReqData.quote.packages[0].unitSystemId == 0 ? "mtrc" : "imp";
            //add packgeDetails
            let index = 1;
            this.package_index = this.orderbyReqData.quote.packages.length + 1;
            this.orderbyReqData.quote.packages.forEach(pckg => {
                if (this.orderbyReqData.quote.packages.length == index) {
                    this.packgeDetails.push({
                        id: index++,
                        value: {
                            weight: pckg.pkgWeight,
                            length: pckg.pkgLength,
                            width: pckg.pkgWidth,
                            height: pckg.pkgHeight,
                            pckgDiv_visibility: false
                        }
                    });

                    this.formGroups.shipmentForm.setValue({
                        weight: pckg.pkgWeight,
                        length: pckg.pkgLength,
                        width: pckg.pkgWidth,
                        height: pckg.pkgHeight
                    });


                }
                else {
                    this.packgeDetails.push({
                        id: index++,
                        value: {
                            weight: pckg.pkgWeight,
                            length: pckg.pkgLength,
                            width: pckg.pkgWidth,
                            height: pckg.pkgHeight,
                            pckgDiv_visibility: true
                        }
                    });
                }
            });

            this.total = { "packages": this.orderbyReqData.quote.packages.length, "volume": this.orderbyReqData.quote.volume, "weight": this.orderbyReqData.quote.grossWeight };
            //check for unit selection radio flag based on if any package added                
            if (this.packgeDetails.length > 1) {
                this.unitDisabledFlag = true;
            } else {
                this.unitDisabledFlag = false;
            }

            //set shipment collection address
            this.shipmentFromAddress.custFstNm = this.orderbyReqData.customerInfo.customerName ? this.orderbyReqData.customerInfo.customerName : '';
            this.shipmentFromAddress.custAddr = this.orderbyReqData.quote.fromAddress;
            this.shipmentFromAddress.custCty = this.orderbyReqData.quote.fromTown;
            this.shipmentFromAddress.country = this.orderbyReqData.quote.fromCountry;
            this.shipmentFromAddress.custPstlCd = this.orderbyReqData.quote.fromPostCode;
            // this.shipmentFromAddress.custCoNm = this.orderbyReqData.quote. ;
            this.shipmentFromAddress.custprov = this.orderbyReqData.quote.fromProvince;
            SpsUtility.commonStaticObject.fromAddress = this.shipmentFromAddress;
            SpsUtility.commonStaticObject.fromAddress['countryInfo'] = this.orderbyReqData.quote.fromCountry;

            //set shipment collectin address
            this.shipmentToAddress.custFstNm = this.orderbyReqData.customerInfo.customerName ? this.orderbyReqData.customerInfo.customerName : '';
            this.shipmentToAddress.custAddr = this.orderbyReqData.quote.deliveryAddress;
            this.shipmentToAddress.custCty = this.orderbyReqData.quote.deliveryTown;
            this.shipmentToAddress.country = this.orderbyReqData.quote.toCountry;
            this.shipmentToAddress.custPstlCd = this.orderbyReqData.quote.deliveryPostCode;
            //  this.shipmentToAddress.custCoNm = this.orderbyReqData.quote. ;
            this.shipmentToAddress.custprov = this.orderbyReqData.quote.deliveryProvince;
            SpsUtility.commonStaticObject.toAddress = this.shipmentToAddress;
            SpsUtility.commonStaticObject.toAddress['countryInfo'] = this.orderbyReqData.quote.toCountry;


            //package details 
            let packObject = [];
            this.packgeDetails.forEach(element => {
                let obj = {
                    "requestId": this.reqId,
                    "unitSystemId": (this.Unitselection == "mtrc" ? 0 : 1),
                    "pkgTypeId": this.orderObject.packageselected == 'Bag' ? "1" : "2",
                    "pkgQty": 1,
                    "pkgLength": element.value.length,
                    "pkgWidth": element.value.width,
                    "pkgHeight": element.value.height,
                    "pkgWeight": element.value.weight,
                    "pkgDeclaredValue": 5000.99,
                    "pkgDeclaredCurrencyCd": "RS",
                    "pkgStackable": (this.orderObject.stackable == true ? 1 : 0),
                    // "pkgTiltable": (this.orderObject.tiltable == true ? 1 : 0),
                    "pkgStatusId": 1,
                    "pkgIsDangerous": (this.orderObject.dangerousGoods == true ? 1 : 0),
                    "pkgCustomVal": 50.00,
                    "pkgCommodityDescription": "Commodity Description",
                    "pkgDangerousTypeId": 2
                }
                packObject.push(obj);
            });

            //create order creation object for submit order
            this.orderCreationReqObj = {
                "requestId": this.reqId,
                "collectionCountryCode": this.shipmentFromAddress ? (this.shipmentFromAddress.country ? (this.shipmentFromAddress.country).toUpperCase() : "") : '',
                "collectionAddress": this.shipmentFromAddress ? (this.shipmentFromAddress.custAddr ? this.shipmentFromAddress.custAddr : "") : '',
                "collectionTown": this.shipmentFromAddress ? (this.shipmentFromAddress.custCty ? this.shipmentFromAddress.custCty : "") : '',
                "collectionProvince": this.shipmentFromAddress ? (this.shipmentFromAddress.custprov ? this.shipmentFromAddress.custprov : "") : '',
                "collectionPostCode": this.shipmentFromAddress ? (this.shipmentFromAddress.custPstlCd ? this.shipmentFromAddress.custPstlCd : "") : '',
                "collectionContactName": this.shipmentObject.collectionContactName,
                "collectionTelephone1": this.shipmentObject.collectionContactNo,
                "orderCollectionDate": this.orderbyReqData.quote.picupDate,
                "orderCollectionFromTime": this.orderbyReqData.quote.collectionFromTime,
                "orderCollectionToTime": this.orderbyReqData.quote.collectionToTime,
                "sumOfWeight": this.total.weight,
                "grossWeight": this.total.weight,
                "chargableWeight": this.total.weight,
                "sumOfVolume": this.total.volume,
                "grossVolume": this.total.volume,
                "consignmentQty": this.total.packages,
                "instructions": this.orderObject.shippingInstructions,
                "sumOfDimensionInLength": "20",
                "sumOfDimensionInWidth": "20",
                "sumOfDimensionInHeight": "20",
                "deliveryCountryCode": this.shipmentToAddress.country ? (this.shipmentToAddress.country).toUpperCase() : "",
                "deliveryAddress": this.shipmentToAddress.custAddr ? this.shipmentToAddress.custAddr : " ",
                "deliveryAddress2": this.shipmentToAddress.custAddr ? this.shipmentToAddress.custAddr : " ",
                "deliveryTownName": this.shipmentToAddress.custCty ? this.shipmentToAddress.custCty : " ",
                "deliveryProvince": this.shipmentToAddress.custprov ? this.shipmentToAddress.custprov : " ",
                "deliveryPostCode": this.shipmentToAddress.custPstlCd ? this.shipmentToAddress.custPstlCd : " ",
                "deliveryContactName": this.shipmentObject.receiverContactName,
                "deliveryTelephone": this.shipmentObject.receiverContactNo,
                "deliveryProductType": this.orderObject.productselected ? this.orderObject.productselected : 'N', //change
                "goodsDescription": this.orderObject.goodsDescription,
                "unnr": "unnr",
                "akward": (this.orderObject.awkward == true ? "Y" : "N"),
                "ccIndicator": (this.orderObject.customClear == true ? "Y" : "N"),
                "isStackable": (this.orderObject.stackable == true ? "Y" : "N"),
                "dangerousGoods": (this.orderObject.dangerousGoods == true ? "Dangerous" : "Non"),
                "orderDeliveryFromDate": this.orderbyReqData.quote.deliveryFromDate,
                "orderDeliveryFromTime": this.orderbyReqData.quote.collectionFromTime,
                "orderDeliveryToDate": this.orderbyReqData.quote.deliveryToDate,
                "orderDeliveryToTime": this.orderbyReqData.quote.collectionToTime,
                "userId": SpsUtility.userInfo.usrId,
                "uomWt": "kg",
                "uomVl": "m",
                "collectionCompanyName": this.shipmentFromAddress.custCoNm ? this.shipmentFromAddress.custCoNm : "",
                "deliveryCompanyName": this.shipmentToAddress.custCoNm ? this.shipmentToAddress.custCoNm : "",
                "packingCd": this.orderObject.packageselected == 'Bag' ? "1" : "2",
                "tntMappingCode": this.shipmentObject.TNTselectedcode,
                "serviceTntId": this.shipmentObject.TNTselectedId,
                "packGroupCd": "",
                "senderCountryName": this.orderbyReqData.customerInfo.countryInfo.ctryName ? this.orderbyReqData.customerInfo.countryInfo.ctryName : '',
                "senderCompanyName": this.orderbyReqData.customerInfo.custCoNm ? this.orderbyReqData.customerInfo.custCoNm : '',
                "packageDetails": packObject,
                "fedExEAN": this.customerDetails.custId,
                "customerReferenceNumber": this.orderObject.custRef
            }

        }

        //specialityList
        const contryCode = SpsUtility.userDetails.countryInfo.ctryCd;
        // const contryCode = "IN";
        const specialServiceUrl = `${SpsUtility.urlParams.specialServiceUrl.url}?countryCd=${contryCode}`
        this.commonService.getAPIResponse(specialServiceUrl, null, SpsUtility.urlParams.specialServiceUrl.type).subscribe((specialServiceResponse: any) => {
            this.specialityList = specialServiceResponse;
        });
    }

    ngAfterViewInit() {
        this.formGroups.customer.disable();
        if (this.previousRoute == 'manage') {
            this.stepper.selectedIndex = 1;
        }
    }

    specialityChange(selectedVal) {
        this.shipmentObject.specialityselected = selectedVal.split(',')[0];
        this.shipmentObject.specialityselectedId = selectedVal.split(',')[1];
        // this.shipmentObject.specialityselected = SName;
        const contryCode = SpsUtility.userDetails.countryInfo.ctryCd;
        //const contryCode = "IN";
        const tntspecialServiceUrl = `${SpsUtility.urlParams.tntspecialServiceUrl.url}countryCd=${contryCode}&serviceId=${this.shipmentObject.specialityselectedId}`;
        this.commonService.getAPIResponse(tntspecialServiceUrl, null, SpsUtility.urlParams.tntspecialServiceUrl.type).subscribe((TNTServiceResponse: any) => {
            // SpsUtility.commonStaticObject.TNTServiceResponse = TNTServiceResponse;

            this.fromAddressDetails = SpsUtility.commonStaticObject.fromAddress
            this.toAddressDetails = SpsUtility.commonStaticObject.toAddress
            // this.TNTList = TNTServiceResponse;

            if (SpsUtility.commonStaticObject.fromAddress.countryInfo.ctryName == SpsUtility.commonStaticObject.toAddress.countryInfo) {

                this.TNTList = TNTServiceResponse.filter(flag => flag.domesticFlag === "N");

            } else {

                this.TNTList = TNTServiceResponse.filter(flag => flag.domesticFlag === "Y");
            }
        });
    }

    TNTChange(selectedVal) {
        this.shipmentObject.TNTselected = selectedVal.split(',')[0];
        this.shipmentObject.TNTselectedId = selectedVal.split(',')[1];
        this.shipmentObject.TNTselectedcode = selectedVal.split(',')[2];
    }

    addPacakge(pckg, Unitselection) {
        this.packgeDetails.forEach(pckElement => {
            if (pckElement.id == this.updatePckgIndex) {
                pckElement.value = pckg;
                pckElement.value.pckgDiv_visibility = true;

                this.formGroups.shipmentForm.setValue({
                    weight: "",
                    length: "",
                    width: "",
                    height: ""
                });
                // //update packagedetails list 
                this.updatePckgIndex = this.package_index;
                this.formGroups.shipmentForm.value['pckgDiv_visibility'] = false;
                this.packgeDetails.push({ "id": this.package_index++, "value": this.formGroups.shipmentForm.value });
                this.total.packages = this.packgeDetails.length;
            }
        });


        //check for unit selection radio flag based on if any package added                
        if (this.packgeDetails.length > 1) {
            this.unitDisabledFlag = true;
        } else {
            this.unitDisabledFlag = false;
        }
    }

    weightChange(unit, id) {
        let pckgIndex = this.packgeDetails.findIndex((obj => obj.id == id));

        //update package details after package added
        this.total.weight -= this.packgeDetails[pckgIndex].value.weight;
        this.total.weight += (+ this.formGroups.shipmentForm.value.weight);
        this.packgeDetails[pckgIndex].value.weight = (+ this.formGroups.shipmentForm.value.weight);
    }

    volumeChange(id, unit) {
        let pckgIndex = this.packgeDetails.findIndex((obj => obj.id == id));

        this.total.volume -= (this.packgeDetails[pckgIndex].value.length * this.packgeDetails[pckgIndex].value.width * this.packgeDetails[pckgIndex].value.height);
        this.total.volume += (this.formGroups.shipmentForm.value.length * this.formGroups.shipmentForm.value.width * this.formGroups.shipmentForm.value.height);
        this.packgeDetails[pckgIndex].value.length = (+ this.formGroups.shipmentForm.value.length);
        this.packgeDetails[pckgIndex].value.width = (+ this.formGroups.shipmentForm.value.width);
        this.packgeDetails[pckgIndex].value.height = (+ this.formGroups.shipmentForm.value.height);
    }

    editDone(pckg, Unitselection, indx) {
        //update form visibility
        this.packgeDetails[indx].value = pckg;
        this.packgeDetails[indx].value.pckgDiv_visibility = true;
        // this.packgeDetails[indx].value.Unitselection = Unitselection;
        //edit icon invisible 
        this.editIconVisibility = false;

        //reset last changed form form values 
        this.packgeDetails[this.packgeDetails.length - 1].value.pckgDiv_visibility = false;
        this.formGroups.shipmentForm.setValue({
            // UN_NRselected: this.packgeDetails[this.packgeDetails.length-1].value.UN_NRselected,
            weight: this.packgeDetails[this.packgeDetails.length - 1].value.weight,
            length: this.packgeDetails[this.packgeDetails.length - 1].value.length,
            width: this.packgeDetails[this.packgeDetails.length - 1].value.width,
            height: this.packgeDetails[this.packgeDetails.length - 1].value.height
        });
        // this.Unitselection = this.packgeDetails[this.packgeDetails.length - 1].value.Unitselection;
        this.UpdatedIndex = undefined;

        //reset delete icon visibility once edit is done 
        this.deleteIconVisibility = true;
    }

    editpackage(pckg, index) {
        //stop other delete operations if package is in edit mode by hiding icon 
        this.deleteIconVisibility = false;

        //check if other package is in editing mode then close the existing and open new one as edit mode // editIconVisibility : true => already in editing mode
        if (this.editIconVisibility == true) {
            //check if edited package is last then set visibility of edit and delete icons accordingly
            if (index == this.packgeDetails.length - 1) {
                this.deleteIconVisibility = true;
                this.editIconVisibility = false;
            }

            this.packgeDetails[index].value.pckgDiv_visibility = false;
            this.packgeDetails[this.lasteditedIndex].value = this.formGroups.shipmentForm.value;
            this.packgeDetails[this.lasteditedIndex].value.pckgDiv_visibility = true;
            // this.packgeDetails[this.lasteditedIndex].value.Unitselection = this.Unitselection;

            //reset form values 
            this.formGroups.shipmentForm.setValue({
                weight: pckg.value.weight,
                length: pckg.value.length,
                width: pckg.value.width,
                height: pckg.value.height
            });
            // this.Unitselection = this.packgeDetails[index].value.Unitselection;
            this.lasteditedIndex = index;
            // this.editIconVisibility = false;
        }
        else {
            //click on edit icon 
            this.editIconVisibility = true;
            // if (this.UpdatedIndex == undefined)
            this.UpdatedIndex = this.packgeDetails.length - 1;
            this.lasteditedIndex = index;

            //update form visibility
            this.packgeDetails[index].value.pckgDiv_visibility = false;
            this.packgeDetails[this.UpdatedIndex].value = this.formGroups.shipmentForm.value;
            this.packgeDetails[this.UpdatedIndex].value.pckgDiv_visibility = true;
            // this.packgeDetails[this.UpdatedIndex].value.Unitselection = this.Unitselection;

            //reset form values 
            this.formGroups.shipmentForm.setValue({
                weight: pckg.value.weight,
                length: pckg.value.length,
                width: pckg.value.width,
                height: pckg.value.height
            });
            // this.Unitselection = this.packgeDetails[index].value.Unitselection;
        }
    }

    deleteLastpackage(pckg) {
        if (this.packgeDetails.length > 1) {
            let objIndex = this.packgeDetails.findIndex((obj => obj.id == pckg.id));
            let pkg = this.packgeDetails[objIndex];
            this.packgeDetails.splice(objIndex, 1);

            //update package details after package added           
            this.total.volume -= (this.formGroups.shipmentForm.value.length * this.formGroups.shipmentForm.value.width * this.formGroups.shipmentForm.value.height);
            this.total.weight -= (+ this.formGroups.shipmentForm.value.weight);
            this.total.packages = this.packgeDetails.length;

            this.packgeDetails[this.packgeDetails.length - 1].value.pckgDiv_visibility = false;
            this.updatePckgIndex = this.packgeDetails[this.packgeDetails.length - 1].id;

            //set form value
            this.formGroups.shipmentForm.setValue({
                weight: this.packgeDetails[this.packgeDetails.length - 1].value.weight,
                length: this.packgeDetails[this.packgeDetails.length - 1].value.length,
                width: this.packgeDetails[this.packgeDetails.length - 1].value.width,
                height: this.packgeDetails[this.packgeDetails.length - 1].value.height
            });

            this.pckgError = false;
            $('#dltPkgConfirm').modal('hide');
        }
        else {
            this.pckgError = true;
        }

        //check for unit selection radio flag based on if any package added        
        if (this.packgeDetails.length > 1) {
            this.unitDisabledFlag = true;
        } else {
            this.unitDisabledFlag = false;
        }
    }

    deletepackage(pckg) {
        //update total values and remove elements
        if (this.packgeDetails.length > 1) {
            let objIndex = this.packgeDetails.findIndex((obj => obj.id == pckg.id));
            let pkg = this.packgeDetails[objIndex];
            //remove element
            this.packgeDetails.splice(objIndex, 1);

            //update package details after package added           
            this.total.volume -= (pkg.value.length * pkg.value.width * pkg.value.height);
            this.total.weight -= (+pkg.value.weight);
            this.total.packages = this.packgeDetails.length;



            this.packgeDetails[this.packgeDetails.length - 1].value.pckgDiv_visibility = false;
            this.updatePckgIndex = this.packgeDetails[this.packgeDetails.length - 1].id;

            this.pckgError = false;
            $('#dltPkgConfirm').modal('hide');

        } else {
            this.pckgError = true;
        }

        //check for unit selection radio flag based on if any package added        
        if (this.packgeDetails.length > 1) {
            this.unitDisabledFlag = true;
        } else {
            this.unitDisabledFlag = false;
        }
    }

    deleteDialog(pckg) {
        this.pckgError = false;
        $("#dltPkgConfirm").modal();
        this.deletepckFuncall = "del";
        this.deletingpck = pckg;
    }

    deleteDialogLastPkg(pckg) {
        this.pckgError = false;
        $("#dltPkgConfirm").modal();
        this.deletepckFuncall = "delLast";
        this.deletingpck = pckg;
    }

    saveDetails() {

        if (this.formGroups.collectionAddressFormFields) {
            this.shipmentFromAddress = this.formGroups.collectionAddressFormFields;
            this.shipmentFromAddress['country'] = this.formGroups.collectionAddressFormFields.countryInfo;
        }
        if (this.formGroups.deliveryAddressToFields) {
            this.shipmentToAddress = this.formGroups.deliveryAddressToFields;
            this.shipmentToAddress['country'] = this.formGroups.deliveryAddressToFields.countryInfo;
        }

        this.packgeDetails.forEach(pckElement => {
            if (pckElement.id == this.updatePckgIndex) {
                pckElement.value = this.formGroups.shipmentForm.value;
                pckElement.value.pckgDiv_visibility = false;
            }
        });


        //create request Object for consignment API

        //package details 
        let packObject = [];
        this.packgeDetails.forEach(element => {
            let obj = {
                "requestId": this.reqId,
                "unitSystemId": (this.Unitselection == "mtrc" ? 0 : 1),
                "pkgTypeId": this.orderObject.packageselected,
                "pkgQty": 1,
                "pkgLength": element.value.length,
                "pkgWidth": element.value.width,
                "pkgHeight": element.value.height,
                "pkgWeight": element.value.weight,
                "pkgDeclaredValue": 5000.99,
                "pkgDeclaredCurrencyCd": "RS",
                "pkgStackable": (this.orderObject.stackable == true ? 1 : 0),
                // "pkgTiltable": (this.orderObject.tiltable == true ? 1 : 0),
                "pkgStatusId": 1,
                "pkgIsDangerous": (this.orderObject.dangerousGoods == true ? 1 : 0),
                "pkgCustomVal": 50.00,
                "pkgCommodityDescription": "Commodity Description",
                "pkgDangerousTypeId": 2,
                "uomDims": "M"
            }
            packObject.push(obj);
        });

        //main request Object
        //collection Date
        let collectionDate = this.datePipe.transform(this.shipmentObject.collectionDate, "yyyy-MM-dd");
        //collecion from Time
        let coll_from_hourPart = this.shipmentObject.collectionFromTime.split(' ')[0]
        let coll_from_am_pm = this.shipmentObject.collectionFromTime.split(' ')[1];
        let coll_from_hr = (coll_from_am_pm == 'PM') ? 12 + (+coll_from_hourPart.split(':')[0]) : coll_from_hourPart.split(':')[0];
        let coll_from_time = collectionDate + 'T' + coll_from_hr + ':' + coll_from_hourPart.split(':')[1] + ':00';
        //collecion To Time
        let coll_to_hourPart = this.shipmentObject.collectionToTime.split(' ')[0]
        let coll_to_am_pm = this.shipmentObject.collectionToTime.split(' ')[1];
        let coll_to_hr = (coll_to_am_pm == 'PM') ? 12 + (+coll_to_hourPart.split(':')[0]) : coll_to_hourPart.split(':')[0];
        let coll_to_time = collectionDate + 'T' + coll_to_hr + ':' + coll_to_hourPart.split(':')[1] + ':00';

        //collection Date
        let deliveryFromDate = this.datePipe.transform(this.shipmentObject.deliveryFromDate, "yyyy-MM-dd");
        let deliveryToDate = this.datePipe.transform(this.shipmentObject.deliveryToDate, "yyyy-MM-dd");
        //collecion from Time
        let del_from_hourPart = this.shipmentObject.deliveryFromTime.split(' ')[0]
        let del_from_am_pm = this.shipmentObject.deliveryFromTime.split(' ')[1];
        let del_from_hr = (del_from_am_pm == 'PM') ? 12 + (+del_from_hourPart.split(':')[0]) : del_from_hourPart.split(':')[0];
        let del_from_time = collectionDate + 'T' + del_from_hr + ':' + del_from_hourPart.split(':')[1] + ':00';
        //collecion To Time
        let del_to_hourPart = this.shipmentObject.deliveryToTime.split(' ')[0]
        let del_to_am_pm = this.shipmentObject.deliveryToTime.split(' ')[1];
        let del_to_hr = (del_to_am_pm == 'PM') ? 12 + (+del_to_hourPart.split(':')[0]) : del_to_hourPart.split(':')[0];
        let del_to_time = collectionDate + 'T' + del_to_hr + ':' + del_to_hourPart.split(':')[1] + ':00';



        this.orderCreationReqObj = {
            "akward": (this.orderObject.awkward == true ? "Y" : "N"),
            "ccIndicator": (this.orderObject.customClear == true ? "Y" : "N"),
            "chargableWeight": this.total.weight,
            "collectionAddress": this.shipmentFromAddress ? (this.shipmentFromAddress.custAddr ?
                this.shipmentFromAddress.custAddr : "") : '',
            "collectionContactName": this.shipmentObject.collectionContactName,
            "collectionCountryCode": this.shipmentFromAddress ? (this.shipmentFromAddress.country ?
                (this.shipmentFromAddress.country).toUpperCase() : "") : '',
            "collectionPostCode": this.shipmentFromAddress ? (this.shipmentFromAddress.custPstlCd ?
                this.shipmentFromAddress.custPstlCd : "") : '',
            "collectionProvince": this.shipmentFromAddress ? (this.shipmentFromAddress.custprov ?
                this.shipmentFromAddress.custprov : "") : '',
            "collectionTelephone1": this.shipmentObject.collectionContactNo,
            "collectionTown": this.shipmentFromAddress ? (this.shipmentFromAddress.custCty ? this.shipmentFromAddress.custCty : "") : '',
            "consignmentQty": this.total.packages,
            "dangerousGoods": (this.orderObject.dangerousGoods == true ? "Y" : "N"),
            "deliveryAddress": this.shipmentToAddress.custAddr ? this.shipmentToAddress.custAddr : " ",
            "deliveryAddress2": this.shipmentToAddress.custAddr ? this.shipmentToAddress.custAddr : " ",
            "deliveryContactName": this.shipmentObject.receiverContactName,
            "deliveryCountryCode": this.shipmentToAddress.country ? (this.shipmentToAddress.country).toUpperCase() : "",
            "deliveryPostCode": this.shipmentToAddress.custPstlCd ? this.shipmentToAddress.custPstlCd : " ",
            "deliveryProductType": this.orderObject.productselected,
            "deliveryProvince": this.shipmentToAddress.custprov ? this.shipmentToAddress.custprov : " ",
            "deliveryTelephone": this.shipmentObject.receiverContactNo,
            "deliveryTownName": this.shipmentToAddress.custCty ? this.shipmentToAddress.custCty : " ",
            "goodsDescription": this.orderObject.goodsDescription,
            "grossVolume": this.total.volume,
            "grossWeight": this.total.weight,
            "instructions": this.orderObject.shippingInstructions,
            "isStackable": (this.orderObject.stackable == true ? "Y" : "N"),
            "orderCollectionDate": collectionDate,
            "orderCollectionFromTime": coll_from_time,
            "orderCollectionToTime": coll_to_time,
            "orderDeliveryFromDate": deliveryFromDate,
            "orderDeliveryFromTime": del_from_time,
            "orderDeliveryToDate": deliveryToDate,
            "orderDeliveryToTime": del_to_time,
            "packageDetails": packObject,
            "requestId": this.reqId,
            "sumOfDimensionInHeight": "20",
            "sumOfDimensionInLength": "20",
            "sumOfDimensionInWidth": "20",
            "sumOfVolume": this.total.volume,
            "sumOfWeight": this.total.weight,
            "unnr": "unnr",
            "userId": SpsUtility.userInfo.usrId,
            "uomWt": 'KG',
            "uomVl": 'M3',
            "collectionCompanyName": this.shipmentFromAddress.custCoNm ? this.shipmentFromAddress.custCoNm : "",
            "deliveryCompanyName": this.shipmentToAddress.custCoNm ? this.shipmentToAddress.custCoNm : "",
            "packingCd": this.orderObject.packageselected,
            "tntMappingCode": this.shipmentObject.TNTselectedcode,
            "packGroupCd": "",
            "senderCountryName": this.customerDetails.countryInfo.ctryName ? this.customerDetails.countryInfo.ctryName : this.customerDetails.countryInfo,
            "senderCompanyName": "TEST", // todo remove hard code and assign this.customerDetails.custCoNm,
            "serviceTntId": this.shipmentObject.TNTselectedId,
            "fedExEAN": this.customerDetails.custId,
            "customerReferenceNumber": this.orderObject.custRef,
            "dryIceIn": (this.orderObject.dryIce === true) ? "Y" : "N",
            "shippingInstruction": this.orderObject.shippingInstructions,
            "cplIndicator": (this.orderObject.CPLIndicator === true) ? "Y" : "N"
        }

        //save details at local DB
        this.displayLoader = true;
        const saveconsignmentDetailsUrl = SpsUtility.urlParams.saveconsignmentDetails.url
        this.commonService.getAPIResponse(saveconsignmentDetailsUrl, this.orderCreationReqObj, SpsUtility.urlParams.saveconsignmentDetails.type).subscribe((consignmentDetailsResponse: any) => {
            this.displayLoader = false;
            if (this.reqId == consignmentDetailsResponse.requestId) {
                this.commonService.showNotifier('Consignment Details are saved Successfully.', 'success');
            }

        }, (error) => {
            this.displayLoader = false;
            this.commonService.showNotifier('Thre is an error while saving Consignment Details. Please, Submit again.', 'error');
        });

    }


    submitOrder() {

        //check for package in metric or imperial and change to metric
        let orderObj = JSON.parse(JSON.stringify(this.orderCreationReqObj));
        let totalwt = 0; let totalvlm = 0;

        if (orderObj.packageDetails[0].unitSystemId == 1) {
            orderObj.packageDetails.forEach(pack => {
                pack.pkgWeight = (pack.pkgWeight * 0.4535).toFixed(4);
                pack.pkgLength = (pack.pkgLength * 0.0254).toFixed(4);
                pack.pkgWidth = (pack.pkgWidth * 0.0254).toFixed(4);
                pack.pkgHeight = (pack.pkgHeight * 0.0254).toFixed(4);

                totalwt += (+pack.pkgWeight);
                totalvlm += (+(pack.pkgLength * pack.pkgWidth * pack.pkgHeight));
            });

            orderObj.sumOfWeight = totalwt.toFixed(4);
            orderObj.grossWeight = totalwt.toFixed(4);
            orderObj.chargableWeight = totalwt.toFixed(4);
            orderObj.sumOfVolume = totalvlm.toFixed(4);
            orderObj.grossVolume = totalvlm.toFixed(4);
        }

        //call create consignment API
        this.displayLoader = true;
        const saveconsignmentDetailsToGLServerUrl = SpsUtility.urlParams.saveconsignmentDetailsToGLServer.url
        this.commonService.getAPIResponse(saveconsignmentDetailsToGLServerUrl, orderObj, SpsUtility.urlParams.saveconsignmentDetailsToGLServer.type).subscribe((consignmentDetailsResponseToGL: any) => {
            this.displayLoader = false;
            this.orderId = consignmentDetailsResponseToGL.orderId;
            SpsUtility.commonStaticObject.consignmentDetailsResponseToGL = consignmentDetailsResponseToGL;
            //  this.commonService.showNotifier('Consignment Details are saved Successfully.', 'success');
            this.orderCreationReqObj = {};

            //open dialog
            // SpsUtility.commonStaticObject.orderId =  6379; 
            const dialogRef = this.dialog.open(OrderCreationDialog, {
                disableClose: true,
                height: '300px',
                width: '600px',
                data: {
                    // message: this.customerDetails,
                    buttonText: {
                        ok: 'OK',
                        cancel: 'NO'
                    }
                }
            });

            dialogRef.afterClosed().subscribe(result => {
                SpsUtility.commonStaticObject.consignmentDetailsResponseToGL = {};
                SpsUtility.commonStaticObject.fromAddress = {};
                SpsUtility.commonStaticObject.toAddress = {};


            });

        }, (error) => {
            this.displayLoader = false;
            this.commonService.showNotifier('Thre is an error while saving Consignment Details. Please, Submit again.', 'error');
            //if failed
            //change status to "FAILED"
            const saveFailedStatusUrl = SpsUtility.urlParams.saveQuotePriceUrl.url;
            const saveFailedStatusObject = {
                "requestId": this.reqId,
                "status": "FAILED"
            };
            this.commonService.getAPIResponse(saveFailedStatusUrl, saveFailedStatusObject, SpsUtility.urlParams.saveQuotePriceUrl.type).subscribe((saveFailedStatusObjectResponse: any) => {
            });

        });

    }

    onFormGroupCreate(element) {
        if (this.formGroups && element && element.group) {
            this.formGroups[element.formName] = element.group;
            this.onChanges(element.group);
        }
    }

    onChanges(group) {
        group.valueChanges.subscribe(val => {
            // tslint:disable-next-line: forin
            for (const i in this.formGroups) {
                if (this.formGroups[i] && !this.formGroups[i].valid) {
                    // this.stopStepper = true;
                } else if (this.formGroups[i]) {
                    this.formGroups[i] = group;
                }
            }
        });
    }

    buildField(frmCnfg = null, availableObject) {
        const fieldConfigMap = {};
        const formConfigObj: any = {};
        if (frmCnfg) {
            const config: any = JSON.parse(JSON.stringify(frmCnfg));
            const fieldConfigs: FieldConfig[] = [];
            if (config.fields) {
                config.fields.map((field) => {
                    let elementConfig: FieldConfig;
                    const elementObj: any = {};
                    elementObj.inputType = field.inputType;
                    elementObj.type = field.type;
                    elementObj.label = field.label;
                    elementObj.name = field.name;
                    elementObj.styleClass = field.styleClass;
                    elementObj.styleColor = field.styleColor;
                    elementObj.disabled = field.disabled;
                    elementObj.id = field.id;
                    elementObj.style = field.style;

                    if (field.value) {
                        elementObj.value = field.value;
                    }
                    if (field.options) {
                        elementObj.options = field.options;
                    }

                    // Override the default Value
                    if (availableObject && availableObject[field.name]) {
                        if (field.type === 'select') {
                            elementObj.options = availableObject[field.name].values;
                            elementObj.value = availableObject[field.name].value;
                        } else {
                            elementObj.value = availableObject[field.name];
                        }

                        if (field.type === 'date') {
                            elementObj.dateFilter = availableObject[field.name].dateFilter;
                            if (availableObject[field.name].value) {
                                elementObj.value = availableObject[field.name].value;
                            } else {
                                elementObj.value = availableObject[field.name];
                            }
                        }

                        if (field.label === 'Country') {
                            elementObj.value = availableObject[field.name].ctryName;
                        }

                        if (field.id === 'payer') {
                            $('#payer').css('text-align', 'end');
                        }
                        // elementObj.disabled = !!availableObject[field.name].disabled;
                    }

                    if (field.validations) {
                        let validator: Validator[];
                        const validatorArr = [];
                        field.validations.map((validation) => {
                            const validatorObj: any = {};
                            if (validation.name === 'required') {
                                validatorObj.name = validation.name;
                                validatorObj.validator = Validators.required;
                                validatorObj.message = validation.message;
                            } else if (validation.name === 'pattern') {
                                validatorObj.name = validation.name;
                                validatorObj.validator = Validators.pattern(validation.value);
                                validatorObj.message = validation.message;
                            } else if (validation.name === 'maxlength') {
                                validatorObj.name = validation.name;
                                validatorObj.validator = Validators.maxLength(validation.value);
                                validatorObj.message = validation.message;
                            } else if (validation.name === 'minlength') {
                                validatorObj.name = validation.name;
                                validatorObj.validator = Validators.minLength(validation.value);
                                validatorObj.message = validation.message;
                            }
                            validatorArr.push(validatorObj);
                        });
                        validator = validatorArr;
                        elementObj.validations = validator;
                    }
                    elementConfig = elementObj;
                    fieldConfigs.push(elementConfig);
                });
            }
            formConfigObj.fieldsConfig = fieldConfigs;
            fieldConfigMap[formConfigObj.form_name] = formConfigObj;
        }
        return formConfigObj;
    }

    openFromAddressDialog() {
        //change flag if From address field is cahnged
        this.fromToAddressFlag = false;
        $('#checkAddressButton').css('background-color', '#4d148c');
        let message;
        if (this.previousRoute == 'customer') {
            message = this.customerDetails;
        } else if (this.previousRoute == 'manage') {
            message = this.shipmentFromAddress;
        }


        const dialogRef = this.dialog.open(FromAddressDialog, {
            disableClose: true,
            height: '690px',
            width: '800px',
            data: {
                message: message,
                buttonText: {
                    ok: 'OK',
                    cancel: 'NO'
                }
            }
        });

        dialogRef.afterClosed().subscribe(result => {
            this.shipmentObject.collectionAddr = '';

            if (result == 'close') {
                this.formGroups.collectionAddressFormFields = {};
            }
            else {
                this.formGroups.collectionAddressFormFields = result;

                for (var key in result) {
                    if (result[key] != null && result[key] != '' && result[key] != undefined && key != 'custCoNm') {
                        this.shipmentObject.collectionAddr += result[key] + ',';
                    }
                }
            }
            this.shipmentObject.collectionAddr = this.shipmentObject.collectionAddr.substring(0, this.shipmentObject.collectionAddr.length - 1);

        });

    }

    openToAddressDialog() {
        //change flag if To address field is cahnged
        this.fromToAddressFlag = false;
        $('#checkAddressButton').css('background-color', '#4d148c');

        const dialogRef = this.dialog.open(ToAddressDialog, {
            disableClose: true,
            height: '690px',
            width: '800px',
            data: {
                buttonText: {
                    ok: 'OK',
                    cancel: 'No'
                }
            }
        });

        dialogRef.afterClosed().subscribe(result => {
            this.formGroups.deliveryAddressToFields = result;
            this.shipmentObject.deliveryAddr = '';
            for (var key in result) {
                if (result[key] != null && result[key] != '' && result[key] != undefined && key != 'custCoNm') {
                    this.shipmentObject.deliveryAddr += result[key] + ',';
                }
            }
            this.shipmentObject.deliveryAddr = this.shipmentObject.deliveryAddr.substring(0, this.shipmentObject.deliveryAddr.length - 1);
        });


    }

    //validate collection and deliver address
    checkAddress() {

        if (SpsUtility.commonStaticObject.fromAddress.custPstlCd == '' || SpsUtility.commonStaticObject.fromAddress.custPstlCd == undefined || SpsUtility.commonStaticObject.fromAddress.custPstlCd == null) {
            $('#checkAddressButton').css('background-color', '#4d148c');
            this.addressErrorMessage = 'Please Enter Collection Address Postal Code.';
        } else if (SpsUtility.commonStaticObject.toAddress == undefined) {
            $('#checkAddressButton').css('background-color', '#4d148c');
            this.addressErrorMessage = 'Please Enter Delivery Address Postal Code.';
        }
        else {
            if (SpsUtility.commonStaticObject.toAddress.custPstlCd == '' || SpsUtility.commonStaticObject.toAddress.custPstlCd == undefined || SpsUtility.commonStaticObject.toAddress.custPstlCd == null) {
                $('#checkAddressButton').css('background-color', '#4d148c');
                this.addressErrorMessage = 'Please Enter Delivery Address Postal Code.';
            }
            else {
                this.addressErrorMessage = '';

                // check from address validation
                // let from_address ={"countryCode": this.customerDetails.countryInfo.ctryCd ,"town":"","postalCode":SpsUtility.commonStaticObject.fromAddress.custPstlCd,"quoteCountry":"IN"}
                let country = (SpsUtility.commonStaticObject.fromAddress.countryInfo.ctryName) ? SpsUtility.commonStaticObject.fromAddress.countryInfo.ctryName : SpsUtility.commonStaticObject.fromAddress.countryInfo;
                const checkfromAddrUrl = SpsUtility.urlParams.checkAddrUrl.url + 'countryName=' + country.toUpperCase() + '&postCode=' + SpsUtility.commonStaticObject.fromAddress.custPstlCd;

                this.commonService.getAPIResponse(checkfromAddrUrl, null, 'GET').subscribe((addressResponse: any) => {
                    if (addressResponse && addressResponse.status === 500) {
                        if (addressResponse.message) {
                            this.commonService.showNotifier(addressResponse.message, 'error');
                        } else {
                            this.commonService.showNotifier('Error occurred while changing status.', 'error');
                        }
                        return;
                    }

                    if (addressResponse.towns.length > 0) {
                        //check to address                           
                        const checkToAddrUrl = SpsUtility.urlParams.checkAddrUrl.url + 'countryName=' + (SpsUtility.commonStaticObject.toAddress.countryInfo.toString().toUpperCase()) + '&postCode=' + SpsUtility.commonStaticObject.toAddress.custPstlCd;
                        this.commonService.getAPIResponse(checkToAddrUrl, null, 'GET').subscribe((toaddressResponse: any) => {

                            if (toaddressResponse.towns.length > 0) {
                                this.fromToAddressFlag = true;
                                $('#checkAddressButton').css('background-color', 'green');
                            }
                            else {
                                this.fromToAddressFlag = false;
                                $('#checkAddressButton').css('background-color', '#4d148c');
                                this.addressErrorMessage = 'Delivery Address Postal code is not valid.';
                            }
                        }, (error) => {
                            this.fromToAddressFlag = false;
                            $('#checkAddressButton').css('background-color', '#4d148c');
                            this.addressErrorMessage = 'Delivery Address Postal code is not valid.';
                        });

                    }
                    else {
                        $('#checkAddressButton').css('background-color', '#4d148c');
                        this.fromToAddressFlag = false;
                        this.addressErrorMessage = 'Collection Address Postal code is not valid.'
                    }

                    if (addressResponse && (addressResponse.status === 500 || addressResponse.status === 404)) {

                        // if (response.message) {
                        //     this.commonService.showNotifier(response.message, 'error');
                        // } else {
                        //     this.commonService.showNotifier('Error occurred while getting PT Data.', 'error');
                        // }
                        // return;
                    }
                }, (error) => {
                    $('#checkAddressButton').css('background-color', '#4d148c');
                    this.addressErrorMessage = 'Collection Address Postal code is not valid.';
                });
            }
        }
    }

    //validate delivary time if collection and  delivery date is same or delivery from and to date is same
    // checkDeliveryTimeValidate() {            
    //     let collectionDate = new Date(this.shipmentObject.collectionDate).getTime();
    //     let deliveryFromDate = new Date(this.shipmentObject.deliveryFromDate).getTime();
    //     let deliveryToDate = new Date(this.shipmentObject.deliveryToDate).getTime();

    //     if (this.shipmentObject.collectionToTime == this.shipmentObject.deliveryFromTime) {
    //         if (collectionDate === deliveryFromDate) {    
    //         }
    //     }

    // }



    ord: string;

    ord1: string;

    ord2: string;

    ord3: string;

    ord4: string;

    ord5: string;

    ord6: string;

    changeVal(veriable: string) {

        if (veriable === 'a') {

            this.shipmentObject.collectionDate = '';
            this.shipmentObject.collectionFromTime = '';
            this.shipmentObject.collectionToTime = '';
            this.shipmentObject.deliveryFromDate = '';
            this.shipmentObject.deliveryFromTime = '';
            this.shipmentObject.deliveryToDate = '';
            this.shipmentObject.deliveryToTime = '';

        }
        else if (veriable === 'b') {
            this.shipmentObject.deliveryFromDate = '';
            this.shipmentObject.deliveryFromTime = '';
            this.shipmentObject.deliveryToDate = '';
            this.shipmentObject.deliveryToTime = '';
        }
        else if (veriable === 'c') {
            this.shipmentObject.deliveryFromTime = '';
            this.shipmentObject.deliveryToDate = '';
            this.shipmentObject.deliveryToTime = '';

        }
        else if (veriable === 'd') {

            this.shipmentObject.deliveryToDate = '';
            this.shipmentObject.deliveryToTime = '';

        }
        else {
            this.shipmentObject.collectionDate = '';
            this.shipmentObject.collectionFromTime = '';
            this.shipmentObject.collectionToTime = '';
            this.shipmentObject.deliveryFromDate = '';
            this.shipmentObject.deliveryFromTime = '';
            this.shipmentObject.deliveryToDate = '';
            this.shipmentObject.deliveryToTime = '';
        }

    }



    timeApper(dsd) {
        this.dialogRef = this.dialog.open(this.timeModal, {});
        //this.changeTime(dsd)
        if (dsd == '1') {
            this.deliveryFromTimeVal = false;
            this.deliveryToTimeVal = false;
            this.collectionFromTimeVal = true;
            this.collectionToTimeVal = false;
        }
        if (dsd == '2') {
            this.deliveryFromTimeVal = false;
            this.deliveryToTimeVal = false;
            this.collectionFromTimeVal = false;
            this.collectionToTimeVal = true;
        }
        if (dsd == '3') {
            this.deliveryFromTimeVal = true;
            this.deliveryToTimeVal = false;
            this.collectionFromTimeVal = false;
            this.collectionToTimeVal = false;
        }
        if (dsd == '4') {
            this.deliveryFromTimeVal = false;
            this.deliveryToTimeVal = true;
            this.collectionFromTimeVal = false;
            this.collectionToTimeVal = false;
        }
    }
    changeTime() {

        let timetwel = (this.someDate.getHours() % 12 || 12).toLocaleString('en-US', { minimumIntegerDigits: 2, useGrouping: false });
        let time = this.someDate.getHours();
        //let time1=this.someDate.getDate();
        let ampm = time >= 12 ? 'PM' : 'AM';
        let minutes = this.someDate.getMinutes().toLocaleString('en-US', { minimumIntegerDigits: 2, useGrouping: false });

        if (this.deliveryFromTimeVal) {

            this.deliveryFromTime_minutes = 0;
            this.deliveryFromTime_minutes = (this.someDate.getDate() + this.someDate.getHours() * 60) + this.someDate.getMinutes();
            this.shipmentObject.deliveryFromTime = timetwel + ':' + minutes + ' ' + ampm;
            // $('#del_from_time').removeClass('dateErr');
            $('#del_from_time').css('background-color', '#4d148c');
            this.addressErrorMessage1 = '';
            this.deliveryTimeValidation = true;

            const datesForValidation = this.getDatesForValidation();

            if (datesForValidation.fromDateTime >= datesForValidation.toDateAndTime) {
                // $('#del_from_time').addClass('dateErr');
                $('#del_from_time').css('background-color', '#4d148c');
                this.addressErrorMessage1 = 'Please select deliveryFromTime greaterthen deliverToTime.';
                this.deliveryTimeValidation = false;
            }
            if (datesForValidation.fromDateTime <= datesForValidation.collectionToDateAndTime) {
                // $('#del_from_time').addClass('dateErr');
                $('#del_from_time').css('background-color', '#4d148c');
                this.addressErrorMessage1 = 'Please select deliveryFromTime greaterthen collectionToTime & deliveryToTime greaterthen deliveryFromTime';
                this.deliveryTimeValidation = false;
            }

            // this.shipmentObject.deliveryFromTime = timetwel + ':' + minutes + ' ' + ampm;
        }
        if (this.deliveryToTimeVal) {
            this.deliveryToTime_minutes = 0;
            this.deliveryToTime_minutes = (this.someDate.getDate() + this.someDate.getHours() * 60) + this.someDate.getMinutes();
            this.shipmentObject.deliveryToTime = timetwel + ':' + minutes + ' ' + ampm;
            // $('#del_to_time').removeClass('dateErr');
            $('#del_to_time').css('background-color', '#4d148c');
            this.addressErrorMessage1 = '';
            this.deliveryTimeValidation = true;
            const datesForValidation = this.getDatesForValidation();
            if (datesForValidation.toDateAndTime <= datesForValidation.fromDateTime) {
                // $('#del_to_time').addClass('dateErr');
                $('#del_to_time').css('background-color', '#4d148c');
                this.addressErrorMessage1 = 'Please select deliveryToTime greaterthen deliveryFromTime.';
                this.deliveryTimeValidation = false;
            }


            // this.shipmentObject.deliveryToTime = timetwel + ':' + minutes + ' ' + ampm;
        }
        if (this.collectionFromTimeVal) {
            this.collectionFromTime_minutes = 0;
            this.collectionFromTime_minutes = (this.someDate.getDate() + this.someDate.getHours() * 60) + this.someDate.getMinutes();
            this.shipmentObject.collectionFromTime = timetwel + ':' + minutes + ' ' + ampm;
            $('#coll_from_time').removeClass('dateErr');
            this.addressErrorMessage2 = '';
            this.collectionTimeValidation = true;

            if (this.collectionToTime_minutes && this.collectionToTime_minutes <= this.collectionFromTime_minutes) {
                // $('#coll_from_time').addClass('dateErr');
                $('#coll_from_time').css('background-color', '#4d148c');
                this.addressErrorMessage2 = 'Please select collectionToTime greaterthen collectionFromTime.';
                this.collectionTimeValidation = false;
            }
            if (this.collectionToTime_minutes > this.collectionFromTime_minutes) {
                $('#coll_to_time').removeClass('dateErr');
                this.addressErrorMessage2 = '';
                this.collectionTimeValidation = true;
            }
        }
        if (this.collectionToTimeVal) {
            this.collectionToTime_minutes = 0;
            this.collectionToTime_minutes = (this.someDate.getDate() + this.someDate.getHours() * 60) + this.someDate.getMinutes();
            this.shipmentObject.collectionToTime = timetwel + ':' + minutes + ' ' + ampm;
            $('#coll_to_time').removeClass('dateErr');
            this.addressErrorMessage2 = '';
            this.collectionTimeValidation = true;

            if (this.collectionFromTime_minutes && this.collectionToTime_minutes <= this.collectionFromTime_minutes) {
                // $('#coll_to_time').addClass('dateErr');
                $('#coll_to_time').css('background-color', '#4d148c');
                this.addressErrorMessage2 = 'Please select collectionToTime greaterthen collectionFromTime.';
                this.collectionTimeValidation = false;
            }
            if (this.collectionToTime_minutes > this.collectionFromTime_minutes) {
                $('#coll_from_time').removeClass('dateErr');
                this.addressErrorMessage2 = '';
                this.collectionTimeValidation = true;
            }
        }
        // alert(this.someDate);
        this.dialogRef.close(null);
    }

    private getDatesForValidation() {
        const fromDate = new Date(this.shipmentObject.deliveryFromDate);
        const fromDateAndTime = (isNaN(fromDate.getTime()) ? 0 : fromDate.getTime()) + this.deliveryFromTime_minutes;

        const toDate = new Date(this.shipmentObject.deliveryToDate);
        const toDateAndTime = (isNaN(toDate.getTime()) ? 0 : toDate.getTime()) + this.deliveryToTime_minutes;

        const collectionDate = new Date(this.shipmentObject.collectionDate);
        const collectionToDateAndTime = (isNaN(collectionDate.getTime())) ? 0 : collectionDate.getTime() + this.collectionToTime_minutes;
        return {
            fromDateTime: fromDateAndTime,
            toDateAndTime: toDateAndTime,
            collectionToDateAndTime: collectionToDateAndTime
        };
    }

    cancelTime(event) {
        //if(event == 'cancel'){
        if (this.deliveryFromTimeVal) {
            this.dialogRef.close(null);
            // this.shipmentObject.deliveryFromTime = '';
        }
        if (this.deliveryToTimeVal) {
            this.dialogRef.close(null);
            // this.shipmentObject.deliveryToTime = '';
        }
        if (this.collectionFromTimeVal) {
            this.dialogRef.close(null);
            //  this.shipmentObject.collectionFromTime = '';
        }
        if (this.collectionToTimeVal) {
            this.dialogRef.close(null);
            // this.shipmentObject.collectionToTime = '';
        }
        // }
    }

    goback() {
        this.customerPanelOpen = false;
        let shipmentform = this.formGroups.shipmentForm;
        this.formGroups.customer.disable();
        this.formGroups.shipmentForm = shipmentform;

    }
}