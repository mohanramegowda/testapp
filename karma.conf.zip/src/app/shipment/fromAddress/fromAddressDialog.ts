import { Component, Inject, OnInit } from '@angular/core';
import { VERSION, MatDialogRef, MatDialog, MatSnackBar, MAT_DIALOG_DATA } from '@angular/material';
import { FromAddressConfig } from '../shipment-fromaddressConfig';
import { SpsUtility } from '../../common/SpsUtility'
import { FormControl, Validator, FormGroup, Validators } from '@angular/forms';
import { FieldConfig } from 'app/components/dyn-forms/field.interface';


@Component({
  selector: 'fromAddress-dialog',
  templateUrl: './fromAddressDialog.html',
})
export class FromAddressDialog implements OnInit{

  formGroups = { fromAddress: null};
  FromAddressDynamicConfig: FieldConfig[] = [];
  fromAddressDetails; FromAddrcofigJSON ;

  message: any;
  confirmButtonText = "Yes"
  cancelButtonText = "Cancel"
  constructor(
    @Inject(MAT_DIALOG_DATA) private data: any,
    private dialogRef: MatDialogRef<FromAddressDialog>) {
      if(data){    
            if (data.buttonText) {
            this.confirmButtonText = data.buttonText.ok || this.confirmButtonText;
            this.cancelButtonText = data.buttonText.cancel || this.cancelButtonText;
            }
      }

      this.FromAddrcofigJSON = JSON.parse(JSON.stringify(FromAddressConfig.config.shipmentFromAddressForm));
  }

  ngOnInit(): void {
      console.log(SpsUtility.commonStaticObject.fromAddress.ctryName);
      console.log(this.data.message.countryInfo.ctryName);
    //from address config    
    if(SpsUtility.commonStaticObject.fromAddress){
        console.log("from add");
        this.fromAddressDetails = SpsUtility.commonStaticObject.fromAddress;        
        this.formGroups.fromAddress = this.buildField(this.FromAddrcofigJSON, this.fromAddressDetails);
    }else if(this.data.message) {
        console.log("data");
        this.fromAddressDetails = this.data.message;
        this.fromAddressDetails['countryInfo'] = this.data.message.country;
        console.log(this.fromAddressDetails);
        this.formGroups.fromAddress = this.buildField(this.FromAddrcofigJSON, this.fromAddressDetails);
    }else {
        this.formGroups.fromAddress = this.buildField(this.FromAddrcofigJSON, null);
    }    
    // this.formGroups.fromAddress = this.buildField(this.FromAddrcofigJSON, this.fromAddressDetails);
    this.FromAddressDynamicConfig = this.formGroups.fromAddress.fieldsConfig;

    console.log(this.data.message.ctryName);
    // console.log(this.data.message.countryInfo);
    // console.log("vvc",this.data.message.ctryName);
    // console.log(this.data.message.countryInfo.ctryName);
    console.log(this.formGroups.fromAddress);

  }

  close() {
    SpsUtility.commonStaticObject.fromAddress = this.formGroups.fromAddress.value;    
    this.dialogRef.close();
  }


  onConfirmClick(): void {
    if (this.formGroups.fromAddress.value.custCoNm != '' && this.formGroups.fromAddress.value.custCoNm != undefined && this.formGroups.fromAddress.value.custCoNm != null
        && this.formGroups.fromAddress.value.custAddr != '' && this.formGroups.fromAddress.value.custAddr != undefined && this.formGroups.fromAddress.value.custAddr != null
        && this.formGroups.fromAddress.value.custCty != '' && this.formGroups.fromAddress.value.custCty != undefined && this.formGroups.fromAddress.value.custCty != null
        && this.formGroups.fromAddress.value.countryInfo != '' && this.formGroups.fromAddress.value.countryInfo != undefined && this.formGroups.fromAddress.value.countryInfo != null        
        && this.formGroups.fromAddress.value.custPstlCd != '' && this.formGroups.fromAddress.value.custPstlCd != undefined && this.formGroups.fromAddress.value.custPstlCd != null) {
        SpsUtility.commonStaticObject.fromAddress = this.formGroups.fromAddress.value;    
        this.dialogRef.close(this.formGroups.fromAddress.value);
    }
  }

  onFormGroupCreate(element) {
    if (this.formGroups && element && element.group) {
        this.formGroups[element.formName] = element.group;
        this.onChanges(element.group);
    }
}
onChanges(group) {
    group.valueChanges.subscribe(val => {
        // tslint:disable-next-line: forin
        for (const i in this.formGroups) {
            if (this.formGroups[i] && !this.formGroups[i].valid) {
                // this.stopStepper = true;
            } else if (this.formGroups[i]) {
                this.formGroups[i] = group;
            }
        }

    });
}
  buildField(frmCnfg = null, availableObject) {
    const fieldConfigMap = {};
    const formConfigObj: any = {};
    if (frmCnfg) {
        const config: any = JSON.parse(JSON.stringify(frmCnfg));        

        const fieldConfigs: FieldConfig[] = [];
        if (config.fields) {
            config.fields.map((field) => {

                let elementConfig: FieldConfig;
                const elementObj: any = {};
                elementObj.inputType = field.inputType;
                elementObj.type = field.type;
                elementObj.label = field.label;
                elementObj.name = field.name;
                elementObj.styleClass = field.styleClass;
                elementObj.styleColor = field.styleColor;
                elementObj.disabled = field.disabled;
                if (field.value) {
                    elementObj.value = field.value;
                }
                if (field.options) {
                    elementObj.options = field.options;
                }

                // Override the default Value
                if (availableObject && availableObject[field.name]) {
                    if (field.type === 'select') {
                        elementObj.options = availableObject[field.name].values;
                        elementObj.value = availableObject[field.name].value;
                    } else {
                        elementObj.value = availableObject[field.name];
                    }

                    if (field.inputType === 'radio') {
                        elementObj.options = availableObject[field.name].values;
                        elementObj.value = availableObject[field.name].value;
                    } else {
                        elementObj.value = availableObject[field.name];
                    }

                    if (field.type === 'date') {
                        elementObj.dateFilter = availableObject[field.name].dateFilter;
                        if (availableObject[field.name].value) {
                            elementObj.value = availableObject[field.name].value;
                        } else {
                            elementObj.value = availableObject[field.name];
                        }
                    }

                    if (field.label === 'Country') {
                        console.log(availableObject[field.name].ctryName);
                        if(availableObject[field.name].ctryName){
                            elementObj.value = availableObject[field.name].ctryName;
                        }else{
                        elementObj.value = availableObject[field.name];
                        }
                    }

                    if (field.label === 'Payer') {
                        console.log("=====");
                        console.log(field);
                        console.log(field.parent());

                    }
                    // elementObj.disabled = !!availableObject[field.name].disabled;
                }

                if (field.validations) {
                    let validator: Validator[];
                    const validatorArr = [];
                    field.validations.map((validation) => {
                        const validatorObj: any = {};
                        if (validation.name === 'required') {
                            validatorObj.name = validation.name;
                            validatorObj.validator = Validators.required;
                            validatorObj.message = validation.message;
                        } else if (validation.name === 'pattern') {
                            validatorObj.name = validation.name;
                            validatorObj.validator = Validators.pattern(validation.value);
                            validatorObj.message = validation.message;
                        } else if (validation.name === 'maxlength') {
                            validatorObj.name = validation.name;
                            validatorObj.validator = Validators.maxLength(validation.value);
                            validatorObj.message = validation.message;
                        } else if (validation.name === 'minlength') {
                            validatorObj.name = validation.name;
                            validatorObj.validator = Validators.minLength(validation.value);
                            validatorObj.message = validation.message;
                        }
                        validatorArr.push(validatorObj);
                    });
                    validator = validatorArr;
                    elementObj.validations = validator;
                }
                elementConfig = elementObj;
                fieldConfigs.push(elementConfig);
            });
        }
        formConfigObj.fieldsConfig = fieldConfigs;
        fieldConfigMap[formConfigObj.form_name] = formConfigObj;
    }
    return formConfigObj;
}

}