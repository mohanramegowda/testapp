import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ShipmentdetailsComponent } from '../shipment/shipmentdetails.component';
import { MaterialModule } from '../material.module';
import { ComponentsModule } from 'app/components/components.module';
import { RangeSliderModule } from 'app/components/range-slider/range-slider.module';
import { TimePickerComponent } from './../timepicker/timepicker.component';
import { DynFormModule } from '../components/dyn-forms/dyn-forms.module';
import {FromAddressDialog } from './fromAddress/fromAddressDialog';
import {ToAddressDialog } from './toAddress/toAddressDialog';
import {DatePipe} from '@angular/common';
import {OrderCreationDialog } from './orderCreated/orderCreationDialog';
@NgModule({
    imports: [
        CommonModule,
        RouterModule,
        FormsModule,
        ReactiveFormsModule,
        CommonModule,
        MaterialModule,
        ComponentsModule,
        RangeSliderModule,
        DynFormModule
    ],
    providers: [DatePipe],
    declarations: [ShipmentdetailsComponent,TimePickerComponent,FromAddressDialog,ToAddressDialog,OrderCreationDialog],
    exports: [ShipmentdetailsComponent],
    entryComponents: [FromAddressDialog,ToAddressDialog,OrderCreationDialog]
})
export class SPSSCustomerModule { }