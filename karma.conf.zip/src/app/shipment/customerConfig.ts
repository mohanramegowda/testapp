export class customerConfig {
   static config = {
        'customerDetailsForm': {
            'name': 'Test',
            'submitUrl': '',
            'form_name': 'tts',
            'entity': 'tts',
            'fields': [
                {},
                {},
                {
                    'type': "radiobutton",
                    'label': "Payer",
                    'name': "payer",
                    'options': ["Sender"],
                    'value': "Sender",                    
                    'id':"payer",
                    'styleClass': "payerClass",
                    'disabled' : true
                    },             
                {
                    'name': 'custFstNm',                    
                    'inputType': 'text',
                    'type': 'input',
                    'label': 'Customer Name',                   
                    'validations': [ ],
                    'disabled' : true
                },
                {
                    'name': 'custCoNm',                    
                    'inputType': 'text',
                    'type': 'input',
                    'label': 'Company Name',                   
                    'validations': [ ],
                    'disabled' : true
                },
                {
                    'name': 'countryInfo',                    
                    'inputType': 'text',
                    'type': 'input',
                    'label': 'Country',                                                          
                    'validations': [],
                    'disabled' : true
                },
                {
                    'name': 'custPstlCd',                    
                    'inputType': 'text',
                    'type': 'input',
                    'label': 'Postal',                                                          
                    'validations': [],
                    'disabled' : true
                },
                {
                    'name': 'custCty',                    
                    'inputType': 'text',
                    'type': 'input',
                    'label': 'City',                                                           
                    'validations': [],
                    'disabled' : true
                },
                {
                    'name': 'custPh',                    
                    'inputType': 'phone',
                    'type': 'input',
                    'value': '',
                    'label': 'Phone Number',                    
                    'validations': [],
                    'disabled' : true
                },
                {
                    'name': 'custMail',                    
                    'inputType': 'text',
                    'type': 'input',
                    'label': 'Customer Email',                   
                    'validations': [ ],
                    'disabled' : true
                },                
                {   
                    'name': 'custAddr',                    
                    'inputType': 'text',
                    'type': 'input',
                    'value': '',
                    'label': 'Address',                    
                    'validations': [],
                    'disabled' : true
                }               
             ]}
                
    }
}
