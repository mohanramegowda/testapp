import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { InvoicingComponent } from './invoicing.component';
import { IsAuthorized } from 'app/common/guards/auth-guard';

const routes: Routes = [
    { path: 'invoice', component: InvoicingComponent, canActivate: [IsAuthorized] }
];


@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class InvoiceRoutingModule { }
