import { Component, ViewChild, ElementRef, OnInit, Pipe } from '@angular/core';
import { CommonService } from '../common/common.service';
import { MatTableDataSource } from '@angular/material/table';
import { FormControl, Validators, FormBuilder } from '@angular/forms';
import { SpsUtility } from 'app/common/SpsUtility';
import { SelectionModel } from '@angular/cdk/collections';
import { DatePipe } from '@angular/common';
import { MatPaginator } from '@angular/material/paginator';
import { RolesAndActionsService } from 'app/common/roles-actions.service';


@Component({
  selector: 'app-invoicing',
  templateUrl: './invoicing.component.html',
  styleUrls: ['./invoicing.component.scss']
})
export class InvoicingComponent implements OnInit {

  @ViewChild("orderId") orderIdField: ElementRef;
  editorderIdField(): void {
    this.orderIdField.nativeElement.focus();
  }
  @ViewChild("fromDate") fromDateField: ElementRef;
  editfromDateField(): void {
    this.fromDateField.nativeElement.focus();
  }
  @ViewChild("toDate") toDateField: ElementRef;
  edittoDateField(): void {
    this.toDateField.nativeElement.focus();
  }
  // loginValue: any[] = [
  //   { value: 'col-0', viewValue: '<---Select--->' },
  //   { value: 'col-1', viewValue: 'Order Id' },
  //   { value: 'col-2', viewValue: 'EAN Number' },
  //   { value: 'col-1', viewValue: 'Connote  Number' }
  // ];
  //selectedValue='';
  selectedValue: boolean = true;

  submitted = false;
  dataList = null;
  displayedColumns: string[] = ['select', 'customerNo', 'shipDate', 'productCode', 'originationCountry', 'destinationCountry'];
  dataSource = new MatTableDataSource<PeriodicElement>();

  selection = new SelectionModel<PeriodicElement>(true, []);

  filterForm = this.formBuilder.group({
    fromDate: [null,],
    toDate: [null, ],
    qteCountry: new FormControl('', []),
    orderId: new FormControl({value: '', disabled: true}),
    customerNo: new FormControl('', []),
  });

  ELEMENT_DATA: any;
  countryList: any;
  tableList: any;
  isDisabled: boolean = true;
  toggle = true;
  status = 'Enable';
  countryListData: any;
  tomorrow = new Date();
  selectionAmount: string;

  showPagination: boolean = false;
  public array: any;
  public pageSize = 10;
  public currentPage = 0;
  positionValue = [];
  public totalSize = 0;
  reqID: any;
  dateTime: string;
  entDegi: any;

ord:boolean = false;

ord1:boolean = false;

ord2:boolean = false;

canDownload: boolean = true;

changeVal(veriable:string){

 if(veriable ==='a'){
  // this.ord = false;
  //this.editorderIdField();
  this.filterForm.get('orderId').enable();
      this.filterForm.get('fromDate').reset();
       this.filterForm.get('toDate').reset();
      // this.filterForm.get('orderId').reset();
    
    //this.onSubmit();
    //this.submitted = false;
    if(this.filterForm.value.orderId.length > 4){
      this.editfromDateField();
    this.edittoDateField();
      this.filterForm.get('fromDate').enable();
      this.filterForm.get('toDate').enable();
      this.editorderIdField();
      this.filterForm.get('orderId').enable();
       //this.filterForm.get('orderId').reset();
      // this.filterForm.get('fromDate').reset();
      //  this.filterForm.get('toDate').reset();
    }
    else if(this.filterForm.value.orderId.length === 4){
      this.editfromDateField();
    this.edittoDateField();
      this.filterForm.get('fromDate').enable();
      this.filterForm.get('toDate').enable();
         this.filterForm.get('fromDate').reset();
       this.filterForm.get('toDate').reset();
      //   this.filterForm.get('orderId').reset();
    }
    else{

    // this.filterForm.get('fromDate').enable();
    // this.filterForm.get('toDate').enable();
    this.editfromDateField();
    this.edittoDateField();
    this.editorderIdField();
    this.filterForm.get('orderId').enable();
     this.filterForm.get('fromDate').reset();
     this.filterForm.get('toDate').reset();
    }
 }




  if(veriable ==='b' || veriable ==='c'){
  //this.editfromDateField();
  //this.edittoDateField();
  if(this.filterForm.value.orderId.length > 4){
    this.editfromDateField();
  this.edittoDateField();
    this.filterForm.get('fromDate').enable();
    this.filterForm.get('toDate').enable();
  }
  else if(this.filterForm.value.orderId.length === 4 && this.filterForm.value.orderId.length < 4){
    this.editfromDateField();
  this.edittoDateField();
  this.editorderIdField();
    this.filterForm.get('fromDate').enable();
    this.filterForm.get('toDate').enable();
    this.filterForm.get('orderId').reset();
       this.filterForm.get('fromDate').reset();
     this.filterForm.get('toDate').reset();
    //   this.filterForm.get('orderId').reset();
  }
  //  if(this.filterForm.value.orderId.length === 0 || this.filterForm.value.orderId.length === null ||  this.filterForm.value.orderId.length === 4){
  //   this.editfromDateField();
  // this.edittoDateField();
  //  // this.filterForm.get('fromDate').enable();
  //   //this.filterForm.get('toDate').enable();
  //     this.filterForm.get('fromDate').reset();
  //     this.filterForm.get('toDate').reset();
  //      this.filterForm.get('orderId').reset();
  // }
 // this.submitted = false;
  //this.filterForm.get('orderId').disable();
  //this.filterForm.get('orderId').reset();
  else{
  //this.filterForm.get('orderId').disable();
  this.filterForm.get('orderId').reset();
//   this.filterForm.get('fromDate').disable();
// this.filterForm.get('toDate').disable();
this.filterForm.get('fromDate').reset();
 this.filterForm.get('toDate').reset();
// console.log("");
      }}
//           // else{
//           //   this.ord = false;
//           //   this.ord1 = false;
//           //   this.ord2 = false;
//           // }
 }

  get fromDate() { return this.filterForm.get('fromDate').value; }
  get toDate() { return this.filterForm.get('toDate').value; }
  constructor(private formBuilder: FormBuilder, private commonService: CommonService, private datePipe: DatePipe
    , private rolesAndActionsService: RolesAndActionsService) {
    this.invoiceDataList();
    this.tomorrow.setDate(this.tomorrow.getDate() && this.tomorrow.getDate() - 7);
  }
  @ViewChild(MatPaginator) paginator: MatPaginator;
  ngOnInit() {
    //this.onSubmit();
    //this.submitted = true;
    //this.dataSource.paginator = this.paginator;
    // this.dataSource.paginator = this.paginator;

    let countryList1 = SpsUtility.countryList;
    this.countryList = countryList1.sort((a, b) => a.ctryName !== b.ctryName ? a.ctryName < b.ctryName ? -1 : 1 : 0);
    this.canDownload = this.rolesAndActionsService.CanDownloadInInvoice();
  }

  get f() { return this.filterForm.controls; }

  onSubmit() {
    this.submitted = true;
// this.entDegi= document.getElementById("entDegi").nodeValue
//     if (this.entDegi < 4) {
//       this.entDegi = this.filterForm.value.orderId;
//     } else {
//       this.entDegi = this.filterForm.value.customerNumber;
//     }

if(this.filterForm.value.orderId){
  if (this.filterForm.value.orderId.length > 4){
    this.reqID = '&countrycode=' + this.filterForm.value.qteCountry + '&customerNo=' + this.filterForm.value.orderId + '&fromdate=' + this.convert(this.filterForm.value.fromDate, 'dd/MM/yyyy') + '&todate=' + this.convert(this.filterForm.value.toDate, 'dd/MM/yyyy') ;
  }
  else{
    this.reqID = '&countrycode=' + this.filterForm.value.qteCountry + '&orderId=' + this.filterForm.value.orderId;
  }
}
else{
  this.reqID= '&countrycode=' + this.filterForm.value.qteCountry + '&fromdate=' + this.convert(this.filterForm.value.fromDate, 'dd/MM/yyyy') + '&todate=' + this.convert(this.filterForm.value.toDate, 'dd/MM/yyyy') 
}

  // if(this.filterForm.value.qteCountry && this.filterForm.value.customerNo )
  // {
  //  this.reqID = '&countrycode=' + this.filterForm.value.qteCountry + '&customerNo=' + this.filterForm.value.customerNo 
  // }
  //   else (this.filterForm.value.qteCountry  && this.filterForm.value.orderId )
  //   {
  //    this.reqID = '&countrycode=' + this.filterForm.value.qteCountry + '&orderId=' + this.filterForm.value.orderId 
  //   }
    
  // }
  // else{
     
  //   if (this.filterForm.value.qteCountry  && this.filterForm.value.orderId )
  //   {
  //    this.reqID = '&countrycode=' + this.filterForm.value.qteCountry + '&orderId=' + this.filterForm.value.orderId 
  //   }

  //   else (this.filterForm.value.qteCountry  && this.convert(this.filterForm.value.fromDate, 'dd/MM/yyyy') && this.convert(this.filterForm.value.toDate, 'dd/MM/yyyy' ))
  //   {
  //     this.reqID= '&countrycode=' + this.filterForm.value.qteCountry + '&fromdate=' + this.convert(this.filterForm.value.fromDate, 'dd/MM/yyyy') + '&todate=' + this.convert(this.filterForm.value.toDate, 'dd/MM/yyyy') 
  //    }
    

  // }
    
    const invoiceUrl = SpsUtility.urlParams.invoiceUrl.url + this.reqID
    this.commonService.getAPIResponse(invoiceUrl, null, SpsUtility.urlParams.invoiceUrl.type).subscribe((tableData: any) => {
     
      this.dataSource = new MatTableDataSource(tableData);

     
// console.log(ref.checked)
      console.log(tableData);
      this.array = this.dataSource.filteredData;
      this.totalSize = this.array.length;


      this.dataSource.paginator = this.paginator;
      this.iterator();
      
    });
  }

  search(term: string) {
    if(!term) {
      this.array = this.dataSource.filteredData;
    } else {
      this.array = this.dataSource.filteredData.filter(x => 
         x.name.trim().toLowerCase().includes(term.trim().toLowerCase())
      );
    }
  }

  disabledAgreement: boolean = true;
  changeCheck(event) {
    this.disabledAgreement = !event.checked;
  }

  iterator() {
    const end = (this.currentPage + 1) * this.pageSize;
    const start = this.currentPage * this.pageSize;
    const part = this.array.slice(start, end);
    this.dataSource.filteredData = part;
    //console.log(this.dataSource, "dataSoucr222222222222222222")
    if (this.array.length == 0) {
      this.currentPage = this.currentPage - 1;
      const end = (this.currentPage + 1) * this.pageSize;
      const start = this.currentPage * this.pageSize;
      const part = this.array.slice(start, end);
      this.dataSource.filteredData = part;
    }
  }
  handlePage(e: any) {
    this.currentPage = e.pageIndex;
    this.pageSize = (e.pageSize != undefined) ? e.pageSize : this.pageSize;
    this.iterator();

  }
  isAllSelected() {

    const numSelected = this.selection.selected.length;
    const numRows = this.dataSource.filteredData.length;
    // console.log(numSelected,numRows);

    return numSelected === numRows;

  }

  /** Selects all rows if they are not all selected; otherwise clear selection. */
  masterToggle(ref) {
    
    if (this.isSomeSelected()) {

      this.selection.clear();
      ref.checked = false;
     // console.log(ref.checked)

    } else {
      
      this.selection.clear(),
        ref.checked = true;

      this.dataSource.filteredData.forEach(row => this.selection.select(row));
      this.dataSource.filteredData.forEach(row => {
        this.positionValue.push(row)
      });
     

    }
  }
  pageChanged() {
    // console.log(' 1111 ', this.selection.clear());
    this.disabledAgreement = true;

    this.selection.clear();
  }

  isSomeSelected() {

    return this.selection.selected.length > 0;
  }
  applyFilter(filterValue: string) {
    this.dataSource.filter = filterValue.trim().toLowerCase();
  }
  convert(time, format) {
    var t = new Date(time);
    var tf = function (i) { return (i < 10 ? '0' : '') + i };
    return format.replace(/yyyy|MM|dd|HH|mm|ss/g, function (a) {
      switch (a) {
        case 'yyyy':
          return tf(t.getFullYear());
          break;
        case 'MM':
          return tf(t.getMonth() + 1);
          break;
        case 'mm':
          return tf(t.getMinutes());
          break;
        case 'dd':
          return tf(t.getDate());
          break;
        case 'HH':
          return tf(t.getHours());
          break;
        case 'ss':
          return tf(t.getSeconds());
          break;
      }
    })
  }

  invoiceDataList() {

    let dataList =
    {
      "preInvGroupNo": 2,
      "preInvTransTypeId": "MISC_FB",
      "customerNo": 700159738,
      "currencyCode": "AUD",
      "additionalInfo": null,
      "shipDate": "2019-11-13",
      "productCode": "MISCAU-AIB",
      "productNote": "TNTABxxx- 1E",
      "quantity": 1,
      "ovrPrice": 20,
      "ovrdPriceComments": null,
      "originationCountry": null,
      "originationLocation": null,
      "destinationCountry": null,
      "destinationLocation": null,
      "leaseIndicator": null,
      "airBillNumber": null,
      "billTypeNo": null,
      "serviceTypeNo": null,
      "weightNo": null,
      "sendToCustFlag": null,
      "purchaseOrderNo": null

    }
   
  }

  openAddFileDialog() {

    let listData = this.selection.selected;
    const headers = {
      preInvGroupNo: 'Preinvoice GroupNbr*',
      preInvTransTypeId: 'Preinvoice Trx Type*',
      customerNo: 'Customer Number*',
      currencyCode: "Currency Code*",
      additionalInfo: 'Additional Info(140 Characters Only)',
      shipDate: 'Ship Date(DD-MM-YYYY)',
      productCode: 'Product Code*',
      productNote: 'Product Note(240 Characters Only)',
      quantity: 'Quantity*',
      ovrPrice: 'Overridden Price',
      ovrdPriceComments: 'Overridden Price Comments',
      originationCountry: 'Origination Country',
      originationLocation: 'Origination Location',
      destinationCountry: 'Destination Country',
      destinationLocation: 'Destination Location',
      leaseIndicator: 'Lease Indicator(Y/N)',
      airBillNumber: 'AirBill Number',
      billTypeNo: 'Bill Type',
      serviceTypeNo: 'Service Type',
      weightNo: 'Weight',
      sendToCustFlag: 'Send To Cust Flag(Y/N)',
      purchaseOrderNo: 'Purchase Order Number'
    };

    const itemsFormated = [];
    //console.log(headers)

    listData.forEach((data) => {
      itemsFormated.push({
        preInvGroupNo: data.preInvGroupNo == null?'': data.preInvGroupNo,
        preInvTransTypeId: data.preInvTransTypeId == null?'': data.preInvTransTypeId,
        customerNo: data.customerNo == null?'': data.customerNo,
        currencyCode: data.currencyCode == null?'': data.currencyCode,
        additionalInfo: data.additionalInfo == null?'': data.additionalInfo,
        shipDate: data.shipDate == null?'': data.shipDate,
        productCode: data.productCode == null?'': data.productCode,
        productNote: data.productCode == null?'': data.productCode,
        quantity: data.quantity == null?'': data.quantity,
        ovrPrice: data.ovrPrice == null?'': data.ovrPrice,
        ovrdPriceComments: data.ovrdPriceComments == null?'': data.ovrdPriceComments,
        originationCountry: data.originationCountry == null?'': data.originationCountry,
        originationLocation: data.originationLocation == null?'': data.originationLocation,
        destinationCountry: data.destinationCountry == null?'': data.destinationCountry,
        destinationLocation: data.destinationLocation == null?'': data.destinationLocation,
        leaseIndicator: data.leaseIndicator == null?'': data.leaseIndicator,
        airBillNumber: data.airBillNumber == null?'': data.airBillNumber,
        billTypeNo: data.billTypeNo == null?'': data.billTypeNo,
        serviceTypeNo: data.serviceTypeNo == null?'': data.serviceTypeNo,
        weightNo: data.weightNo == null?'': data.weightNo,
        sendToCustFlag: data.sendToCustFlag == null?'': data.sendToCustFlag,
        purchaseOrderNo: data.purchaseOrderNo == null?'': data.purchaseOrderNo
        //ctryName:data.ctryName


      })
    })

    const fileTitle = 'Invoice-list';
    this.exportCSVFile(headers, itemsFormated, fileTitle);
  }
  exportCSVFile(headers, items, fileTitle) {
    if (headers) {
      items.unshift(headers);
    }

    let jsonObject = JSON.stringify(items)
    let csv = this.convertToCSV(jsonObject);
    let exportedFilename = fileTitle + '.csv' || 'export.csv';
    let blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    if (navigator.msSaveBlob) {
      navigator.msSaveBlob(blob, exportedFilename);
    }
    else {
      let link = document.createElement('a');
      if (link.download != undefined) {
        let url = URL.createObjectURL(blob);
        link.setAttribute('href', url);
        link.setAttribute('download', exportedFilename);
        link.style.visibility = 'hidden';
        //document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
      }
    }
  }

  convertToCSV(objArray) {
    const array = typeof objArray != 'object' ? JSON.parse(objArray) : objArray;
    let str = '';
    for (let i = 0; i < array.length; i++) {
      let line = '';
      for (let index in array[i]) {
        if (line != '') line += ','; line += array[i][index];
      }
      str += line + '\r\n';
    }
    return str;
  }

}

export interface PeriodicElement {
  quantity: any;
  ovrPrice: any;
  ovrdPriceComments: any;
  originationLocation: any;
  destinationLocation: any;
  leaseIndicator: any;
  airBillNumber: any;
  billTypeNo: any;
  serviceTypeNo: any;
  weightNo: any;
  sendToCustFlag: any;
  purchaseOrderNo: any;
  additionalInfo: any;
  currencyCode: any;
  preInvTransTypeId: any;
  preInvGroupNo: any;
  position: any;
  name: any;
  customerNo: number;
  shipDate: string;
  productCode: string;
  originationCountry: string;
  destinationCountry: string;
}
