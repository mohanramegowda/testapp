import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SPSCustomerRoutingModule } from './sps-customer.routing';
import { SPSCustomerComponent } from './sps-customer.component';
import { MaterialModule } from '../material.module';
import { ComponentsModule } from 'app/components/components.module';
import { RangeSliderModule } from 'app/components/range-slider/range-slider.module';
import {MatAutocompleteModule} from '@angular/material/autocomplete';

@NgModule({
    imports: [
        CommonModule,
        RouterModule,
        SPSCustomerRoutingModule,
        FormsModule,
        ReactiveFormsModule,
        CommonModule,
        MaterialModule,
        ComponentsModule,
        RangeSliderModule,
        MatAutocompleteModule
    ],
    providers: [],
    declarations: [SPSCustomerComponent],
    exports: [SPSCustomerComponent],
})
export class SPSCustomerModule { }
