import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { CommonService } from '../common/common.service';
import { NestedTreeControl } from '@angular/cdk/tree';
import { MatTreeNestedDataSource } from '@angular/material/tree';
import { MatDialog, MatStepper } from '@angular/material';
import { Router, ActivatedRoute } from '@angular/router';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { COMMA, ENTER } from '@angular/cdk/keycodes';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MatAutocompleteSelectedEvent, MatChipInputEvent, MatAutocomplete } from '@angular/material';
import { Observable } from 'rxjs';
import { map, startWith } from 'rxjs/operators';
import { SpsUtility } from '../common/SpsUtility';

declare var $: any;
interface FoodNode {
    name: string;
    style?: string;
    children?: FoodNode[];
}

@Component({
    selector: 'app-sps-customer',
    templateUrl: './sps-customer.component.html',
    styleUrls: ['./sps-customer.component.scss']
})
export class SPSCustomerComponent implements OnInit {

    @ViewChild('genModal')
    genModal: any;

    @ViewChild('stepper')
    stepper: MatStepper;

    displayLoader: boolean = false;
    customerDetails: any;
    isDisabled: boolean = false;
    filter: any = '';
    filterLevel: any = '';
    showResult = false;
    dialogRef: any;
    editCallerForm: FormGroup;
    treeControl = new NestedTreeControl<FoodNode>(node => node.children);
    dataSource = new MatTreeNestedDataSource<FoodNode>();
    visible = true;
    selectable = true;
    removable = true;
    addOnBlur = true;
    separatorKeysCodes: number[] = [ENTER, COMMA];
    fruitCtrl = new FormControl();
    filteredFruits: Observable<string[]>;
    fruits: string[] = ['Netherlands'];
    allFruits: string[] = ['Great Britain', 'Germany', 'Netherlands', 'Belgium', 'Austria'];
    tiles: any = [
        { text: 'Two', cols: 1, rows: 2, color: '#ab70b7' },
        { text: 'One', cols: 3, rows: 2, color: '#ffd7b5' },
    ]
    dropdownDisc = 8;
    changeDisc = [8, 8, 8, 8, 8];
    qualityType = 'Shipments';
    imperial_val: boolean = false;
    selectedStatus = 'PreApproved';
    discArr = { 59: '#ffffff', 60: '#FFBF00', 70: '#CD5C5C' };
    discStyle = ['#ffffff', '#ffffff', '#ffffff', '#ffffff', '#ffffff'];
    discType = 1;
    customerSearchShow: boolean = false;
    addcustomers: boolean = false;
    errNotification = 'Pre Approved';
    @ViewChild('fruitInput') fruitInput: ElementRef<HTMLInputElement>;
    @ViewChild('auto') matAutocomplete: MatAutocomplete;
    countryList; ErrorMessage: string;
    caller = new FormGroup({
        'name': new FormControl('', [Validators.required]),
        'telNo': new FormControl('', [Validators.required, Validators.
            pattern('^\\s*(?:\\+?(\\d{1,3}))?[-. (]*(\\d{3})[-. )]*(\\d{3})[-. ]*(\\d{1,4})(?: *x(\\d+))?\\s*$')
        ]),
        'email': new FormControl('', [Validators.required, Validators.email,
        Validators.pattern('^([\\w-]+(?:\\.[\\w-]+)*)@((?:[\\w-]+\\.)*\\w[\\w-]{0,66})\\.([A-Za-z]{2,6}(?:\\.[A-Za-z]{2,6})?)$')]),
        'customerId': new FormControl('', Validators.required),
        'qteCountry': new FormControl('', [Validators.required]),
        'isTnt': new FormControl(false),
    });

    credit_status = {
        "BK": "Bankruptcy",
        "CC": "Credit Card",
        "CR": "Credit Revoked",
        "MR": "Marginal",
        "NC": "No Credit",
        "OP": "Open",
        "UK": "Unknown"
    };
    countryList1: any;
    //'qteCountry' = new FormControl('', [Validators.required]);
    filteredOptions: Observable<any>;
    // qteCountry= new FormControl();
    filterValue: any;

    temp: string[] = [];

    constructor(private commonService: CommonService, private dialog: MatDialog, private router: Router) {
        // this.filteredFruits = this.fruitCtrl.valueChanges.pipe(
        //     startWith(null),
        //     map((fruit: string | null) => fruit ? this._filter(fruit) : this.allFruits.slice()));
    }

    ngOnInit(): void {
        this.countryList1 = SpsUtility.countryList;

        this.countryList = this.countryList1 ?
            this.countryList1.sort((a, b) => a.ctryName !== b.ctryName ? a.ctryName < b.ctryName ? -1 : 1 : 0)
            : this.countryList1;
        // this.ErrorMessage = ''; 
        this.filteredOptions = this.caller.controls.qteCountry.valueChanges
            .pipe(
                startWith(''),
                map(country => country && typeof country === 'object' ? country.ctryName : country)
                , map((country: string) => this._filter(country))
            );
        this.countryList1.forEach(element => {
            this.temp.push(element.ctryName);
        });


        // console.log("sunil venna",this.caller.controls.qteCountry);  
        //   console.log(this.temp);
        //   console.log(this.countryList);

    }


    private _filter(value: string): string[] {
        this.filterValue = value.toUpperCase();
        return this.countryList.filter(option => option.ctryName.toUpperCase().includes(value.toUpperCase()));
    }

    displayFn(country): string {
        return country ? country.ctryName : country;
    }



    toggleSearch(id) {
        // this.displayLoader = true;
        //        let param ={ "searchValue": id, "opCo": null, "ctryNm": "", "date": "", "userId": 4 },
        //        const custUrl = `${SpsUtility.urlParams.customerUrl.url}`;

        // this.commonService.getAPIResponse(custUrl,param,SpsUtility.urlParams.customerUrl.type).subscribe((custResponse: any) => {          


        const reqArr = [];
        const custDetails = {
            url: `${SpsUtility.urlParams.customerUrl.url}`,
            param: { "searchValue": id, "opCo": null, "ctryNm": "", "date": "", "userId": 4 },
            type: SpsUtility.urlParams.customerUrl.type
        }

        reqArr.push(custDetails);
        this.commonService.getGenericForkJoin(reqArr).subscribe((responseList: any) => {
            this.ErrorMessage = '';
            this.customerDetails = responseList[0];
            this.displayLoader = false;
            this.customerDetails.forEach(customer => {
                let creditCode = customer.creditStatus;
                customer['creditStatus_details'] = this.credit_status[creditCode];
                customer.custMail = customer.custMail.toLowerCase();
            });
            SpsUtility.commonStaticObject.customerDetails = this.customerDetails;

            // if (responseList[0] && responseList[0].status === 'EXCEPTION') {
            //     if (response.message) {
            //         this.commonService.showNotifier(response.message, 'error');
            //     } else {
            //         this.commonService.showNotifier('Error occurred while getting PT Data.', 'error');
            //     }
            //     return;
            // }

        }, (error) => {
            this.ErrorMessage = 'Customer is not found with given EAN number.';
            this.customerSearchShow = false;
        });


        this.customerSearchShow = true;
    }
    routetoshipment(cust) {
        let credit_codes = ['BK', 'CC', 'CR', 'MR', 'NC', 'OP', 'UK'];
        let gd_credit = ['CC', 'OP'];


        if (gd_credit.includes(cust.creditStatus.toUpperCase())) {
            SpsUtility.commonStaticObject.customerDetails = cust;
            //save caller Details
            let caller =
            {
                "userId": SpsUtility.userInfo.usrId,
                "callerTelNo": this.caller.value.telNo,
                "callerName": this.caller.value.name,
                "callerEmail": this.caller.value.email,
                "callerCountryName": this.caller.value.qteCountry ? this.caller.value.qteCountry.ctryName : this.caller.value.qteCountry,
                "customerEan": cust.custId,
                "customerName": cust.custFstNm,
                "customeAddress": cust.custAddr,
                "customeCity": cust.custCty,
                "customePostCode": cust.custPstlCd,
                "customeProvice": "",
                "customerTelNo": cust.custPh,
                "customerCtryName": cust.countryInfo.ctryName,
                "customerExtn": cust.custPhExt,
                "customerEmail": cust.custMail,
                "customerConTtl": "",
                "customerConFirstName": cust.custFstNm,
                "customerConFamName": "",
                "customerCreditStatus": cust.creditStatus,
                "customerCreditLimit": cust.creditLimit,
                "createdById": SpsUtility.userInfo.usrId,
                "lastModifiedById": SpsUtility.userInfo.usrId
            }

            const savecallerUrl = SpsUtility.urlParams.saveCallerUrl.url
            this.commonService.getAPIResponse(savecallerUrl, caller, SpsUtility.urlParams.saveCallerUrl.type).subscribe((callerResponse: any) => {
                SpsUtility.commonStaticObject.callerResponse = callerResponse;
                //  this.router.navigate(['/shipment']);
                this.router.navigate(['/shipment'], { queryParams: { route: 'customer' }, skipLocationChange: true });
            });
        }
        else {
            $("#badCreditAlertModal").modal();
            //alert("The customer cannot book a shipment at this time. Please follow your business processes or refer the customer to Accounts Receivable.");
        }

        // if (cust.creditStatus.toLowerCase() == 'bad') {
        //     alert("The customer cannot book a shipment at this time. Please follow your business processes or refer the customer to Accounts Receivable.");
        // }
        // else {
        //     SpsUtility.commonStaticObject.customerDetails = cust;
        //     this.router.navigate(['/shipment']);
        // }
    }

    // routeToGenerateTariff() {
    //     this.closeModal();
    //     this.router.navigate(['/generate']);
    // }
    // addcustomer() {
    //     this.addcustomers = !this.addcustomers;
    // }
    // closeModal() {
    //     try {
    //         this.dialogRef.close(null);
    //     } catch (e) {
    //         // Intentionally do nothing
    //     }
    // }
    // toggleImpl(e) {
    //     if (e.checked == true) {
    //         this.imperial_val = true;
    //     } else {
    //         this.imperial_val = false;
    //     }
    // }
    // add(event: MatChipInputEvent): void {
    //     // Add fruit only when MatAutocomplete is not open
    //     // To make sure this does not conflict with OptionSelected Event
    //     if (!this.matAutocomplete.isOpen) {
    //         const input = event.input;
    //         const value = event.value;

    //         // Add our fruit
    //         if ((value || '').trim()) {
    //             this.fruits = [];
    //             this.fruits.push(value.trim());
    //         }

    //         // Reset the input value
    //         if (input) {
    //             input.value = '';
    //         }

    //         this.fruitCtrl.setValue(null);
    //     }
    // }

    // remove(fruit: string): void {
    //     const index = this.fruits.indexOf(fruit);

    //     if (index >= 0) {
    //         this.fruits.splice(index, 1);
    //     }
    // }

    // selected(event: MatAutocompleteSelectedEvent): void {
    //     this.fruits = [];
    //     this.fruits.push(event.option.viewValue);
    //     this.fruitInput.nativeElement.value = '';
    //     this.fruitCtrl.setValue(null);
    // }

    // private _filter(value: string): string[] {
    //     const filterValue = value.toLowerCase();

    //     return this.allFruits.filter(fruit => fruit.toLowerCase().indexOf(filterValue) === 0);
    // }

    // clickTree(event) {
    //     const element = event.target;
    //     $('.tree-cls').removeClass('purple');
    //     $(element).addClass('purple');
    // }

    // keyChange(event, i) {
    //     if (event && event.target) {
    //         if (this.changeDisc[i] <= 59) {
    //             this.discStyle[i] = this.discArr[59];
    //             this.selectedStatus = 'PreApproved';
    //             this.errNotification = 'Pre Approved';
    //             this.discType = 1;
    //         } else if (this.changeDisc[i] > 59 && this.changeDisc[i] < 70) {
    //             this.errNotification = 'Please escalate to Sales Manager for Discount Approval';
    //             this.discStyle[i] = this.discArr[60];
    //             this.discType = 2;
    //         } else if (this.changeDisc[i] >= 70) {
    //             this.selectedStatus = 'Strategic';
    //             this.errNotification = 'Please Create a Strategic Request';
    //             this.discStyle[i] = this.discArr[70];
    //             this.discType = 3;
    //         }
    //     }
    // }

    // discEditClick() {
    //     this.stepper.selectedIndex = 3;
    // }
}
