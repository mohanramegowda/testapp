import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { SPSCustomerComponent } from './sps-customer.component';
import { IsAuthorized } from 'app/common/guards/auth-guard';

const routes: Routes = [
    { path: 'create',     component: SPSCustomerComponent, canActivate: [IsAuthorized] },
    { path: 'sps/:salesFeedNumber',     component: SPSCustomerComponent },
    { path: 'sps/:salesFeedNumber/:countryId',     component: SPSCustomerComponent },
];


@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class SPSCustomerRoutingModule { }
