export const user = {   
  userRole : 'SPSAgent'
  // userRole : 'BillingAgent'
  };
  