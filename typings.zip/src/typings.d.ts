/* SystemJS module definition */
declare var module: NodeModule;
interface NodeModule {
  id: string;
}
import * as $ from 'jquery';
declare module "*.json" {
  const value: any;
  export default value;
}
