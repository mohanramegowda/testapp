export class FromAddressConfig {
    static config = {
        'shipmentFromAddressForm': {
            // 'name': 'address',
            // 'submitUrl': '',
            // 'form_name': 'address',
            // 'entity': 'address',
            'fields': [
                {
                    'name': 'custCoNm',
                    'inputType': 'text',
                    'type': 'input',
                    'label': 'Company Name',
                    'validations': [
                        {
                            'name': 'required',
                            'validator': '',
                            'message': 'Company Name Required'
                        }
                    ]
                },
                {
                    'name': 'custAddr',
                    'inputType': 'text',
                    'type': 'input',
                    'value': '',
                    'label': 'Address',
                    'validations': [
                        {
                            'name': 'required',
                            'validator': '',
                            'message': 'Address Required'
                        }
                    ]
                },
                {
                    'name': 'custAptSteName',
                    'inputType': 'text',
                    'type': 'input',
                    'label': 'APT/Suite (Optional)',
                    'validations': []
                },
                // {
                //     'name': 'custPh',
                //     'inputType': 'text',
                //     'type': 'input',
                //     'label': 'Contact Number',                                                        
                //     'validations': []
                // },
                // {
                //     'name': 'custTown',
                //     'inputType': 'text',
                //     'type': 'input',
                //     'label': 'Town',                                                           
                //     'validations': [  ]
                // },
                {
                    'name': 'custCty',
                    'inputType': 'text',
                    'type': 'input',
                    'label': 'Town/City',
                    'validations': [
                        {
                            'name': 'required',
                            'validator': '',
                            'message': 'Town/City Required'
                        }
                    ]
                },
                {
                    'name': 'custprov',
                    'inputType': 'text',
                    'type': 'input',
                    'label': 'Province',
                    'validations': [
                    ]
                },
                {
                    'name': 'countryInfo',
                    'inputType': 'text',
                    'type': 'input',
                    'label': 'Country',
                    'validations': [
                        {
                            'name': 'required',
                            'validator': '',
                            'message': 'Country Required'
                        }
                    ]
                },
                {
                    'name': 'custPstlCd',
                    'inputType': 'text',
                    'type': 'input',
                    'validations': [
                        {
                            'name': 'required',
                            'validator': '',
                            'message': 'Postal Required'
                        }
                    ],
                    'label': 'Postal'
                }
            ]
        }

    }
}
