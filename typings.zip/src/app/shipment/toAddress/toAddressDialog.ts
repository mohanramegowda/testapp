import { Component, Inject, OnInit } from '@angular/core';
import { VERSION, MatDialogRef, MatDialog, MatSnackBar, MAT_DIALOG_DATA } from '@angular/material';
import { ToAddressConfig } from '../shipment-toaddressConfig';
import { SpsUtility } from '../../common/SpsUtility'
import { FormControl, Validator, FormGroup, Validators } from '@angular/forms';
import { FieldConfig } from 'app/components/dyn-forms/field.interface';


@Component({
  selector: 'toAddress-dialog',
  templateUrl: './toAddressDialog.html',
  styles: ['.hoverClass {cursor: pointer;}']
})
export class ToAddressDialog implements OnInit{

  formGroups = { toAddress: null};
  ToAddressDynamicConfig: FieldConfig[] = [];
  toAddressDetails;

  message: any;
  confirmButtonText = "Yes"
  cancelButtonText = "Cancel"
  constructor(
    @Inject(MAT_DIALOG_DATA) private data: any,
    private dialogRef: MatDialogRef<ToAddressDialog>) {
      if(data){    
            if (data.buttonText) {
            this.confirmButtonText = data.buttonText.ok || this.confirmButtonText;
            this.cancelButtonText = data.buttonText.cancel || this.cancelButtonText;
            }
      }
  }

  ngOnInit(): void {
      console.log(SpsUtility.commonStaticObject.toAddress);
    //from address config
    const ToAddrcofigJSON = JSON.parse(JSON.stringify(ToAddressConfig.config.shipmentToAddressForm));
    if(SpsUtility.commonStaticObject.toAddress){
        this.toAddressDetails = SpsUtility.commonStaticObject.toAddress ;        
        this.toAddressDetails['countryInfo'] = SpsUtility.commonStaticObject.toAddress.country ? SpsUtility.commonStaticObject.toAddress.country : SpsUtility.commonStaticObject.toAddress.countryInfo;        
    } 
    else {
        this.toAddressDetails = null
    }

    this.formGroups.toAddress = this.buildField(ToAddrcofigJSON, this.toAddressDetails);
    this.ToAddressDynamicConfig = this.formGroups.toAddress.fieldsConfig;
  }
  close() {    
    SpsUtility.commonStaticObject.toAddress = this.formGroups.toAddress.value;    
    this.dialogRef.close();
  }

  onConfirmClick(): void {
    if (this.formGroups.toAddress.value.custCoNm != '' && this.formGroups.toAddress.value.custCoNm != undefined && this.formGroups.toAddress.value.custCoNm != null
    && this.formGroups.toAddress.value.custAddr != '' && this.formGroups.toAddress.value.custAddr != undefined && this.formGroups.toAddress.value.custAddr != null
    && this.formGroups.toAddress.value.custCty != '' && this.formGroups.toAddress.value.custCty != undefined && this.formGroups.toAddress.value.custCty != null
    && this.formGroups.toAddress.value.countryInfo != '' && this.formGroups.toAddress.value.countryInfo != undefined && this.formGroups.toAddress.value.countryInfo != null    
    && this.formGroups.toAddress.value.custPstlCd != '' && this.formGroups.toAddress.value.custPstlCd != undefined && this.formGroups.toAddress.value.custPstlCd != null) {
        SpsUtility.commonStaticObject.toAddress = this.formGroups.toAddress.value;    
        this.dialogRef.close(this.formGroups.toAddress.value);
    }
  }

  onFormGroupCreate(element) {
    if (this.formGroups && element && element.group) {
        this.formGroups[element.formName] = element.group;
        this.onChanges(element.group);
    }
}
onChanges(group) {
    group.valueChanges.subscribe(val => {
        // tslint:disable-next-line: forin
        for (const i in this.formGroups) {
            if (this.formGroups[i] && !this.formGroups[i].valid) {
                // this.stopStepper = true;
            } else if (this.formGroups[i]) {
                this.formGroups[i] = group;
            }
        }

    });
}
  buildField(frmCnfg = null, availableObject) {
    const fieldConfigMap = {};
    const formConfigObj: any = {};
    if (frmCnfg) {
        const config: any = JSON.parse(JSON.stringify(frmCnfg));
        const fieldConfigs: FieldConfig[] = [];
        if (config.fields) {
            config.fields.map((field) => {

                let elementConfig: FieldConfig;
                const elementObj: any = {};
                elementObj.inputType = field.inputType;
                elementObj.type = field.type;
                elementObj.label = field.label;
                elementObj.name = field.name;
                elementObj.styleClass = field.styleClass;
                elementObj.styleColor = field.styleColor;
                elementObj.disabled = field.disabled;
                if (field.value) {
                    elementObj.value = field.value;
                }
                if (field.options) {
                    elementObj.options = field.options;
                }

                // Override the default Value
                if (availableObject && availableObject[field.name]) {
                    if (field.type === 'select') {
                        elementObj.options = availableObject[field.name].values;
                        elementObj.value = availableObject[field.name].value;
                    } else {
                        elementObj.value = availableObject[field.name];
                    }

                    if (field.inputType === 'radio') {
                        elementObj.options = availableObject[field.name].values;
                        elementObj.value = availableObject[field.name].value;
                    } else {
                        elementObj.value = availableObject[field.name];
                    }

                    if (field.type === 'date') {
                        elementObj.dateFilter = availableObject[field.name].dateFilter;
                        if (availableObject[field.name].value) {
                            elementObj.value = availableObject[field.name].value;
                        } else {
                            elementObj.value = availableObject[field.name];
                        }
                    }

                    if (field.label === 'Country') {
                        if(availableObject[field.name].ctryName){
                            elementObj.value = availableObject[field.name].ctryName;
                        }else{
                        elementObj.value = availableObject[field.name];
                        }
                    }

                    if (field.label === 'Payer') {
                        console.log("=====");
                        console.log(field);
                        console.log(field.parent());

                    }
                    // elementObj.disabled = !!availableObject[field.name].disabled;
                }

                if (field.validations) {
                    let validator: Validator[];
                    const validatorArr = [];
                    field.validations.map((validation) => {
                        const validatorObj: any = {};
                        if (validation.name === 'required') {
                            validatorObj.name = validation.name;
                            validatorObj.validator = Validators.required;
                            validatorObj.message = validation.message;
                        } else if (validation.name === 'pattern') {
                            validatorObj.name = validation.name;
                            validatorObj.validator = Validators.pattern(validation.value);
                            validatorObj.message = validation.message;
                        } else if (validation.name === 'maxlength') {
                            validatorObj.name = validation.name;
                            validatorObj.validator = Validators.maxLength(validation.value);
                            validatorObj.message = validation.message;
                        } else if (validation.name === 'minlength') {
                            validatorObj.name = validation.name;
                            validatorObj.validator = Validators.minLength(validation.value);
                            validatorObj.message = validation.message;
                        }
                        validatorArr.push(validatorObj);
                    });
                    validator = validatorArr;
                    elementObj.validations = validator;
                }
                elementConfig = elementObj;
                fieldConfigs.push(elementConfig);
            });
        }
        formConfigObj.fieldsConfig = fieldConfigs;
        fieldConfigMap[formConfigObj.form_name] = formConfigObj;
    }
    return formConfigObj;
}

}