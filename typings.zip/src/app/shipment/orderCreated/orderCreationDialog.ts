import { Component, Inject, OnInit } from '@angular/core';
import { VERSION, MatDialogRef, MatDialog, MatSnackBar, MAT_DIALOG_DATA } from '@angular/material';
import { Router, ActivatedRoute } from '@angular/router';
import { SpsUtility } from '../../common/SpsUtility'
import { FormControl, Validator, FormGroup, Validators } from '@angular/forms';
import { FieldConfig } from 'app/components/dyn-forms/field.interface';


@Component({
  selector: 'orderCreation-dialog',
  templateUrl: './orderCreationDialog.html',
})
export class OrderCreationDialog implements OnInit{

  confirmButtonText = "OK";
  cancelButtonText = "Cancel";
  orderId;
  constructor(  private router: Router,
    private dialogRef: MatDialogRef<OrderCreationDialog>) {     
  }

  ngOnInit(): void {
    //from address config
    this.orderId = SpsUtility.commonStaticObject.consignmentDetailsResponseToGL.orderId ; 
  }

  onConfirmClick(): void {
    this.dialogRef.close()
    //this.router.navigate(['/manage']);
  }
 
}