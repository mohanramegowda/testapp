
import { Router, ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree, CanActivate } from '@angular/router';
import { CommonService } from '../common.service';
import { Observable } from 'rxjs';
import { Injectable } from '@angular/core';
import { RolesAndActionsService } from '../roles-actions.service';

@Injectable()
export class IsAuthorized implements CanActivate {
    constructor(private router: Router, private commonService: CommonService,
        private rolesAndActions: RolesAndActionsService) { }

    canActivate(route: ActivatedRouteSnapshot,
        state: RouterStateSnapshot): boolean | Observable<boolean> | Promise<boolean> {

        const isPermitted = this.checkPermission(state.url);
        if (!isPermitted) {
            this.commonService.showNotifier('You are not Authorized', 'warning');
        }
        return isPermitted;
    }

    private checkPermission(url: string) {
        switch (url) {
            case '/create': return this.rolesAndActions.CanViewInCreate();
                break;
            case '/manage': return this.rolesAndActions.CanViewOrderInManage();
                break;
            case '/invoice': return this.rolesAndActions.CanViewOrderInInvoice();
                break;
            case '/': return this.rolesAndActions.CanViewInHome();
        }

    }
}
