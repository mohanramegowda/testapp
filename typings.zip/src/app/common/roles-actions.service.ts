import { Injectable } from '@angular/core';
import { SpsUtility } from './SpsUtility';
import { CommonService } from './common.service';

@Injectable({
  providedIn: 'root'
})
export class RolesAndActionsService {
  activate: Boolean = true;
  actions = [];
  authorisedRoleActions = [];
  notAuthorisedRoleActions = [];

  roles: string[];
  roleUser: string;
  roleName: string;
  authorisationStatus: any;
  authorisationCompleted: boolean = false;

  // New ESC
  newRoleLiterals = {
    'spshome/manageorder/': ((value) => {
      if (value && value.isauthorized) {
        this.authorisedRoleActions.push({
          resourcePath: value.resourcePath,
          action: value.action
        });
      } else if (value && !value.isauthorized) {
        this.notAuthorisedRoleActions.push({
          resourcePath: value.resourcePath,
          action: value.action
        });
      }
    }),
    'spshome/invoice/': ((value) => {
      if (value && value.isauthorized) {
        this.authorisedRoleActions.push({
          resourcePath: value.resourcePath,
          action: value.action
        });
      } else if (value && !value.isauthorized) {
        this.notAuthorisedRoleActions.push({
          resourcePath: value.resourcePath,
          action: value.action
        });
      }
    }),
    'spshome/create/': ((value) => {
      if (value && value.isauthorized) {
        this.authorisedRoleActions.push({
          resourcePath: value.resourcePath,
          action: value.action
        });
      } else if (value && !value.isauthorized) {
        this.notAuthorisedRoleActions.push({
          resourcePath: value.resourcePath,
          action: value.action
        });
      }
    }),
    'spshome/': ((value) => {
      if (value && value.isauthorized) {
        this.authorisedRoleActions.push({
          resourcePath: value.resourcePath,
          action: value.action
        });
      } else if (value && !value.isauthorized) {
        this.notAuthorisedRoleActions.push({
          resourcePath: value.resourcePath,
          action: value.action
        });
      }
    })
  };

  constructor(private commonService: CommonService) { }

  procesRolesAndActions(response) {
    response.id = '3665677';
    SpsUtility.user = response.id;
    this.setUserDetails(response);
    const url = `${SpsUtility.urlParams.authorize.url}${response.id}`;
    this.authorisationStatus = this.commonService.getHttpLoginResponse(url);
    this.authorisationStatus.subscribe((authResponse: any) => {
      for (const i in authResponse) {
        if (Object.keys(this.newRoleLiterals).includes(authResponse[i].resourcePath)) {
          this.newRoleLiterals[authResponse[i].resourcePath](authResponse[i]);
        }
      }
      this.authorisationCompleted = true;
    });
  }

  private setUserDetails(response) {
    const userObj = {
      'usrWssoId': response.id,
      'usrFstNm': response.firstName,
      'usrLstNm': response.lastName,
      'usrAbbrn': '',
      'usrDesktopPh': response.telephoneNumber,
      'usrEmail': response.email.toLowerCase(),
      'usrCrteById': response.id,
      'usrMdfyById': response.id,
      'countryInfo': {
        'ctryNm': response.internationalcountry.toUpperCase(),
        'ctryCd': response.countryCode
      },
      'usrDeptNm': response.departmentname,
      'usrTitle': response.title
    }
    SpsUtility.userDetails = userObj;

  }

  CanCancelOrderInManage() {
    return (this.notAuthorisedRoleActions.filter((item: any) =>
      item.resourcePath === 'spshome/manageorder/' && item.action === 'cancelorder'
    ).length === 0);
  }

  CanCreateOrderInManage() {
    return (this.notAuthorisedRoleActions.filter((item: any) =>
      item.resourcePath === 'spshome/manageorder/' && item.action === 'create'
    ).length === 0);
  }

  CanDownloadInManage() {
    return (this.notAuthorisedRoleActions.filter((item: any) =>
      item.resourcePath === 'spshome/manageorder/' && item.action === 'Download'
    ).length === 0);
  }

  CanSendInManage() {
    return (this.notAuthorisedRoleActions.filter((item: any) =>
      item.resourcePath === 'spshome/manageorder/' && item.action === 'send'
    ).length === 0);
  }

  CanUpdateOrderInManage() {
    return (this.notAuthorisedRoleActions.filter((item: any) =>
      item.resourcePath === 'spshome/manageorder/' && item.action === 'Update'
    ).length === 0);
  }

  CanViewOrderInManage() {
    return (this.notAuthorisedRoleActions.filter((item: any) =>
      item.resourcePath === 'spshome/manageorder/' && item.action === 'view'
    ).length === 0);
  }

  CanCancelOrderInvoice() {
    return (this.notAuthorisedRoleActions.filter((item: any) =>
      item.resourcePath === 'spshome/invoice/' && item.action === 'cancelorder'
    ).length === 0);
  }

  CanCreateOrderInInvoice() {
    return (this.notAuthorisedRoleActions.filter((item: any) =>
      item.resourcePath === 'spshome/invoice/' && item.action === 'create'
    ).length === 0);
  }

  CanDownloadInInvoice() {
    return (this.notAuthorisedRoleActions.filter((item: any) =>
      item.resourcePath === 'spshome/invoice/' && item.action === 'Download'
    ).length === 0);
  }

  CanSendInInvoice() {
    return (this.notAuthorisedRoleActions.filter((item: any) =>
      item.resourcePath === 'spshome/invoice/' && item.action === 'send'
    ).length === 0);
  }

  CanUpdateOrderInInvoice() {
    return (this.notAuthorisedRoleActions.filter((item: any) =>
      item.resourcePath === 'spshome/invoice/' && item.action === 'Update'
    ).length === 0);
  }

  CanViewOrderInInvoice() {
    return (this.notAuthorisedRoleActions.filter((item: any) =>
      item.resourcePath === 'spshome/invoice/' && item.action === 'view'
    ).length === 0);
  }

  CanCancelOrderInCreate() {
    return (this.notAuthorisedRoleActions.filter((item: any) =>
      item.resourcePath === 'spshome/create/' && item.action === 'cancelorder'
    ).length === 0);
  }

  CanCreateOrderInCreate() {
    return (this.notAuthorisedRoleActions.filter((item: any) =>
      item.resourcePath === 'spshome/create/' && item.action === 'create'
    ).length === 0);
  }

  CanDownloadInCreate() {
    return (this.notAuthorisedRoleActions.filter((item: any) =>
      item.resourcePath === 'spshome/create/' && item.action === 'Download'
    ).length === 0);
  }

  CanSendInCreate() {
    return (this.notAuthorisedRoleActions.filter((item: any) =>
      item.resourcePath === 'spshome/create/' && item.action === 'send'
    ).length === 0);
  }

  CanUpdateInCreate() {
    return (this.notAuthorisedRoleActions.filter((item: any) =>
      item.resourcePath === 'spshome/create/' && item.action === 'Update'
    ).length === 0);
  }

  CanViewInCreate() {
    return (this.notAuthorisedRoleActions.filter((item: any) =>
      item.resourcePath === 'spshome/create/' && item.action === 'view'
    ).length === 0);
  }

  CanCancelOrderInHome() {
    return (this.notAuthorisedRoleActions.filter((item: any) =>
      item.resourcePath === 'spshome/' && item.action === 'cancelorder'
    ).length === 0);
  }

  CanCreateInHome() {
    return (this.notAuthorisedRoleActions.filter((item: any) =>
      item.resourcePath === 'spshome/' && item.action === 'create'
    ).length === 0);
  }

  CanDownloadInHome() {
    return (this.notAuthorisedRoleActions.filter((item: any) =>
      item.resourcePath === 'spshome/' && item.action === 'Download'
    ).length === 0);
  }

  CanSendInHome() {
    return (this.notAuthorisedRoleActions.filter((item: any) =>
      item.resourcePath === 'spshome/' && item.action === 'send'
    ).length === 0);
  }

  CanUpdateInHome() {
    return (this.notAuthorisedRoleActions.filter((item: any) =>
      item.resourcePath === 'spshome/' && item.action === 'Update'
    ).length === 0);
  }

  CanViewInHome() {
    return (this.notAuthorisedRoleActions.filter((item: any) =>
      item.resourcePath === 'spshome/' && item.action === 'view'
    ).length === 0);
  }
}
