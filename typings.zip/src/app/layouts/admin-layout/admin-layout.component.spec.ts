import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { BrowserDynamicTestingModule, platformBrowserDynamicTesting } from '@angular/platform-browser-dynamic/testing';

import { AdminLayoutModule } from './admin-layout.module';
import { AdminLayoutComponent } from './admin-layout.component';

fdescribe('AdminLayoutComponent', () => {
  let component: AdminLayoutComponent;
  let fixture: ComponentFixture<AdminLayoutComponent>;

  // beforeEach(async(() => {
  //   TestBed.resetTestEnvironment();
  //   TestBed.initTestEnvironment(BrowserDynamicTestingModule,
  //      platformBrowserDynamicTesting());

  //   TestBed.configureTestingModule({
  //     // declarations: [ AdminLayoutComponent ],
  //     imports: [AdminLayoutModule]
  //   })
  // }));

  beforeEach(() => {
    TestBed.resetTestEnvironment();
    TestBed.initTestEnvironment(BrowserDynamicTestingModule,
       platformBrowserDynamicTesting());

    TestBed.configureTestingModule({
      // declarations: [ AdminLayoutComponent ],
      imports: [AdminLayoutModule]
    })
  });

  TestBed.compileComponents().then(() => {
    console.log('create Test bed');
    fixture = TestBed.createComponent(AdminLayoutComponent);

    // Access the dependency injected component instance
    component = fixture.componentInstance;

    expect(component).toBeTruthy();

    // Access the element
    const element = fixture.nativeElement;

    // Detect changes as necessary
    fixture.detectChanges();

    // expect(element.textContent).toContain('something');
  });

  // beforeEach(() => {
  //   fixture = TestBed.createComponent(AdminLayoutComponent);
  //   component = fixture.componentInstance;
  //   fixture.detectChanges();
  // });

  // it('should create', () => {
  //   expect(component).toBeTruthy();
  // });
});
