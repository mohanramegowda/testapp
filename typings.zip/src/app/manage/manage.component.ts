import { Component, OnInit, ViewChild } from '@angular/core';
import { MatTableDataSource,MatDialog} from '@angular/material';
import { summaryDialog } from './summaryDialog/summaryDialog'
import {MatSort,Sort} from '@angular/material/sort';
import { SpsUtility } from '../common/SpsUtility';
import { CommonService } from '../common/common.service';
import { MatPaginator } from '@angular/material/paginator';
//import { SelectionModel } from '@angular/cdk/collections';
import { FormControl } from '@angular/forms';
//import { PeriodicElement } from 'app/invoicing/invoicing.component';

@Component({
  selector: 'app-booking',
  templateUrl: './manage.component.html',
  styleUrls: ['./manage.component.scss']
})
export class ManageComponent implements OnInit {
  displayedColumns = ["customerName","orderId","createdDate","fromCity","toCity","status","fedExEan","agentName"];
  dataSource = new MatTableDataSource<PeriodicElement>();

  //selection = new SelectionModel<OrderId>(true, []);

  @ViewChild(MatSort) sort: MatSort;
  
  managequoteList ; 

  customerNameFilter = new FormControl('');
  orderIdFilter = new FormControl();
  createdDateFilter = new FormControl();
  fromCityFilter = new FormControl('');
  toCityFilter = new FormControl('');
  statusFilter = new FormControl('');
  fedExEanFilter = new FormControl('');
  agentNameFilter = new FormControl('');
  

  globalFilter = '';

  filteredValues = {
    customerName: '', orderId:'', createdDate: '',
    fromCity: '',toCity: '', status: '', fedExEan: '',
    agentName: '',topFilter: false
  };




  showPagination: boolean = false;
  public array: any;
  public pageSize = 10;
  public currentPage = 0;
  positionValue = [];
  public totalSize = 0;
  specialServiceResponse: any;

  constructor( private dialog: MatDialog,private commonService: CommonService) {
   // this.dataSource.data=this.dataSource;
  //  this.dataSource.data=this.array;
  // this.dataSource.data = this.tableFilter();
    console.log("vvvvvvvvvvvvvvvvvvvvvvvvvv", this.dataSource.data)
    
  }
  @ViewChild(MatPaginator) paginator: MatPaginator;
  ngOnInit() {



    const specialServiceUrl = SpsUtility.urlParams.managequoteUrl.url + '&countryCd=' + SpsUtility.userDetails.countryInfo.ctryCd ;  
    this.commonService.getAPIResponse(specialServiceUrl, null, SpsUtility.urlParams.managequoteUrl.type).subscribe((specialServiceResponse) => {
         this.dataSource = new MatTableDataSource(specialServiceResponse);
         this.array=this.dataSource.data;
         console.log('swamy',this.dataSource)
       this.dataSource.filterPredicate = this.customFilterPredicate();
        // this.iterator();
        console.log('swamy11111',this.array)

        
    this.customerNameFilter.valueChanges.subscribe(customerName => {
      this.filteredValues.customerName = customerName;
      this.dataSource.filter = JSON.stringify(this.filteredValues);
      // this.filteredValues['topFilter'] = false;
    });

    this.orderIdFilter.valueChanges.subscribe(orderId => {
      this.filteredValues.orderId= orderId;
      this.dataSource.filter = JSON.stringify(this.filteredValues);
      // this.filteredValues['topFilter'] = false;
    });

    this.createdDateFilter.valueChanges.subscribe(createdDate => {
      this.filteredValues.createdDate = createdDate;
      this.dataSource.filter = JSON.stringify(this.filteredValues);
      // this.filteredValues['topFilter'] = false;
    });

    this.fromCityFilter.valueChanges.subscribe(fromCity => {
      this.filteredValues.fromCity = fromCity;
      this.dataSource.filter = JSON.stringify(this.filteredValues);
      // this.filteredValues['topFilter'] = false;
    });

    this.toCityFilter.valueChanges.subscribe(toCity => {
      this.filteredValues.toCity = toCity;
      this.dataSource.filter = JSON.stringify(this.filteredValues);
      // this.filteredValues['topFilter'] = false;
    });

    this.statusFilter.valueChanges.subscribe(status => {
      this.filteredValues.status = status;
      this.dataSource.filter = JSON.stringify(this.filteredValues);
      // this.filteredValues['topFilter'] = false;
    });

    this.fedExEanFilter.valueChanges.subscribe(fedExEan => {
      this.filteredValues.fedExEan = fedExEan;
      this.dataSource.filter = JSON.stringify(this.filteredValues);
      // this.filteredValues['topFilter'] = false;
    });


    this.agentNameFilter.valueChanges.subscribe(agentName => {
      this.filteredValues.agentName = agentName;
      this.dataSource.filter = JSON.stringify(this.filteredValues);
      // this.filteredValues['topFilter'] = false;
    });

    // this.dataSource.filterPredicate = this.createFilter();
    //  });


    


console.log("veeeraaaaaaaaaaa",this.specialServiceResponse)
//console.log("veeeraaaaaaaaaaa",this.myFilterPredicate)


this.dataSource.sort = this.sort;
this.array = this.dataSource.filteredData;
this.totalSize = this.array.length;
this.dataSource.paginator = this.paginator;

  })
  }

  applyFilter(filterValue: string) {
    let filter = {
      customerName: filterValue.trim().toLowerCase(),
      orderId: filterValue.trim().toLowerCase(),
      createdDate: filterValue.trim().toLowerCase(),
      fromCity: filterValue.trim().toLowerCase(),
      toCity: filterValue.trim().toLowerCase(),
      status: filterValue.trim().toLowerCase(),
      fedExEan: filterValue.trim().toLowerCase(),
      agentName: filterValue.trim().toLowerCase(),

      topFilter: true
    }
    this.dataSource.filter = JSON.stringify(filter)
  }



  customFilterPredicate() {
    const myFilterPredicate = function(data:PeriodicElement,        filter:string) :boolean {
      let searchTerms = JSON.parse(filter);
      // let nameFound = data.name.toString().trim().toLowerCase().indexOf(searchString.name.toLowerCase()) !== -1
      // let positionFound = data.position.toString().trim().indexOf      (searchString.position) !== -1
      let positionFound1 = data.customerName.toLowerCase().indexOf(searchTerms.customerName) !== -1 
      let positionFound2 =  data.orderId.toString().trim().indexOf(searchTerms.orderId) !== -1 
      let positionFound3 =    data.createdDate.toString().trim().indexOf(searchTerms.createdDate) !== -1 
      let positionFound4 =   data.fromCity.toLowerCase().indexOf(searchTerms.fromCity) !== -1 
      let positionFound5 =    data.toCity.toLowerCase().indexOf(searchTerms.toCity) !== -1 
      let positionFound6 =    data.status.toLowerCase().indexOf(searchTerms.status) !== -1 
      let positionFound7 =      data.fedExEan.toLowerCase().indexOf(searchTerms.fedExEan) !== -1 
      let positionFound8 =     data.agentName.toLowerCase().indexOf(searchTerms.agentName) !== -1;
      if (searchTerms.topFilter) {
          return positionFound1 || positionFound2 || positionFound3 || positionFound4 || positionFound5 || positionFound6 || positionFound7 || positionFound8
      } else {
        return positionFound1 && positionFound2 && positionFound3 && positionFound4 && positionFound5 && positionFound6 && positionFound7 && positionFound8
      }
    }
    return myFilterPredicate;
  }




  //   tableFilter ():(data: PeriodicElement, filter: any) => boolean {
  //     let filterFunction = function(data, filter) : boolean {
  //     let searchTerms = JSON.parse(filter);
  //     console.log(' data ', data);
  //     console.log(' searchTerms ', searchTerms)
        
  //     return  data.customerName.toLowerCase().indexOf(searchTerms.customerName) !== -1 &&
  //        data.orderId.toString().trim().indexOf(searchTerms.orderId) !== -1 &&
  //         data.createdDate.toString().trim().indexOf(searchTerms.createdDate) !== -1 &&
  //        data.fromCity.toLowerCase().indexOf(searchTerms.fromCity) !== -1 &&
  //        data.toCity.toLowerCase().indexOf(searchTerms.toCity) !== -1 &&
  //        data.status.toLowerCase().indexOf(searchTerms.status) !== -1 &&
  //       data.fedExEan.toLowerCase().indexOf(searchTerms.fedExEan) !== -1 &&
  //       data.agentName.toLowerCase().indexOf(searchTerms.agentName) !== -1;
  //     }
  //   return filterFunction;
  // }
  // applyFilter(filterValue: string) {
  //   this.dataSource.filter = filterValue.trim().toLowerCase();
  // }
 
//   applyFilter(filterValue:string) {
//      filterValue=filterValue
//        filterValue=filterValue.toLocaleLowerCase();
//        this.dataSource.filter = JSON.stringify(filterValue)
//     this.dataSource.filter=filterValue;
  
// }


  // applyFilter1(filter) {
  //   this.globalFilter = filter;
  //   this.dataSource.filter = JSON.stringify(this.filteredValues);
  // }

  // applyFilter(filterValue:string) {
  //   this.globalFilter = filterValue;
  //  this.dataSource.filter=filterValue;
  //   filterValue=filterValue.trim()
  //   filterValue=filterValue.toLocaleLowerCase();
  //   this.dataSource.filter=filterValue;

  // }

  convert(time, format) {
    var t = new Date(time);
    var tf = function (i) { return (i < 10 ? '0' : '') + i };
    return format.replace(/yyyy|MM|dd|HH|mm|ss/g, function (a) {
      switch (a) {
        case 'yyyy':
          return tf(t.getFullYear());
          break;
        case 'MM':
          return tf(t.getMonth() + 1);
          break;
        case 'mm':
          return tf(t.getMinutes());
          break;
        case 'dd':
          return tf(t.getDate());
          break;
        case 'HH':
          return tf(t.getHours());
          break;
        case 'ss':
          return tf(t.getSeconds());
          break;
      }
    })
  }

  iterator() {
    const end = (this.currentPage + 1) * this.pageSize;
    const start = this.currentPage * this.pageSize;
    const part = this.array.slice(start, end);
    this.dataSource.filteredData = part;
    //console.log(this.dataSource, "dataSoucr222222222222222222")
    if (this.array.length == 0) {
      this.currentPage = this.currentPage - 1;
      const end = (this.currentPage + 1) * this.pageSize;
      const start = this.currentPage * this.pageSize;
      const part = this.array.slice(start, end);
      this.dataSource.filteredData = part;
    }
  }
  handlePage(e: any) {
    this.currentPage = e.pageIndex;
    this.pageSize = (e.pageSize != undefined) ? e.pageSize : this.pageSize;
    this.iterator();

  }
  

  // ngAfterViewInit() {
  //   this.dataSource.sort = this.sort;
  //   this.dataSource.paginator = this.paginator;
    
  // }

  // applyFilter(filterValue: any) {
  //   filterValue = filterValue.trim(); // Remove whitespace
  //   filterValue = filterValue.toLowerCase(); // Datasource defaults to lowercase matches
    
  //   this.globalFilter = filterValue;
  //   this.dataSource.filter = JSON.stringify(this.filteredValues);
  //   this.dataSource.filteredData = filterValue;
  // }

  getDetailsbyOrder(row){
    console.log(row);

    //open dialog
    const dialogRef = this.dialog.open(summaryDialog, {
      disableClose: true,
      height: '750px',
      width: '900px',
      data: {
          message: row,
          buttonText: {
              ok: 'SAVE',
              cancel: 'NO'
          },
         // sendToCustomerValue :(row.status == 'QUOTED' || row.status == 'SEND TO CUSTOMER')  ? true : false 
      }
  });

  dialogRef.afterClosed().subscribe(result => {
      console.log(result); 
      
    if (result) {
            //get updated manage quote details 
            const specialServiceUrl = SpsUtility.urlParams.managequoteUrl.url + 'countryCd=' + SpsUtility.userDetails.countryInfo.ctryCd;

            this.commonService.getAPIResponse(specialServiceUrl, null, SpsUtility.urlParams.managequoteUrl.type).subscribe((specialServiceResponse: any) => {
              // SpsUtility.commonStaticObject.specialServiceResponse = specialServiceResponse;
              this.managequoteList = specialServiceResponse;
              this.dataSource = new MatTableDataSource(this.managequoteList);
              this.dataSource.sort = this.sort;
              this.dataSource.paginator = this.paginator;
              console.log("this.managequoteList", this.managequoteList);
            });
          } 
 
     
  });
  }
  
}

export interface PeriodicElement {
  customerName : string,
  orderId : any,
  createdDate : any,
  fromCity : string,
  toCity : string,
  status : string,
  fedExEan : string,
  agentName : string
}