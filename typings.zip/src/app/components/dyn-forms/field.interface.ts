export interface Validator {
    name: string;
    validator: any;
    message: string;
}
export interface FieldConfig {
    dateFilter?: (d: Date) => boolean;
    label?: string;
    name?: string;
    inputType?: string;
    id?: string;
    style?:string;
    options?: any[];
    collections?: any;
    type: string;
    value?: any;
    styleClass?: any;
    styleColor?: any;
    min?: any;
    max?: any;
    disabled?: boolean;
    multiSelect?: boolean;
    validations?: Validator[];
}
