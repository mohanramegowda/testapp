import {
    Component,
    EventEmitter,
    Input,
    OnChanges,
    OnInit,
    Output,
    NgZone
} from '@angular/core';
import {
    FormGroup,
    FormBuilder,
    Validators,
    FormControl
} from '@angular/forms';
import { FieldConfig, Validator } from '../field.interface';

@Component({
    exportAs: 'app-dynamic-form',
    selector: 'app-dynamic-form',
    template: `
    <form class="dynamic-form {{styleClass}}" [formGroup]="form" (submit)="onSubmit($event)">
    <div class="{{styleSubClass}}" *ngFor="let field of fields;">
    <ng-container dynamicField [required]="isRequired(field)"  [readonly]="disabled" [field]="field" [group]="form">
    </ng-container>
    </div>
    <ng-content></ng-content>
    </form>
    `,
    styles: []
})
export class DynamicFormComponent implements OnInit {
    @Input() fields: FieldConfig[] = [];
    @Input() styleClass = '';
    @Input() styleSubClass = '';
    @Input() formName = '';
    @Input() disabled;

    @Output() submit: EventEmitter<any> = new EventEmitter<any>();
    @Output() onFormGroupCreate: EventEmitter<any> = new EventEmitter<any>();

    form: FormGroup;

    get value() {
        return this.form.value;
    }
    constructor(private fb: FormBuilder, private zone: NgZone) { }

    ngOnInit() {
        this.zone.run(() => {
            this.form = this.createControl();
        });
        this.onFormGroupCreate.emit({ formName: this.formName, group: this.form });
    }

    onSubmit(event: Event) {
        event.preventDefault();
        event.stopPropagation();
        if (this.form.valid) {
            this.submit.emit(this.form.value);
        } else {
            this.validateAllFormFields(this.form);
        }
    }

    createControl() {
        const group = this.fb.group({});
        this.fields.forEach(field => {
            if (field.type === 'button') { return; }
            const control = this.fb.control(
                field.value,
                this.bindValidations(field.validations || [])
            );
            if (field.disabled) {
                control.disable();
            } else {
                control.enable();
            }
            group.addControl(field.name, control);
        });
        return group;
    }

    bindValidations(validations: any) {
        if (validations.length > 0) {
            const validList = [];
            validations.forEach(valid => {
                validList.push(valid.validator);
            });
            return Validators.compose(validList);
        }
        return null;
    }
    isRequired(field) {
        let required = false;
        if (field && field.validations) {
            field.validations.map((validation) => {
                required = validation.name === 'required' ? true : false;
            });
        }
        return required;
    }

    validateAllFormFields(formGroup: FormGroup) {
        Object.keys(formGroup.controls).forEach(field => {
            const control = formGroup.get(field);
            control.markAsTouched({ onlySelf: true });
            if (!this.form.controls[field].valid) {
                console.log(field);
            }
        });
    }
}
