export class ListColumn {
    name?: string;
    property?: string;
    visibleType: string;
    visible?: boolean;
    isModelProperty?: boolean;
    displayFn: any;
}
