import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ListComponent } from './list.component';
// import { TableListComponent } from 'app/table-list/table-list.component';

xdescribe('ListComponent', () => {
  let component: ListComponent;
  // let tableListComponent: TableListComponent;
  let fixture: ComponentFixture<ListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ListComponent]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ListComponent);
    // tableListComponent = TestBed.get(TableListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create the app', () => {
    expect(component).toBeTruthy();
  });

  it('should filter the results', () => {
    component.ngAfterViewInit();
    expect(this.tableListComponent.onFilterChange).toHaveBeenCalled();
  });
});
