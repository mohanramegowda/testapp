import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import 'hammerjs';
import { RangeSliderComponent } from './range-slider.component';
import { SliderHandlerEnum } from './range-slider.component';
import { DebugElement, SimpleChange } from '@angular/core';
import { By } from '@angular/platform-browser';

describe('RangeSliderComponent', () => {
    let rangeSlider: RangeSliderComponent;
    let fixture: ComponentFixture<RangeSliderComponent>;
    let sliderElem: DebugElement;
    let leftHandlerElem: DebugElement;
    let rightHandlerElem: DebugElement;

    const handlerIndex = SliderHandlerEnum;

    const defaultMinValue = 2000;
    const defaultMaxValue = 5000;
    const defaultStepValue = 500;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [RangeSliderComponent]
        })
            .compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(RangeSliderComponent);
        rangeSlider = fixture.componentInstance;

        rangeSlider.setMinValues = defaultMinValue;
        rangeSlider.setMaxValues = defaultMaxValue;
        rangeSlider.stepValue = defaultStepValue;

        fixture.detectChanges();

        sliderElem = fixture.debugElement;
        leftHandlerElem = sliderElem.query(By.css('.left-handle'));
        rightHandlerElem = sliderElem.query(By.css('.right-handle'));
    });

    it('should create "rangeSlider" with two handlers with correct position and correct values', () => {
        fixture.detectChanges();
        expect(rangeSlider).toBeTruthy();
        // Left handler and tooltip
        expect(leftHandlerElem.styles.left).toBe('0%', 'Left handler should be at left most side of slider');
        expect(leftHandlerElem.query(By.css('.handle-tooltip')).nativeElement.textContent).toBe(defaultMinValue.toString());
        // Right handler and tooltip
        expect(rightHandlerElem.styles.left).toBe('100%', 'Right handler should be at right most side of slider');
        expect(rightHandlerElem.query(By.css('.handle-tooltip')).nativeElement.textContent).toBe(defaultMaxValue.toString());
        // Values displayed at bottom of slider
        expect(sliderElem.query(By.css('.values > span:first-child')).nativeElement.textContent).toBe(defaultMinValue.toString());
        expect(sliderElem.query(By.css('.values > span:last-child')).nativeElement.textContent).toBe(defaultMaxValue.toString());
    });

    it('slider should display step indicator', () => {
        rangeSlider.showStepIndicator = true;
        rangeSlider.ngOnChanges({});
        fixture.detectChanges();

        const stepIndicatorElem = sliderElem.query(By.css('.step-indicators'));
        expect(stepIndicatorElem.query(By.css('span'))).toBeTruthy('Step indicator should be displayed!');

        rangeSlider.showStepIndicator = false;
        rangeSlider.ngOnChanges({});
        fixture.detectChanges();

        expect(stepIndicatorElem.query(By.css('span'))).toBeFalsy('Step indicator should not be displayed');
    });

    it('should palce left handler on the correct position based on selectedValues', () => {
        rangeSlider.setMinSelectedValues = 3000;
        rangeSlider.ngOnChanges({
            setMinSelectedValues: new SimpleChange(0, 3000, false)
        });
        fixture.detectChanges();
        const leftValue = trimPercentageValue(leftHandlerElem.styles.left);
        expect(leftValue).toBe('33.33%', 'Left handler should be position with respect to the min selected value');
    });

    it('should place right handler on the correct position based on selectedValues', () => {
        rangeSlider.setMaxSelectedValues = 4000;
        rangeSlider.ngOnChanges({
            setMaxSelectedValues: new SimpleChange(0, 4000, false)
        });
        fixture.detectChanges();
        const rightValue = trimPercentageValue(rightHandlerElem.styles.left);
        expect(rightValue).toBe('66.66%', 'Right handler should be position with respect to the max selected value');
    });

    it('Left handler should move on handlerSliding() method call', () => {
        fixture.detectChanges();
        const sliderWidth = +sliderElem.nativeElement.children[0].children[0].offsetWidth;
        expect(sliderWidth).toBeDefined('Width of slider should be defined');

        const event = {
            clientX: 0,
            preventDefault: () => { }
        };
        rangeSlider.setHandlerActive(event, handlerIndex.left);
        event.clientX = sliderWidth * 0.5; // taking half of slider width
        rangeSlider.handlerSliding(event);
        rangeSlider.setHandlerActiveOff();

        fixture.detectChanges();

        const expectValue = defaultMinValue + (defaultMaxValue - defaultMinValue) / 2;

        expect(leftHandlerElem.styles.left).toBe('50%', 'Left handler should be moved to the new value');
        expect(rightHandlerElem.styles.left).toBe('100%', 'Right handler should be at same the place');

        expect(leftHandlerElem.query(By.css('.handle-tooltip')).nativeElement.textContent).toBe(expectValue.toString());
    });

    it('Single range slider should only contain one handler', () => {
        rangeSlider.multiRange = false;
        rangeSlider.setMinSelectedValues = 2500;
        rangeSlider.ngOnChanges({
            setMinSelectedValues: new SimpleChange(0, 2500, false)
        });
        fixture.detectChanges();
        leftHandlerElem = sliderElem.query(By.css('.left-handle'));
        rightHandlerElem = sliderElem.query(By.css('.right-handle'));

        expect(leftHandlerElem).toBeTruthy('Left handler should not be hidden');
        expect(rightHandlerElem).toBeNull('Right handler should be hidden');

        const filler = sliderElem.query(By.css('div.filler > span'));
        expect(trimPercentageValue(filler.styles.width)).toBe('16.66%');
    });

    it('"isNullOrEmpty()" method should work as expected', () => {
        const temp = undefined; // undefined variable
        expect(rangeSlider.isNullOrEmpty({ id: 1 })).toBe(false, 'It should return false for a valid object');
        expect(rangeSlider.isNullOrEmpty('name')).toBe(false, 'It should return false for a valid string');
        expect(rangeSlider.isNullOrEmpty(null)).toBe(true, 'It should return true for NULL value');
        expect(rangeSlider.isNullOrEmpty(temp)).toBe(true, 'It should return true for undefined value');
        expect(rangeSlider.isNullOrEmpty('')).toBe(true, 'It should return true for empty string');
    });

    it('"findNextValidStepValue()" method should work as expected', () => {
        expect(rangeSlider.findNextValidStepValue(1000, 125)).toBe(100, 'It should return correct next valid step value');
    });

    it('"isNumberArray()" method should work as expected', () => {
        expect(rangeSlider.isNumberArray([2, 3, 4])).toBe(true, 'It should be return true for valid number array');
        expect(rangeSlider.isNumberArray([2, undefined, 4])).toBe(false, 'It should be return false for invalid number array');
        expect(rangeSlider.isNumberArray([])).toBe(false, 'It should be return false for a empty array');
        expect(rangeSlider.isNumberArray(null)).toBe(false, 'It should be return false for null value');
    });
});

function trimPercentageValue(value: string): string {
    return (value.length === 0) ? '' :
        value.substr(0, (value.length > 5) ? 5 : value.length - 1) + value.substr(-1, 1);
}
