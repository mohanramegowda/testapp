// import { async, ComponentFixture, TestBed } from '@angular/core/testing';
// import { BrowserDynamicTestingModule, platformBrowserDynamicTesting } from '@angular/platform-browser-dynamic/testing';
// import { DynamicFilterComponent } from './dynamic-filter.component';
// import { SpsUtility } from '../../common/SpsUtility';
// import { Observable } from 'rxjs';

// // import * as TTConfig from '../components/dynamic-filter/static-data/TT-screens-config.json';
// // import * as STConfig from '../components/dynamic-filter/static-data/ST-screens-config.json';
// import { CommonService } from 'app/common/common.service';


// const response = new Observable(observer => {
//   observer.next(LOginRes);
// });

// const LOginRes = {
//   'userId': '3535076',
//   'userFirstName': 'Roel',
//   'userLastName': 'Roeloffzen',
//   'countryCode': 'NL',
//   'userEmail': 'roel.roeloffzen@tnt.com',
//   'authroizes': {
//     'CountryLevelTariffHistory,Approve': false,
//     'OwnTariffHistory,Approve': false,
//     'PricingMD,Allow': false,
//     'SalesInput,Write': false,
//     'PricingAnalyst,Allow': false,
//     'AllTariffHistory,Approve': true,
//     'PricingManager,Allow': false,
//     'ApplicationLogin,Login': true,
//     'PricingEurope,Allow': false,
//     'PricingHQ,Allow': true
//   }
// }



// describe('DynamicFilterComponent', () => {
//   let component: DynamicFilterComponent;
//   let fixture: ComponentFixture<DynamicFilterComponent>;
//   let dynamicModel = {};
//   let commonService: CommonService;
//   // let SpsUtility: SpsUtility;

//   beforeEach(async(() => {
//     TestBed.resetTestEnvironment();
//     TestBed.initTestEnvironment(BrowserDynamicTestingModule,
//       platformBrowserDynamicTesting());

//     TestBed.configureTestingModule({
//       declarations: [DynamicFilterComponent]
//     })
//       .compileComponents();
//   }));

//   beforeEach(() => {
//     fixture = TestBed.createComponent(DynamicFilterComponent);
//     component = fixture.componentInstance;
//     dynamicModel = component.dynamicModel;
//     commonService = TestBed.get(CommonService);
//     console.log(JSON.parse(JSON.stringify(component)));
//     fixture.detectChanges();
//     spyOn(SpsUtility, 'wssoLoginHdr').and.returnValue(response);
//     expect(SpsUtility.userDetails.userId).toBe('3535076');
//   });

//   it('should create the app', () => {
//     expect(component).toBeTruthy();
//     // expect(SpsUtility.urlParams).toBeUndefined();
//   });

//   it('should show logged in user details', () => {
//     fixture.detectChanges();
//     component.getInitialData();
//     spyOn(SpsUtility, 'CountryDetails').and.returnValue(response);
//     expect(dynamicModel['CTRY_NM']).toBe('THE NETHERLANDS');
//     expect(dynamicModel['CTRY_CD_NM']).toBe('NL');
//     expect(dynamicModel['CURR_CD_NM']).toBe('EUR');
//   });
//   it('should change the currency based on the country when Tariff type is selected', () => {
//     spyOn(component, 'onSectionChange');
//     spyOn(SpsUtility, 'CountryTTSAvlDts').and.returnValue(response);
//     spyOn(SpsUtility, 'closestCountryTariffTypeRevInfo').and.returnValue(response);
//     fixture.detectChanges();
//   });
//   it('should change the currency based on the country when Standard type is selected', () => {
//     spyOn(component, 'onSectionChange');
//     spyOn(SpsUtility, 'stSettingsAvailableDates').and.returnValue(response);
//     spyOn(SpsUtility, 'closestStandardTariffDiscInfo').and.returnValue(response);
//     fixture.detectChanges();
//   });


// });
