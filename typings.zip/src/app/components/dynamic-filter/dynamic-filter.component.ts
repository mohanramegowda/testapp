import { Component, OnInit, Input, Output, OnChanges } from '@angular/core';
import { CommonService } from '../../common/common.service';
import { SpsUtility } from '../../common/SpsUtility';
import { MatSnackBar } from '@angular/material';
import { ActivatedRoute } from '@angular/router';
import { EventListener } from '@angular/core/src/debug/debug_node';


@Component({
  selector: 'app-dynamic-filter',
  templateUrl: './dynamic-filter.component.html',
  styleUrls: ['./dynamic-filter.component.css']
})
export class DynamicFilterComponent implements OnInit, OnChanges {


  @Input() initConfig: any;
  @Input() config: any;

  isFilterEx = true;
  filterValues = {};
  tableNames = [];
  filterFieldMap = {};
  filterFieldArr = [];

  dynamicModel = {};
  workingConfig: any = {};
  workingFilterFieldMap: any = {};
  workingFilterFieldArr: any = [];

  component: any;

  dynamicHierarchy: any = {};
  dynamicFlatMap: any = {};
  dynamicEvents: any = {};
  loggedInCountryCode = '';

  countryNameDetailsMap = {};
  countryIdDetailsMap = {};
  countryCodeDetailsMap = {};
  countryFlatArr = [];

  avlDtsCntryNmeMap = {};
  avlDtsCntryCdMap = {};
  avlDtsCntryIdMap = {};
  profileConfigName: any;
  enableFilter = true;
  // TODO: Remove this
  currentCountryNm = '';
  currentCountryVal = {};

  constructor(private commonService: CommonService) {
    this.component = this;
    this.loggedInCountryCode = (SpsUtility.userDetails && SpsUtility.userDetails.countryCode) ?
      SpsUtility.userDetails.countryCode : '';
    this.dynamicModel['spsFormatedDate'] = this.commonService.formatDateTime(new Date(), 'DD/MM/YYYY');
    this.dynamicModel['loggedInCountryCode'] = this.loggedInCountryCode;
    this.initFilterScreen();
  }

  ngOnInit() {

  }

  ngOnChanges() {
    this.initFilterScreen();
  }
  initFilterScreen() {
    if (!this.config) {
      return;
    }
    this.filterFieldMap = [];
    this.filterFieldArr = [];
    const fieldMap = this.filterFieldMap;
    const fieldArr = this.filterFieldArr;
    if (this.config.filters) {
      this.enableFilter = true;
      this.config.filters.map(function (cfg) {
        fieldMap[cfg.field] = cfg;
        fieldArr.push(cfg);
      });
    } else {
      this.enableFilter = false;
    }
    this.workingFilterFieldMap = JSON.parse(JSON.stringify(this.filterFieldMap)); // Deep Copy
    this.workingConfig = JSON.parse(JSON.stringify(this.config)); // Deep Copy
    this.workingFilterFieldArr = JSON.parse(JSON.stringify(this.filterFieldArr));
    if (this.config.eventConfig) {
      try {
        for (const i in this.config.eventConfig) {
          if (this.config.eventConfig[i]) {
            this.dynamicEvents[i] = this.config.eventConfig[i];
          }
        }
      } catch (e) {
        console.log(e);
      }
    }
    this.getInitialData();
  }

  resetFilters() {
    this.getInitialData();
  }

  onSectionChange($event, filter) {
    let isUpdate = false;
    if (!$event && !filter) {
      if (!this.currentCountryNm) {
        this.getAvailableDates(null, false, true);
        if (this.config.noDateConfiguration) {
          this.filterData();
        }
        return;
      } else {
        isUpdate = true;
        $event = this.currentCountryNm;
        filter = this.currentCountryVal;
      }
    }
    if (filter.hierarchyRoot && this.dynamicHierarchy[filter.field]
      && this.dynamicHierarchy[filter.field][$event] && !isUpdate) {
      const filteredObj = this.dynamicHierarchy[filter.field][$event];
      for (const i in filteredObj) {
        if (filteredObj[i] && this.filterFieldMap[i]) {
          if (this.filterFieldMap[i].type === 'dropdown' && this.filterFieldMap[i].field !== filter.field) {
            this.filterFieldMap[i].values = filteredObj[i];
            if (this.filterFieldMap[i].defaultValueField) {
              this.dynamicModel[i] = filteredObj[this.filterFieldMap[i].defaultValueField];
            } else if (this.filterFieldMap[i].defaultValue) {
              this.dynamicModel[i] = filteredObj.defaultValue;
            }
          } else {
            this.dynamicModel[i] = filteredObj[i];
          }
        }
      }
    }
    // else if (this.dynamicHierarchy[filter.field]) {
    //   this.dynamicHierarchy[filter.field] = [$event];
    // }
    if (filter.field === 'CTRY_NM') {
      this.currentCountryNm = $event;
      this.currentCountryVal = filter;
      if (!isUpdate) {
        this.dynamicModel['availableDates'] = '';
        this.filterFieldMap['availableDates'].values = [];
      }
      const countryCode = this.countryNameDetailsMap[$event].CTRY_CD_NM;
      SpsUtility.commonStaticObject.filteredCountryCode = countryCode;
      this.getAvailableDates(countryCode, false, isUpdate);
    }
  }

  filterData(filterType = null) {
    let filterURL;
    if (filterType && filterType === 'init') {
      filterURL = 'defaultGet'
    } else {
      filterURL = 'filterGet'
    }
    if (this.config.ajaxUrls[filterURL] && this.config.ajaxUrls[filterURL].url &&
      SpsUtility.baseParams[this.config.ajaxUrls[filterURL].url]) {
      let request: any = this.config.ajaxUrls[filterURL].defaultParams || {};
      if (this.config.ajaxUrls[filterURL].params) {
        for (const i in this.config.ajaxUrls[filterURL].params) {
          if (this.config.ajaxUrls[filterURL].params[i]) {
            request[this.config.ajaxUrls[filterURL].params[i]] = this.dynamicModel[i];
            if ([undefined, null].indexOf(this.dynamicModel[i]) > -1) {
              if (i === 'userId') {
                request[this.config.ajaxUrls[filterURL].params[i]] = 0;
              }
            }
          } else {
            request[i] = null;
          }
        }
      } else {
        request = this.dynamicModel;
      }
      if (this.config.clientFilter && filterURL === 'filterGet') {
        let clientFilterData = JSON.parse(JSON.stringify(SpsUtility.commonStaticObject[this.config.ajaxUrls[filterURL].url]));
        for (const i in request) {
          if (request[i] && ['type'].indexOf(i) === -1) {
            clientFilterData = clientFilterData.filter((ele) => {
              if (ele[i]) {
                // tslint:disable-next-line: triple-equals
                return ele[i] == request[i]
              } else {
                return true;
              }
            });
          }
        }
        if (clientFilterData && clientFilterData.length === 0) {
          this.commonService.showNotifier('No Data found!', 'warning');
        }
        this.commonService.updateFilteredResults(clientFilterData);
      } else {
        const baseUrl = (this.config.ajaxUrls[filterURL].isAdminUrl) ? SpsUtility.baseParams.adminServiceBaseUrl.url
          : SpsUtility.baseParams.businessServiceBaseUrl.url;
        const url = baseUrl + SpsUtility.baseParams[this.config.ajaxUrls[filterURL].url].url;
        const type = SpsUtility.baseParams[this.config.ajaxUrls[filterURL].url].type;
        this.commonService.getAPIResponse(url, request, type)
          .subscribe((data: any) => {
            if (!data) {
              return;
            }
            if (data && data.status === 'EXCEPTION') {
              this.commonService.showNotifier(data.message, 'error');
              return;
            }
            if (data && data.length === 0) {
              this.commonService.showNotifier('No Data Found!', 'warning');
            }
            if (this.config.ajaxUrls[filterURL].storeData) {
              SpsUtility.commonStaticObject[this.config.ajaxUrls[filterURL].url] = data;
            }
            this.commonService.updateFilteredResults(data);
          }, (error) => {
            console.log(error);
            this.commonService.showNotifier('An error occurred while filtering data.', 'error');
          })
      }
    } else {
      this.commonService.showNotifier('Filter config is incorrect!', 'error');
    }
  }

  getInitialData() {
    this.initializeScreen();
    const countryCodeDetailsMap = this.countryCodeDetailsMap = {};
    const countryFlatArr = this.countryFlatArr = [];
    const countryIdDetailsMap = this.countryIdDetailsMap = {};
    const countryNameDetailsMap = this.countryNameDetailsMap = {};
    if (this.config && this.config.ajaxUrls && this.config.ajaxUrls.init) {
      if (this.config.ajaxUrls && this.config.ajaxUrls.init.countryDetails) {
        const url = SpsUtility.baseParams.businessServiceBaseUrl.url +
          SpsUtility.baseParams[this.config.ajaxUrls.init.countryDetails.url].url;
        const type = SpsUtility.baseParams[this.config.ajaxUrls.init.countryDetails.url].type;
        const request = this.config.ajaxUrls.init.countryDetails.defaultRequest || null;
        const loggedInCountryCode = this.loggedInCountryCode;
        const dynamicModel = this.dynamicModel;
        this.commonService.getAPIResponse(url, request, type).subscribe((data) => {
          if (data && data.length > 0) {
            SpsUtility.commonStaticObject.countryCodeArr = [];
            data.map((country) => {
              countryCodeDetailsMap[country.CTRY_CD_NM] = country;
              countryFlatArr.push(country);
              countryIdDetailsMap[country.CTRY_ID_NBR] = country;
              countryNameDetailsMap[country.CTRY_NM] = country;
              if (!SpsUtility.commonStaticObject.countryNameDetailsMap) {
                SpsUtility.commonStaticObject.countryNameDetailsMap = {};
              }
              if (!SpsUtility.commonStaticObject.countryCodeArr) {
                SpsUtility.commonStaticObject.countryCodeArr = [];
              }
              SpsUtility.commonStaticObject.countryCodeArr.push({ value: country.CTRY_CD_NM, name: country.CTRY_NM });
              SpsUtility.commonStaticObject.countryNameDetailsMap[country.CTRY_NM] = country;
              if ((country.CTRY_CD_NM === loggedInCountryCode)) {
                dynamicModel['CTRY_NM'] = country.CTRY_NM;
                dynamicModel['CTRY_CD_NM'] = country.CTRY_CD_NM;
                dynamicModel['CURR_CD_NM'] = country.CURR_CD_NM;
                SpsUtility.commonStaticObject.filteredCountryCode = country.CTRY_CD_NM;
              }
            });
            this.dynamicHierarchy['CTRY_NM'] = countryNameDetailsMap;
            if (this.filterFieldMap['CTRY_NM']) {
              this.filterFieldMap['CTRY_NM'].values = Object.keys(countryNameDetailsMap);
            }

            if (this.config.ajaxUrls.init.availableDates) {
              this.avlDtsCntryNmeMap = {};
              this.avlDtsCntryCdMap = {};
              this.avlDtsCntryIdMap = {};
              this.getAvailableDates(null, true);
            } else {
              if (this.config.noDateConfiguration) {
                this.filterData('init');
              } else {
                this.commonService.showNotifier('No Available Dates Configured!', 'warning');
              }
            }
          } else {
            this.commonService.showNotifier('No Country Level Details Found!', 'error');
          }
        }, (error) => {
          console.log(error);
          this.commonService.showNotifier('An error occurred while getting filters.', 'error');
        });
      } else {
        this.commonService.showNotifier('No Country Level Details Found!', 'warning');
      }
    }
  }

  getAvailableDates(countryCode = null, isInit = false, isUpdate = false) {
    if (this.config.ajaxUrls.init.availableDates) {
      const url = SpsUtility.baseParams.businessServiceBaseUrl.url +
        SpsUtility.baseParams[this.config.ajaxUrls.init.availableDates.url].url;
      const type = SpsUtility.baseParams[this.config.ajaxUrls.init.availableDates.url].type;
      const request = this.config.ajaxUrls.init.availableDates.defaultRequest || null;
      let paramCountryCode = '';
      if (this.config.ajaxUrls.init.availableDates.dynamicParam) {
        const params = this.config.ajaxUrls.init.availableDates.dynamicParam;
        for (const i in params) {
          if (params[i]) {
            request[i] = countryCode || this.dynamicModel[params[i]];
            paramCountryCode = countryCode || this.dynamicModel[params[i]];
          }
        }
      }
      this.commonService.getAPIResponse(url, request, type).subscribe((availableDateData: any) => {
        if (availableDateData && availableDateData.length > 0 &&
          availableDateData[0].AVAILABLE_DATE_ARRAY && availableDateData[0].AVAILABLE_DATE_ARRAY.length > 0) {
          this.avlDtsCntryNmeMap[this.countryCodeDetailsMap[paramCountryCode].CTRY_NM] = availableDateData[0].AVAILABLE_DATE_ARRAY;
          this.avlDtsCntryCdMap[paramCountryCode] = availableDateData[0].AVAILABLE_DATE_ARRAY;
          this.avlDtsCntryIdMap[this.countryCodeDetailsMap[paramCountryCode].CTRY_ID_NBR] = availableDateData[0].AVAILABLE_DATE_ARRAY;
          const existingDate = this.dynamicModel['availableDates'];
          if (this.filterFieldMap['availableDates']) {
            this.filterFieldMap['availableDates'].values = availableDateData[0].AVAILABLE_DATE_ARRAY;
          }
          if (this.config.ajaxUrls.init.closestDate) {
            if (isUpdate && availableDateData[0].AVAILABLE_DATE_ARRAY
              && availableDateData[0].AVAILABLE_DATE_ARRAY.indexOf(existingDate) === -1) {
              isUpdate = false;
              isInit = true;
            }
            if (isUpdate) {
              this.dynamicModel['availableDates'] = existingDate;
              this.filterData();
            } else {
              this.dynamicModel['availableDates'] = availableDateData[0].AVAILABLE_DATE_ARRAY;
              this.dynamicModel['availableDates'] = '';
              this.getClosestDate(paramCountryCode, isInit);
            }
          } else {
            this.commonService.showNotifier('No Closest Date Configured!', 'warning');
          }
        } else {
          this.commonService.showNotifier('No Available Dates found!', 'error');
        }
      });
    }
  }

  getClosestDate(countryCode = null, isInit = false) {
    const url = SpsUtility.baseParams.businessServiceBaseUrl.url +
      SpsUtility.baseParams[this.config.ajaxUrls.init.closestDate.url].url;
    const type = SpsUtility.baseParams[this.config.ajaxUrls.init.closestDate.url].type;
    const request = this.config.ajaxUrls.init.closestDate.defaultRequest || null;
    if (this.config.ajaxUrls.init.closestDate.dynamicParam) {
      const params = this.config.ajaxUrls.init.closestDate.dynamicParam;
      for (const i in params) {
        if (params[i]) {
          if (i === 'ctryCd') {
            request[i] = countryCode || this.dynamicModel[params[i]];
          } else {
            request[i] = this.dynamicModel[params[i]];
          }
        }
      }
    }
    this.commonService.getAPIResponse(url, request, type).subscribe((closestData: any) => {
      if (closestData && closestData.length > 0) {
        this.dynamicModel['availableDates'] = closestData[0].CLOSESTDATE;
        if (isInit) {
          this.filterData();
        }
      } else {
        this.commonService.showNotifier('No Closest Date found!', 'error');
      }
    });
  }

  formatDate(date) {
    return this.commonService.formatDateTime(new Date(date), 'DD/MM/YYYY');
  }

  initializeScreen() {
    for (const i in this.filterFieldMap) {
      if (this.filterFieldMap[i]) {
        this.dynamicModel[this.filterFieldMap[i].field] = this.filterFieldMap[i].defaultValue;
      }
    }
    this.dynamicModel['spsFormatedDate'] = this.commonService.formatDateTime(new Date(), 'DD/MM/YYYY');
    this.dynamicModel['newSpsFormatedDate'] = this.commonService.formatDateTime(new Date(), 'YYYY-MM-DDThh:mm:ss');
    this.dynamicModel['loggedInCountryCode'] = this.loggedInCountryCode;
  }

}
