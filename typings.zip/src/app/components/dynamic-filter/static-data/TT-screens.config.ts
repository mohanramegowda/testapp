export class TTConfig {
    static config = {
        'title': 'Tariff Type Setings',
        'subTitle': 'Configure Tariff Types',
        'advancedFilterTitle': 'Filter Tariff Types',
        'filters': [
            {
                'field': 'CTRY_NM',
                'displayName': 'Country',
                'defaultValue': '',
                'type': 'dropdown',
                'values': [],
                'hierarchyRoot': true
            },
            {
                'field': 'CTRY_CD_NM',
                'displayName': 'Country Code',
                'defaultValue': '',
                'type': 'input',
                'disabled': true,
                'inputType': 'text',
                'hierarchyParent': 'CTRY_NM'
            },
            {
                'field': 'CURR_CD_NM',
                'displayName': 'Currency',
                'defaultValue': '',
                'type': 'input',
                'disabled': true,
                'inputType': 'text',
                'hierarchyParent': 'CTRY_NM'
            },
            {
                'field': 'tariffType',
                'displayName': 'Tariff Type',
                'defaultValueField': 0,
                'defaultValue': 0,
                'type': 'dropdown',
                'dateDropDown': false,
                'kvp': true,
                'disabled': false,
                'values': [
                    {
                        'name': 'All',
                        'value': 0
                    },
                    {
                        'name': 'Standard Tariff',
                        'value': 1
                    },
                    {
                        'name': 'Fast track Tariff',
                        'value': 2
                    },
                    {
                        'name': 'Personalised Tariff',
                        'value': 3
                    }
                ],
                'hierarchyParent': ''
            },
            {
                'field': 'typNm',
                'displayName': 'Revenue Type',
                'defaultValueField': 0,
                'defaultValue': 'A',
                'type': 'dropdown',
                'disabled': false,
                'kvp': true,
                'values': [
                    {
                        'name': 'All',
                        'value': 'A'
                    },
                    {
                        'name': 'International',
                        'value': 'I'
                    },
                    {
                        'name': 'Domestic',
                        'value': 'D'
                    }
                ],
                'hierarchyParent': 'CTRY_NM'
            },
            {
                'field': 'availableDates',
                'displayName': 'Available Dates',
                'defaultValueField': 'currentDate',
                'defaultValue': '',
                'type': 'dropdown',
                'dateDropDown': true,
                'disabled': false,
                'hierarchyParent': 'CTRY_NM'
            }
        ],
        'ajaxUrls': {
            'defaultGet': {
                'url': 'getTariffTypes',
                'defaultParams': {
                    'type': 'ALL'
                },
                'params': {
                    'CTRY_CD_NM': 'country',
                    'availableDates': 'startDate',
                    'tariffType': 'tariffType',
                    'typNm': 'typNm'
                }
            },
            'filterGet': {
                'url': 'getTariffTypes',
                'defaultParams': {
                    'type': 'ALL'
                },
                'params': {
                    'CTRY_CD_NM': 'country',
                    'availableDates': 'startDate',
                    'tariffType': 'tariffType',
                    'typNm': 'typNm'
                }
            },
            'update': 'saveTariffTypes',
            'add': 'saveTariffTypes',
            'delete': 'deleteThreshold',
            'init': {
                'countryDetails': {
                    'url': 'CountryDetails',
                    'filterFieldMap': {
                        'CTRY_NM': 'CTRY_NM'
                    },
                    'defaultRequest': {
                        'type': 'ALL'
                    },
                    'dynamicParam': null
                },
                'availableDates': {
                    'url': 'CountryTTSAvlDts',
                    'filterFieldMap': {
                        'AVAILABLE_DATE_ARRAY': 'availableDates'
                    },
                    'defaultRequest': {
                        'type': 'GET'
                    },
                    'dynamicParam': {
                        'ctryCd': 'loggedInCountryCode'
                    }
                },
                'closestDate': {
                    'url': 'TTSClosestDate',
                    'dynamicModelMap': {
                        'CLOSESTDATE': 'availableDates'
                    },
                    'defaultRequest': {
                        'type': 'GET'
                    },
                    'dynamicParam': {
                        'ctryCd': 'loggedInCountryCode',
                        'inputValue': 'newSpsFormatedDate'
                    }
                },
                'url': null
            }
        },
        'eventConfig': {
            'init': '',
            'get': 'if(payload && payload.component) { if(payload.getResponse) { payload.getResponse.map(function(response){ if(response.TRF_TYP_ID_NBR === 1) { response.TRF_TYP = "Standard Tariff"; } else if(response.TRF_TYP_ID_NBR === 2) { response.TRF_TYP = "Fast Track Tariff"; } else if(response.TRF_TYP_ID_NBR === 3) { response.TRF_TYP = "Personalised Tariff"; } if(response.REV_TYP_NM === "D") { response.REV_TYP = "Domestic"; } else { response.REV_TYP = "International"; } response.countryCode = response.CTRY_CD_NM;  }); } } return payload.getResponse;',
            'add': 'var arr = []; if(payload && payload.component) { var revTypeStr = "international"; if(payload.createData.premiumType === "D") { revTypeStr = "domestic"; } var thresholdObj = { trfTypRevIdNbr: null, trfTypIdNbr: parseInt(payload.createData.trfTypIdNbr), effectiveDate: payload.component.gridChangeFormat(payload.createData.effectiveDate), countryCode: payload.createData.countryCode, loggedInUserId: payload.utility.userDetails.userId, threshHoldDetail: { tariffTypeid: parseInt(payload.createData.trfTypIdNbr), premiumType: payload.createData.premiumType}}; thresholdObj.threshHoldDetail[revTypeStr] = { entryPoint: parseFloat(payload.createData.entryPoint), exitPoint: parseFloat(payload.createData.exitPoint) }; arr.push(thresholdObj); } return arr;',
            'update': 'var arr = []; if(payload && payload.component) { if(payload.updateArr) { payload.updateArr.map(function(updateObj) { var tariffTypeId = 1; var revTypeChr = "I"; var revTypeStr = "international"; if(updateObj.TRF_TYP === "Standard Tariff") { tariffTypeId = 1; } else if(updateObj.TRF_TYP === "Fast Track Tariff") { tariffTypeId = 2; } else if(updateObj.TRF_TYP === "Personalised Tariff") { tariffTypeId = 3; } if(updateObj.REV_TYP === "Domestic") { revTypeChr = "D"; revTypeStr = "domestic"; } var thresholdObj = { trfTypRevIdNbr: updateObj.TRF_TYP_REV_ID_NBR, trfTypIdNbr: tariffTypeId, effectiveDate: payload.component.gridChangeFormat(updateObj.EFF_DT), countryCode: updateObj.countryCode, loggedInUserId: payload.utility.userDetails.userId, threshHoldDetail: { tariffTypeid: tariffTypeId, premiumType: revTypeChr }  }; thresholdObj.threshHoldDetail[revTypeStr] = { entryPoint: parseFloat(updateObj.MIN_TRF_REV_AMT), exitPoint: parseFloat(updateObj.MAX_TRF_REV_AMT) }; arr.push(thresholdObj); });  } } return arr;',
            'delete': 'var obj = {}; if(payload && payload.component) { if(payload.deleteData) { obj.trfTypRevIdNbr = payload.deleteData.TRF_TYP_REV_ID_NBR;} } return obj;'
        },
        'crudConfig': {},
        'table': [
            {
                'name': 'ID',
                'property': 'TRF_TYP_REV_ID_NBR',
                'visibleType': 'TRF_TYP_REV_ID_NBR',
                'type': 'number',
                'inputType': 'text',
                'visible': false,
                'editable': false,
                'isModelProperty': true,
                'showEdit': false,
                'isPrimaryKey': true
            },
            {
                'name': 'Tariff Type',
                'property': 'TRF_TYP',
                'visibleType': 'TRF_TYP',
                'type': 'dropdown',
                'transformMap': {
                    'Standard Tariff': '1',
                    'Fast Track Tariff': '2',
                    'Personalised Tariff': '3'
                },
                'values': [
                    {
                        'value': 'Standard Tariff',
                        'name': 'Standard Tariff'
                    },
                    {
                        'value': 'Fast Track Tariff',
                        'name': 'Fast Track Tariff'
                    },
                    {
                        'value': 'Personalised Tariff',
                        'name': 'Personalised Tariff'
                    }
                ],
                'visible': true,
                'editable': true,
                'isModelProperty': true,
                'showEdit': true
            },
            {
                'name': 'Revenue Type',
                'property': 'REV_TYP',
                'visibleType': 'REV_TYP',
                'type': 'dropdown',
                'transformMap': {
                    'Domestic': 'D',
                    'International': 'I'
                },
                'values': [
                    {
                        'value': 'Domestic',
                        'name': 'Domestic'
                    },
                    {
                        'value': 'International',
                        'name': 'International'
                    }
                ],
                'visible': true,
                'editable': true,
                'isModelProperty': true,
                'showEdit': true
            },
            {
                'name': 'Minimum',
                'property': 'MIN_TRF_REV_AMT',
                'visibleType': 'MIN_TRF_REV_AMT',
                'type': 'number',
                'inputType': 'text',
                'visible': true,
                'editable': true,
                'isModelProperty': true,
                'showEdit': true
            },
            {
                'name': 'Maximum',
                'property': 'MAX_TRF_REV_AMT',
                'visibleType': 'MAX_TRF_REV_AMT',
                'type': 'number',
                'inputType': 'text',
                'visible': true,
                'editable': true,
                'isModelProperty': true
            },
            {
                'name': 'Effective Date',
                'property': 'EFF_DT',
                'visibleType': 'EFF_DT',
                'type': 'date',
                'visible': true,
                'editable': true,
                'isModelProperty': true
            },
            {
                'name': 'Country',
                'property': 'countryCode',
                'visibleType': 'countryCode',
                'type': 'dropdown',
                'utilFieldNm': 'countryCodeArr',
                'values': [],
                'visible': true,
                'editable': true,
                'isModelProperty': true,
                'showEdit': true
            }
        ],
        'createUpdateForm': {
            'name': 'Test',
            'submitUrl': '',
            'form_name': 'tts',
            'entity': 'tts',
            'fields': [
                {
                    'label': 'Country',
                    'name': 'countryCode',
                    'type': 'select',
                    'required': true,
                    'inputType': 'text',
                    'value': '',
                    'utilFieldNm': 'countryCodeArr',
                    'defaultValueRef': 'filteredCountryCode',
                    'options': [],
                    'validations': [
                        {
                            'name': 'required',
                            'validator': '',
                            'message': 'country Required'
                        }
                    ]
                },
                {
                    'label': 'Tariff Type',
                    'name': 'trfTypIdNbr',
                    'type': 'select',
                    'required': true,
                    'inputType': 'text',
                    'value': '1',
                    'options': [
                        {
                            'value': '1',
                            'name': 'Standard Tariff'
                        },
                        {
                            'value': '2',
                            'name': 'Fast Track Tariff'
                        },
                        {
                            'value': '3',
                            'name': 'Personalised Tariff'
                        }
                    ],
                    'validations': [
                        {
                            'name': 'required',
                            'validator': '',
                            'message': 'Tariff Type Required'
                        }
                    ]
                },
                {
                    'label': 'Revenue Type',
                    'name': 'premiumType',
                    'type': 'select',
                    'required': true,
                    'inputType': 'text',
                    'value': 'D',
                    'options': [
                        {
                            'value': 'D',
                            'name': 'Domestic'
                        },
                        {
                            'value': 'I',
                            'name': 'International'
                        }
                    ],
                    'validations': [
                        {
                            'name': 'required',
                            'validator': '',
                            'message': 'Tariff Type Required'
                        }
                    ]
                },
                {
                    'label': 'Minimum',
                    'name': 'entryPoint',
                    'type': 'input',
                    'value': 0,
                    'required': true,
                    'inputType': 'number',
                    'validations': [
                        {
                            'name': 'required',
                            'validator': '',
                            'message': 'Minimum Value Required'
                        },
                        {
                            'name': 'pattern',
                            'validator': '^[1-9]+[0-9]*$',
                            'message': 'Only Positive Whole Numbers Required'
                        }
                    ]
                },
                {
                    'label': 'Maximum',
                    'name': 'exitPoint',
                    'type': 'input',
                    'required': true,
                    'value': 0,
                    'inputType': 'number',
                    'validations': [
                        {
                            'name': 'required',
                            'validator': '',
                            'message': 'Maximum Value Required'
                        },
                        {
                            'name': 'pattern',
                            'validator': '^[1-9]+[0-9]*$',
                            'message': 'Only Positive Whole Numbers Required'
                        }
                    ]
                },
                {
                    'label': 'Effective Date',
                    'name': 'effectiveDate',
                    'type': 'date',
                    'required': true,
                    'value': 0,
                    'inputType': 'date',
                    'validations': [
                        {
                            'name': 'required',
                            'validator': '',
                            'message': 'Effective Date Required'
                        }
                    ]
                },
                {
                    'type': 'button',
                    'inputType': 'submit',
                    'styleColor': 'primary',
                    'styleClass': 'float-right',
                    'label': 'Add Setting'
                }
            ]
        }
    }
}
