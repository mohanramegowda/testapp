export class PTConfig {
    static config = {
        'title': 'Personalized Tariff Setings',
        'subTitle': 'Configure Standard Tariff',
        'advancedFilterTitle': 'Filter Standard Tariff',
        'filters': [{
                'field': 'CTRY_NM',
                'displayName': 'Country',
                'defaultValue': '',
                'type': 'dropdown',
                'values': [],
                'hierarchyRoot': true
            }, {
                'field': 'CTRY_CD_NM',
                'displayName': 'Currency',
                'defaultValue': '',
                'type': 'input',
                'disabled': true,
                'inputType': 'text',
                'hierarchyParent': 'countryName'
            },
            {
                'field': 'tariffType',
                'displayName': 'Tariff Type',
                'defaultValueField': 0,
                'defaultValue': 0,
                'type': 'dropdown',
                'dateDropDown': false,
                'kvp': true,
                'disabled': false,
                'values': [{
                        'name': 'All',
                        'value': 0
                    },
                    {
                        'name': 'Standard Tariff',
                        'value': 1
                    },
                    {
                        'name': 'Fast track Tariff',
                        'value': 2
                    },
                    {
                        'name': 'Personalised Tariff',
                        'value': 3
                    }
                ],
                'hierarchyParent': ''
            },
            {
                'field': 'typNm',
                'displayName': 'Revenue Type',
                'defaultValueField': 0,
                'defaultValue': 'A',
                'type': 'dropdown',
                'disabled': false,
                'kvp': true,
                'values': [{
                        'name': 'All',
                        'value': 'A'
                    },
                    {
                        'name': 'International',
                        'value': 'I'
                    },
                    {
                        'name': 'Domestic',
                        'value': 'D'
                    }
                ],
                'hierarchyParent': 'CTRY_NM'
            },
            {
                'field': 'availableDates',
                'displayName': 'Start Date',
                'defaultValue': '',
                'type': 'dropdown',
                'dateDropDown': true,
                'disabled': false,
                'hierarchyParent': 'countryName'
            }
        ],
        'ajaxUrls': {
            'defaultGet': {
                'url': 'notificationSettings',
                'defaultParams': {
                    'type': 'ALL'
                },
                'params': {
                    'CTRY_CD_NM': 'ctryCd',
                    'availableDates': 'startDate',
                    'tariffType': 'tariffType',
                    'typNm': 'typNm'
                }
            },
            'filterGet': {
                'url': 'notificationSettings',
                'defaultParams': {
                    'type': 'GET'
                },
                'params': {
                    'CTRY_CD_NM': 'ctryCd',
                    'availableDates': 'startDate',
                    'tariffType': 'tariffType',
                    'typNm': 'typNm'
                }
            },
            'update': '',
            'add': '',
            'delete': '',
            'init': {
                'countryDetails': {
                    'url': 'CountryDetails',
                    'filterFieldMap': {
                        'CTRY_NM': 'CTRY_NM'
                    },
                    'defaultRequest': {
                        'type': 'ALL'
                    },
                    'dynamicParam': null
                },
                'availableDates': {
                    'url': 'notificationSettingsAvailableDates',
                    'filterFieldMap': {
                        'AVAILABLE_DATE_ARRAY': 'availableDates'
                    },
                    'defaultRequest': {
                        'type': 'GET'
                    },
                    'dynamicParam': {
                        'ctryCd': 'loggedInCountryCode'
                    }
                },
                'closestDate': {
                    'url': 'closestNotificationInfo',
                    'dynamicModelMap': {
                        'CLOSESTDATE': 'availableDates'
                    },
                    'defaultRequest': {
                        'type': 'GET'
                    },
                    'dynamicParam': {
                        'ctryCd': 'loggedInCountryCode',
                        'inputValue': 'newSpsFormatedDate'
                    }
                },
                'url': null
            }
        },
        'filterConfig': {},
        'crudConfig': {},
        'table': [{
                'name': 'Notifications',
                'editable': false,
                'property': 'TEMPL_TITLE_NM',
                'visibleType': 'TEMPL_TITLE_NM',
                'visible': true,
                'type': 'input',
                'inputType': 'text',
                'dropDownValues': '',
                'isModelProperty': true
            },
            {
                'name': 'Tariff Type',
                'property': 'TRF_TYP_ID_NBR',
                'visibleType': 'TRF_TYP_ID_NBR',
                'type': 'dropdown',
                'transformMap': {
                    'Standard Tariff': '1',
                    'Fast Track Tariff': '2',
                    'Personalised Tariff': '3'
                },
                'values': [{
                        'value': 'Standard Tariff',
                        'name': 'Standard Tariff'
                    },
                    {
                        'value': 'Fast Track Tariff',
                        'name': 'Fast Track Tariff'
                    },
                    {
                        'value': 'Personalised Tariff',
                        'name': 'Personalised Tariff'
                    }
                ],
                'visible': true,
                'editable': true,
                'isModelProperty': true,
                'showEdit': true
            },
            {
                'name': 'Revenue Type',
                'property': 'TRF_PRMUM_TYP_NM',
                'visibleType': 'TRF_PRMUM_TYP_NM',
                'type': 'dropdown',
                'transformMap': {
                    'Domestic': 'D',
                    'International': 'I'
                },
                'values': [{
                        'value': 'Domestic',
                        'name': 'Domestic'
                    },
                    {
                        'value': 'International',
                        'name': 'International'
                    }
                ],
                'visible': true,
                'editable': true,
                'isModelProperty': true,
                'showEdit': true
            }, {
                'name': 'Notification Type',
                'editable': true,
                'property': 'NTFY_TYP_ID_NBR',
                'visibleType': 'NTFY_TYP_ID_NBR',
                'visible': true,
                'type': 'input',
                'inputType': 'number',
                'isModelProperty': true,
                'dropDownValues': ''
            }, {
                'name': 'To Role/Pos',
                'editable': false,
                'property': 'toRole',
                'visibleType': 'toRole',
                'visible': true,
                'type': '',
                'inputType': '',
                'isModelProperty': true,
                'dropDownValues': ''
            }, {
                'name': 'Email',
                'editable': true,
                'property': 'NTFY_EMAL_NM',
                'visibleType': 'NTFY_EMAL_NM',
                'visible': true,
                'type': 'input',
                'inputType': 'email',
                'isModelProperty': true,
                'dropDownValues': ''
            },
            {
                'name': 'Effective Date',
                'property': 'EFF_DT',
                'visibleType': 'EFF_DT',
                'type': 'date',
                'visible': true,
                'editable': true,
                'isModelProperty': true
            }
        ]
    }
}
