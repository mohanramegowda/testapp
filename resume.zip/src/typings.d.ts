/* SystemJS module definition */
declare var module: NodeModule;
import * as $ from 'jquery';
interface NodeModule {
  id: string;
}
