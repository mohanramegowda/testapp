export const environment = {
  production: true,
  localUrl: '',
  vpn: false,
  vpnConfig: null
};
