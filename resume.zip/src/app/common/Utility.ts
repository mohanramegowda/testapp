/*
* SonarQube, open source software quality management tool.
* Copyright (C) 2008-2013 SonarSource
* mailto:contact AT sonarsource DOT com
*
* SonarQube is free software; you can redistribute it and/or
* modify it under the terms of the GNU Lesser General Public
* License as published by the Free Software Foundation; either
* version 3 of the License, or (at your option) any later version.
*
* SonarQube is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
* Lesser General Public License for more details.
*
* You should have received a copy of the GNU Lesser General Public License
* along with this program; if not, write to the Free Software Foundation,
* Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/

import { HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
// tslint:disable-next-line:import-blacklist
import { Observable } from 'rxjs/Rx';
import * as moment from 'moment';
import { environment } from '../../environments/environment';
@Injectable()
export class Utility {
    static isLocal = !environment.production;
    static appName = 'sp';
    static isVpn = environment.vpn;
    static userDetails: any = {};
    static loggedInCountryDetails: any = {};
    static countryCodeNameMap: any = {};
    static countryCodeDetailMap: any = {};
    static countryAccessMap: any = {};
    static countryIdMap: any = {};
    static countryIdCodeMap: any = {};
    static displayCountriesMap = {};
    static redirection: any;
    static commonStaticObject: any = {
        downloadAllowed: ['IMPLEMENTED', 'AGREEMENT GENERATED', 'AGREEMENT SUBMITTED', 'PENDING CONTRACT VALIDATION'],
        editAllowed: ['NEW', 'AGREEMENT GENERATED', 'REJECTED']
    };
    static fullOriginPath = window.location.origin;
    static roleActions: any = {};
    static files: FileList;
    static localUrl = environment.localUrl;
    static user = (Utility.isLocal) ? (environment.vpn) ? '' : '3699007' : '';
    static forcedRoute = false;
    static baseUrls = {
        workFlowService: (Utility.isLocal) ? (Utility.isVpn) ? `${Utility.localUrl}/workflow` :
            `${Utility.localUrl}/workflow-controller/workflow` : `${Utility.getContextPath()}/workflow`,
        userServiceBase: (Utility.isLocal) ? (Utility.isVpn) ? Utility.localUrl :
            `${Utility.localUrl}` : Utility.getContextPath(),
        businessServiceBaseUrl: (Utility.isLocal) ? `${Utility.localUrl}/v1` : (`${Utility.getContextPath()}/v1`),
        dataServiceBaseUrl: (Utility.isLocal) ? (!Utility.isVpn) ? `${Utility.localUrl}/proud-data-access-service/dataservice` :
            `${Utility.localUrl}/proud/data` : (`${Utility.getContextPath()}/data`),
        pricingServiceBaseUrl: (Utility.isLocal) ? (!Utility.isVpn) ? `${Utility.localUrl}/proud-products-service/pricing` :
            `${Utility.localUrl}/proud/pricing` : (`${Utility.getContextPath()}/pricing`),
        adminServiceBaseUrl: (Utility.isLocal) ? `${Utility.localUrl}/admin/v1` : (`${Utility.getContextPath()}/admin/v1`),
        printPresentServiceBaseUrl: (Utility.isLocal) ? (!Utility.isVpn) ? `${Utility.localUrl}/proud-print-present-service/printpresent` :
            `${Utility.localUrl}/proud/pricing` : (`${Utility.getContextPath()}/printpresent`),
        uiBaseUrl: (Utility.isLocal) ? (Utility.isVpn) ? Utility.localUrl :
            `${Utility.localUrl}` : Utility.getContextPath(),
        authorizeBase: (Utility.isLocal) ? (!Utility.isVpn) ?
            `https://ca-uat-cluster.emea.fedex.com:8443/test/auth-module/authorizeduser` :
            `${Utility.localUrl}/loggedinuser` : `${Utility.getContextPath()}/loggedinuser`,
        generateAgreement: (Utility.isLocal) ? (Utility.isVpn) ? (`${Utility.localUrl}/pricing/importExcel`)
            : `${Utility.localUrl}/proud-birt-module/generatedoc/download/agreement` :
            (`${Utility.getContextPath()}/generatedoc/download/agreement`),
    };
    static urlParams = {
        wssoLoginHdr: { url: `${Utility.baseUrls.userServiceBase}`, type: 'GET' },
        escSrvc: { url: `${Utility.baseUrls.authorizeBase}/${Utility.user}`, type: 'GET' },
        wssoLogoutUrl: { url: '/logout', type: 'GET' },
        breadCrumbs: { url: `${Utility.baseUrls.workFlowService}/breadcrumb/${Utility.appName}`, type: 'GET' },
        wfInitiate: { url: `${Utility.baseUrls.workFlowService}/initiateworkflow/${Utility.appName}`, type: 'POST' },
        wfSaveStage: { url: `${Utility.baseUrls.workFlowService}/${Utility.appName}/savestep`, type: 'POST' },
        wfUpdateStep: { url: `${Utility.baseUrls.workFlowService}/updatestep/${Utility.appName}`, type: 'PUT' },
        wfGetStep: { url: `${Utility.baseUrls.workFlowService}/stepdetails/${Utility.appName}`, type: 'GET' },
        wfActivityList: { url: `${Utility.baseUrls.workFlowService}/activitylist`, type: 'GET' },
        exportTemplate: { url: `${Utility.baseUrls.pricingServiceBaseUrl}/priceingtemplatedownload`, type: 'GET' },
        importTemplate: { url: `${Utility.baseUrls.pricingServiceBaseUrl}/uploadFile`, type: 'MultiPart' },

        generateAgreement: { url: Utility.baseUrls.generateAgreement, type: 'GET' },
        activityViewList: { url: `${Utility.baseUrls.dataServiceBaseUrl}/activitySAE`, type: 'POST' },

        countryList: { url: `${Utility.baseUrls.dataServiceBaseUrl}/country`, type: 'POST' },
        customerSegment: { url: `${Utility.baseUrls.dataServiceBaseUrl}/segment`, type: 'POST' },
        altLanguage: { url: `${Utility.baseUrls.dataServiceBaseUrl}/languagecd`, type: 'POST' },
        agreementTemplate: { url: `${Utility.baseUrls.dataServiceBaseUrl}/agreementtemplate`, type: 'POST' },
        agreementoption: { url: `${Utility.baseUrls.dataServiceBaseUrl}/agreementoption`, type: 'POST' },
        getStatuses: { url: `${Utility.baseUrls.dataServiceBaseUrl}/statusDrpDwn`, type: 'POST' },
        getDocumentTypes: { url: `${Utility.baseUrls.dataServiceBaseUrl}/documentCategory`, type: 'POST' },
        getComments: { url: `${Utility.baseUrls.printPresentServiceBaseUrl}/getAllComment`, type: 'GET' },
        addComments: { url: `${Utility.baseUrls.printPresentServiceBaseUrl}/saveComment`, type: 'POST' },
        getAllFiles: { url: `${Utility.baseUrls.printPresentServiceBaseUrl}/getAllDocuments`, type: 'GET' },
        uploadDocument: { url: `${Utility.baseUrls.printPresentServiceBaseUrl}/uploadFile`, type: 'MultiPart' },
        downloadDocument: { url: `${Utility.baseUrls.printPresentServiceBaseUrl}/downloadDocument`, type: 'GET' },
        deleteComment: { url: `${Utility.baseUrls.printPresentServiceBaseUrl}/deleteComment`, type: 'DELETE' },
        getProposalStatus: { url: `${Utility.baseUrls.dataServiceBaseUrl}/getProposalStatus`, type: 'POST' },

        genericInfoUrl: { url: `${Utility.baseUrls.businessServiceBaseUrl}/country/info/`, type: 'GET' },
        genericTarrifTypes: { url: `${Utility.baseUrls.businessServiceBaseUrl}/country/tariff/selection/criteria`, type: 'POST' },
        genericServiceTypes: { url: `${Utility.baseUrls.businessServiceBaseUrl}/country/products`, type: 'POST' },
        getDiscounts: { url: `${Utility.baseUrls.dataServiceBaseUrl}/countryLevelDiscounts`, type: 'POST' },
        getZone: { url: `${Utility.baseUrls.businessServiceBaseUrl}/service/zones/info`, type: 'POST' },
        getSurcharges: { url: `${Utility.baseUrls.businessServiceBaseUrl}/surcharges/info`, type: 'POST' },
        createSalesFeed: { url: `${Utility.baseUrls.businessServiceBaseUrl}/salesfeed`, type: 'POST' },
        getTariffHistory: { url: '/activity/view/list', type: 'GET' },
        getLoadingTariffHistory: { url: '/loading/view/list', type: 'GET' },
        updateTariff: { url: `${Utility.baseUrls.businessServiceBaseUrl}/tariff/update/`, type: 'POST' },
        generatePDF: { url: `${Utility.baseUrls.businessServiceBaseUrl}/reports/tariff`, type: 'GET' },
        sneakPreview: { url: `${Utility.baseUrls.businessServiceBaseUrl}/sneak/preview`, type: 'POST' },
        getWeightbrkdwn: { url: '/weight/breakage/', type: 'GET' },
        generateExcel: { url: `${Utility.baseUrls.businessServiceBaseUrl}/reports/excel`, type: 'GET' },
        getSaleFeedInfo: { url: `${Utility.baseUrls.businessServiceBaseUrl}/salesfeed/`, type: 'GET' },
        generateLI: { url: `${Utility.baseUrls.businessServiceBaseUrl}/reports/excel/loading-instructions`, type: 'GET' },
        generateLIDom: { url: `${Utility.baseUrls.businessServiceBaseUrl}/reports/excel/loading-instructions-domestic`, type: 'GET' },
        updateSalesFeed: { url: `${Utility.baseUrls.businessServiceBaseUrl}/salesfeed`, type: 'PUT' },
        getCountryLane: { url: `${Utility.baseUrls.businessServiceBaseUrl}/country/details`, type: 'POST' },
        getStandardDiscounts: { url: `${Utility.baseUrls.businessServiceBaseUrl}/standard/tariff`, type: 'POST' },
        genStdTariff: { url: `${Utility.baseUrls.businessServiceBaseUrl}/reports/standard/tariff`, type: 'GET' },
        uploadPt: { url: `${Utility.baseUrls.businessServiceBaseUrl}/personalised/tariff/upload`, type: 'MultiPart' },
        downloadPT: { url: `${Utility.baseUrls.businessServiceBaseUrl}/personalised/tariff/download/`, type: 'GET' },
        //  getStatuses: { url: `${Utility.baseUrls.businessServiceBaseUrl}/tariff/get/all/status`, type: 'GET' },
        getPTSaleFeedInfo: { url: `${Utility.baseUrls.businessServiceBaseUrl}/approval/personalized/status/`, type: 'GET' },
        ptApproveReject: { url: `${Utility.baseUrls.businessServiceBaseUrl}/approval/personalized/status`, type: 'POST' },
        postPTApproval: { url: `${Utility.baseUrls.businessServiceBaseUrl}/approval/personalized/selection`, type: 'POST' },
        getTariffInfo: { url: `${Utility.baseUrls.businessServiceBaseUrl}/approval/personalized/info/status/`, type: 'GET' },
        confrmST: { url: `${Utility.baseUrls.businessServiceBaseUrl}/salesfeed/confirmAccountDetails`, type: 'POST' },
        updatePTOpco: { url: `${Utility.baseUrls.businessServiceBaseUrl}/personalised/tariff/update/opco`, type: 'PUT' },
        postPersnlDetl: { url: `${Utility.baseUrls.businessServiceBaseUrl}/personalised/tariff/details`, type: 'POST' },
        partlyAwardedSave: { url: `${Utility.baseUrls.businessServiceBaseUrl}/partly/awarded/save`, type: 'PUT' },
        getPartlyAwarded: { url: `${Utility.baseUrls.businessServiceBaseUrl}/partly/awarded/get`, type: 'GET' },
        countrySplitURL: { url: `${Utility.baseUrls.dataServiceBaseUrl}/countrySplit`, type: 'POST' },
        zoningTTURL: { url: `${Utility.baseUrls.dataServiceBaseUrl}/zonningAndTT`, type: 'POST' },
        getAdminCountryList: { url: '/countries/tariff/threshold', type: 'GET' },
        postAdminDetl: { url: `${Utility.baseUrls.dataServiceBaseUrl}/countrySTSettings`, type: 'POST' },
        getStandardDetl: { url: '/standard/tariffs', type: 'GET' },
        getPersonalisedDetl: { url: '/personalized/tariffs', type: 'GET' },
        postThreshold: { url: '/save/threshold', type: 'POST' },
        fetchPTOnGO: { url: '/personalized/tariff/get', type: 'POST' },
        fetchSTOnGO: { url: '/standard/tariff/get', type: 'POST' },
        saveST: { url: `${Utility.baseUrls.adminServiceBaseUrl}/standard/tariff`, type: 'MultiPart' },
        savePT: { url: '/personalized/tariff', type: 'POST' },
        uploadFTT: { url: '/excel/uploadFile', type: 'POST' },
        listPrice: { url: '/countries/list/price', type: 'GET' },
        fetchAvlbDate: { url: '/fetch/li/dates', type: 'POST' },
        fetchLstPric: { url: '/fetch/list/price', type: 'POST' },
        activityVwPgs: { url: `${Utility.baseUrls.businessServiceBaseUrl}/activity/view/pages`, type: 'POST' },
        removeSTURL: { url: '/standard/tariff/remove', type: 'POST' },
        adminCountryServices: { url: '/service/details', type: 'POST' },

        ZoningTTHeaders: { url: `${Utility.baseUrls.dataServiceBaseUrl}/zonningAndTTHeader`, type: 'POST' },
        CountrySplitHeaders: { url: `${Utility.baseUrls.dataServiceBaseUrl}/countrySplitHeader`, type: 'POST' },
        getCountryOP: { url: `${Utility.baseUrls.dataServiceBaseUrl}/countryOpUnitDetails`, type: 'POST' },
        CountryDetails: { url: `${Utility.baseUrls.dataServiceBaseUrl}/country`, type: 'POST' },
        CountryTTSAvlDts: { url: `${Utility.baseUrls.dataServiceBaseUrl}/countryTariffTypeSettingsAvailableDates`, type: 'POST' },
        TTSClosestDate: { url: `${Utility.baseUrls.dataServiceBaseUrl}/closestCountryTariffTypeRevInfo`, type: 'POST' },
        getTariffTypes: { url: `${Utility.baseUrls.dataServiceBaseUrl}/countryTariffTypeSettings`, type: 'POST' },
        saveTariffTypes: { url: `${Utility.baseUrls.adminServiceBaseUrl}/save/tariffTypeSetting`, type: 'POST' },
        stSettingsAvailableDates: { url: `${Utility.baseUrls.dataServiceBaseUrl}/stSettingsAvailableDates`, type: 'POST' },
        closestStandardTariffDiscInfo: { url: `${Utility.baseUrls.dataServiceBaseUrl}/closestStandardTariffDiscInfo`, type: 'POST' },
        countrySTSettings: { url: `${Utility.baseUrls.dataServiceBaseUrl}/countrySTSettings`, type: 'POST' },
        deleteSTRow: { url: `${Utility.baseUrls.adminServiceBaseUrl}/standard/tariff/remove`, type: 'POST' },
        deleteThreshold: { url: `${Utility.baseUrls.adminServiceBaseUrl}/remove/threshold`, type: 'POST' },
        getBandDownloadTrf: { url: `${Utility.baseUrls.businessServiceBaseUrl}/reports/band/files`, type: 'GET' },
        notificationSettingsAvailableDates: {
            url: `${Utility.baseUrls.dataServiceBaseUrl}/notificationSettingsAvailableDates`,
            type: 'POST'
        },
        closestNotificationInfo: { url: `${Utility.baseUrls.dataServiceBaseUrl}/closestNotificationInfo`, type: 'POST' },
        notificationSettings: { url: `${Utility.baseUrls.dataServiceBaseUrl}/notificationSettings`, type: 'POST' },
        getEmailTemplateById: { url: `${Utility.baseUrls.dataServiceBaseUrl}/getEmailTemplateById`, type: 'POST' },
        questionDetails: { url: `${Utility.baseUrls.dataServiceBaseUrl}/questionDetails`, type: 'POST' },
        operatingEntDecision: { url: `${Utility.baseUrls.dataServiceBaseUrl}/operatingEntDecision`, type: 'POST' },
        entityProducts: { url: `${Utility.baseUrls.dataServiceBaseUrl}/entityProducts`, type: 'POST' },
        domesticTariffTypeSettings: { url: `${Utility.baseUrls.dataServiceBaseUrl}/domesticTariffTypeSettings`, type: 'POST' },
        domesticTariffFileSettings: { url: `${Utility.baseUrls.dataServiceBaseUrl}/domesticTariffFileSettings`, type: 'POST' },
        getStatusOptionsForActivityView: { url: `${Utility.baseUrls.dataServiceBaseUrl}/getStatusOptionsForActivityView`, type: 'POST' },
        getUserAccessDetails: { url: `${Utility.baseUrls.dataServiceBaseUrl}/userAccessDetails`, type: 'POST' },
        UpdateUserDetails: { url: `${Utility.baseUrls.adminServiceBaseUrl}/manageUserAccess`, type: 'POST' },
        saveUser: { url: `${Utility.baseUrls.adminServiceBaseUrl}/userDetails`, type: 'POST' },
        getCountryFields: { url: `${Utility.baseUrls.dataServiceBaseUrl}/getCountryFields`, type: 'POST' },
        getSalesCustAttrDetails: { url: `${Utility.baseUrls.dataServiceBaseUrl}/getSalesCustAttrDetails`, type: 'POST' },
        salesCustAttrFeed: { url: `${Utility.baseUrls.businessServiceBaseUrl}/salesCustAttrFeed`, type: 'POST' },
        teamMembers: { url: `${Utility.baseUrls.adminServiceBaseUrl}/reportee`, type: 'POST' },
        ownerDetails: { url: `${Utility.baseUrls.businessServiceBaseUrl}/ownerDetails`, type: 'POST' },
        auditDetails: { url: `${Utility.baseUrls.dataServiceBaseUrl}/auditDetails`, type: 'POST' },
        commentDetails: { url: `${Utility.baseUrls.dataServiceBaseUrl}/commentDetails`, type: 'POST' },
        updateComments: { url: `${Utility.baseUrls.businessServiceBaseUrl}/salesfeed/commentDetails`, type: 'POST' },
        applyGRI: { url: `${Utility.baseUrls.dataServiceBaseUrl}/gri/apply`, type: 'POST' },
        cappedLevelDetails: { url: `${Utility.baseUrls.dataServiceBaseUrl}/cappedLevelDetails`, type: 'POST' },
        revenueLevelDetails: { url: `${Utility.baseUrls.dataServiceBaseUrl}/revenueLevelDetails`, type: 'POST' },
        weightLevelDetails: { url: `${Utility.baseUrls.dataServiceBaseUrl}/weightLevelDetails`, type: 'POST' },
        weightLevelDetailsAvailableDates: {
            url: `${Utility.baseUrls.dataServiceBaseUrl}/weightLevelDetailsAvailableDates`,
            type: 'POST'
        },
        revenueLevelDetailsAvailableDates: {
            url: `${Utility.baseUrls.dataServiceBaseUrl}/revenueLevelDetailsAvailableDates`,
            type: 'POST'
        },
        cappedLevelDetailsAvailableDates: {
            url: `${Utility.baseUrls.dataServiceBaseUrl}/cappedLevelDetailsAvailableDates`,
            type: 'POST'
        },
        serviceDropDown: { url: `${Utility.baseUrls.dataServiceBaseUrl}/serviceDropDown`, type: 'POST' },
        capDiscountDropDown: { url: `${Utility.baseUrls.dataServiceBaseUrl}/capDiscountDropDown`, type: 'POST' },
        closestWeightLevelDetails: { url: `${Utility.baseUrls.dataServiceBaseUrl}/closestWeightLevelDetails`, type: 'POST' },
        closestRevenueLevelDetails: { url: `${Utility.baseUrls.dataServiceBaseUrl}/closestRevenueLevelDetails`, type: 'POST' },
        closestCappedLevelDetails: { url: `${Utility.baseUrls.dataServiceBaseUrl}/closestCappedLevelDetails`, type: 'POST' },
        countryConfigInfo: { url: `${Utility.baseUrls.dataServiceBaseUrl}/countryConfigInfo`, type: 'POST' },
        griAvailableDates: { url: `${Utility.baseUrls.dataServiceBaseUrl}/griAvailableDates`, type: 'POST' },
        removeUser: { url: `${Utility.baseUrls.adminServiceBaseUrl}/removeUser`, type: 'POST' },
        capDiscountSetting: { url: `${Utility.baseUrls.adminServiceBaseUrl}/save/capDiscountSetting`, type: 'POST' },
        revenueLevelSetting: { url: `${Utility.baseUrls.adminServiceBaseUrl}/save/revenueLevelSetting`, type: 'POST' },
        weightLevelSetting: { url: `${Utility.baseUrls.adminServiceBaseUrl}/save/weightLevelSetting`, type: 'POST' },
        ptTariffFileDetails: { url: `${Utility.baseUrls.dataServiceBaseUrl}/ptTariffFileDetails`, type: 'POST' },
        deletePTFile: { url: `${Utility.baseUrls.businessServiceBaseUrl}/personalised/tariff/deletePTFile`, type: 'POST' },
        downloadPTFile: { url: `${Utility.baseUrls.businessServiceBaseUrl}/personalised/tariff/downloadPTFile/`, type: 'GET' }
    }
    static getContextPath() {
        return window.location.pathname.substring(0, window.location.pathname.lastIndexOf('/', window.location.pathname.length));
        // return window.location.pathname.substring(0, window.location.pathname.indexOf('/', 2));
    }

    static formatDateTime(date: Date = new Date(), format: string = 'dd/mm/yyyy') {
        return moment(date).format(format);
    }

    static toHttpParams(obj: object): HttpParams {
        // convert class/json/object to HttpParams
        let params = new HttpParams();
        for (const key in obj) {
            if (obj.hasOwnProperty(key)) {
                const val = obj[key];
                if (val !== null && val !== undefined) {
                    params = params.append(key, val.toString());
                }
            }
        }
        return params;
    }

    static seSessionStorageItem(itemName: string, item: string): void {
        sessionStorage.setItem(itemName, item);
    }

    static getSessionStorageItem(itemName: string): string {
        return sessionStorage.getItem(itemName);
    }

    static getLocalStorageItem(itemName: string): string {
        return localStorage.getItem(itemName);
    }

    static setLocalStorageItem(itemName: string, item: string): void {
        localStorage.setItem(itemName, item);
    }

    static clearAllSessionStorageItems() {
        return sessionStorage.clear();
    }

    static errorHandler(error): Observable<string> {
        if (error.status === 500) {
            return Observable.throw(new Error('Error while processing request'));
        } else if (error.status === 400 || error.status === 401) {
            return Observable.throw(new Error('Invalid username and password'));
        } else if (error.status === 409) {
            return Observable.throw(new Error(error.status));
        } else if (error.status === 406) {
            return Observable.throw(new Error(error.status));
        }
    }

    static checkIsIEOrEdge(): boolean {
        const isIEOrEdge = /msie\s|trident\/|edge\//i.test(window.navigator.userAgent);
        return isIEOrEdge;
    }

}
