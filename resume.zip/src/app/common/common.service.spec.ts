
/*
 * SonarQube, open source software quality management tool.
 * Copyright (C) 2008-2013 SonarSource
 * mailto:contact AT sonarsource DOT com
 *
 * SonarQube is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or (at your option) any later version.
 *
 * SonarQube is distributed in the hope that it will be useful, * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */


import { TestBed, async, fakeAsync, tick, ComponentFixture } from '@angular/core/testing';
import { HttpClientTestingModule } from '@angular/common/http/testing';

import { RouterTestingModule } from '@angular/router/testing';
import { Observable, Observer, of } from 'rxjs';
import { CommonService } from './common.service';
import { Utility } from './Utility';

describe('CommonService', () => {

    let commonService: CommonService;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [
            ],
            providers: [
                CommonService,
            ],
            imports: [
                RouterTestingModule,
                HttpClientTestingModule,
            ]
        }).compileComponents();
        commonService = TestBed.get(CommonService);
        jasmine.DEFAULT_TIMEOUT_INTERVAL = 10000;
    }));

    beforeEach(() => {

    });

    it('should create common service', () => {
        expect(commonService).toBeTruthy();
    });

    it(`updateFilteredResults`, (() => {
        const sampleData = { JSON: true };
        commonService.updateFilteredResults(sampleData);
        commonService.getFilteredResults().subscribe(data => {
            expect(data).toBe(sampleData)
        });
    }));
    it(`checkNullOrUndefined`, (() => {
        const sampleData = { JSON: true };
        expect(commonService.checkNullOrUndefined(sampleData)).toBe(false);
        expect(commonService.checkNullOrUndefined(null)).toBe(true);
        expect(commonService.checkNullOrUndefined(undefined)).toBe(true);
    }));
    const requests = [
        {
            url: null,
            type: null,
            request: null,
            response: null
        }, {
            url: 'GET',
            type: 'GET',
            response: 'GET'
        }, {
            url: 'POST',
            type: 'POST',
            request: 'POST',
            response: 'POST'
        }, {
            url: 'PUT',
            type: 'PUT',
            request: 'PUT',
            response: 'PUT'
        }, {
            url: 'MultiPart',
            type: 'MultiPart',
            request: 'MultiPart',
            response: 'MultiPart'
        }, {
            url: 'Error',
            type: 'error',
            request: 'error',
            response: null
        }
    ];

    requests.forEach(({ url, type, request, response}) => {
        it(`getAPIResponse with ${type}`, (() => {
            if (type === 'GET') {
                spyOn(commonService, 'getHttpGetResponse').and.returnValue(of([response]));
            } else if (type === 'POST') {
                spyOn(commonService, 'getHttpPostResponse').and.returnValue(of([response]));
            } else if (type === 'PUT') {
                spyOn(commonService, 'getHttpPutResponse').and.returnValue(of([response]));
            } else if (type === 'MultiPart') {
                spyOn(commonService, 'getHttpPostMultiPartResponse').and.returnValue(of([response]));
            }
            if (['GET', 'POST', 'PUT', 'MultiPart'].includes(type)) {
                commonService.getAPIResponse(url, request, type).subscribe(data => {
                    expect(data).toEqual([response]);
                });
            } else {
                const result = commonService.getAPIResponse(url, request, type)
                expect(result).toEqual(null);
            }
        }));
    });
});
