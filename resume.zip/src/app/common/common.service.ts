/*
 * SonarQube, open source software quality management tool.
 * Copyright (C) 2008-2013 SonarSource
 * mailto:contact AT sonarsource DOT com
 *
 * SonarQube is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or (at your option) any later version.
 *
 * SonarQube is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

import { Injectable, Compiler } from '@angular/core';
import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Observable, Subject, BehaviorSubject } from 'rxjs/Rx';
import { Utility } from './Utility';
import * as moment from 'moment';
import { forkJoin } from 'rxjs';
import { FieldConfig, Validator } from 'app/components/dyn-forms/field.interface';
import { Validators } from '@angular/forms';
import { RequestOptions } from '@angular/http';

declare var $: any;

@Injectable()
export class CommonService {
  headers: any;
  searchTermSearched = new Subject();
  loggedInDetails = new Subject();
  private _filteredResults = new BehaviorSubject<any>(null);
  components: any = {};

  constructor(private http: HttpClient,
    private _complier: Compiler) {
    this.headers = new HttpHeaders({ 'Content-Type': 'application/json' });
  }

  updateFilteredResults(resultsSet) {
    this._filteredResults.next(resultsSet)
  }

  getFilteredResults(): Observable<any> {
    return this._filteredResults.asObservable();
  }

  getHttpPostMultiPartResponse(formData, url): Observable<any[]> {
    const body = formData;
    return this.http
      .post(url, body, { observe: 'response' })
      .map((res: any) => {
        if (res.status === 302 || (res && typeof res === 'string' && res.indexOf('WSSO Login') > -1)) {
          window.location.reload();
          return;
        }
        if (res.status === 304) {
          this.logoutOTT();
          return;
        }
        const responseBody = res.body || null;
        return responseBody;
      })
      .catch((error: any) => {
        return Observable.throw(new Error(error.status));
      });
  }

  getHttpPostResponse(request, url): Observable<any[]> {
    const body = request;
    const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    return this.http
      .post(url, body, { headers, observe: 'response' })
      .map((res: any) => {
        if (res.status === 302 || (res && typeof res === 'string' && res.indexOf('WSSO Login') > -1)) {
          window.location.reload();
          return;
        }
        if (res.status === 304) {
          this.logoutOTT();
          return;
        }
        const responseBody = res.body || null;
        return responseBody;
      })
      .catch(error => Observable.of(null));
  }

  getHttpDeleteResponse(request, url): Observable<any[]> {
    const body = request;
    const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    return this.http
      .delete(url, { headers, observe: 'response' })
      .map((res: any) => {
        if (res.status === 302 || (res && typeof res === 'string' && res.indexOf('WSSO Login') > -1)) {
          window.location.reload();
          return;
        }
        if (res.status === 304) {
          this.logoutOTT();
          return;
        }
        const responseBody = res.body || null;
        return responseBody;
      })
      .catch((error: any) => {
        return Observable.throw(new Error(error.status));
      });
  }

  getHttpPutResponse(request, url): Observable<any[]> {
    const body = request;
    const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    return this.http
      .put(url, body, { headers, observe: 'response' })
      .map((res: any) => {
        if (res.status === 302 || (res && typeof res === 'string' && res.indexOf('WSSO Login') > -1)) {
          window.location.reload();
          return;
        }
        if (res.status === 304) {
          this.logoutOTT();
          return;
        }
        const responseBody = res.body || null;
        return responseBody;
      })
      .catch((error: any) => {
        return Observable.throw(new Error(error.status));
      });
  }

  getHttpGetResponse(url, request = null): Observable<any[]> {
    const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    const params = new HttpParams();
    if (request) {
      // tslint:disable-next-line: forin
      for (const i in request) {
        params.set(i, request[i]);
      }
    }
    return this.http
      .get(url, { headers: headers, params: params, observe: 'response' })
      .map((res: any) => {
        if (res.status === 302 || (res && typeof res === 'string' && res.indexOf('WSSO Login') > -1)) {
          window.location.reload();
          return;
        }
        if (res.status === 304) {
          this.logoutOTT();
          return;
        }
        const responseBody = res.body || null;
        return responseBody;
      })
      .catch(error => Observable.of(null));
  }

  getHttpDownloadResponse(request, url): Observable<any[]> {
    const body = request;
    const headers = new HttpHeaders({ 'Content-Type': 'application/json' });
    const httpOptions = {
      headers: new HttpHeaders({
        'Accept': 'application/pdf'
      }),
      'responseType': 'blob' as 'json'
    }
    return this.http
      .post(url, body, httpOptions)
      .map((res: any) => {
        if (res.status === 302 || (res && typeof res === 'string' && res.indexOf('WSSO Login') > -1)) {
          window.location.reload();
          return;
        }
        if (res.status === 304) {
          this.logoutOTT();
          return;
        }
        const responseBody = res || null;
        return responseBody;
      })
      .catch(error => Observable.of(null));
  }

  getHttpLoginResponse(url): Observable<any[]> {
    return this.http
      .get(url)
      .map((res: any) => {
        if (res.status === 302 || (res && typeof res === 'string' && res.indexOf('WSSO Login') > -1)) {
          window.location.reload();
          return;
        }
        if (res.status === 304) {
          this.logoutOTT();
          return;
        }
        const responseBody = (res.userId) ? res : res.body || null;
        return responseBody;
      })
      .catch((error: any) => {
        if (error && error.status && error.status === 200) {
          window.location.reload();
        } else if (error && error.status && error.status === 401) {
          return Observable.throw(new Error(error.status));
        } else {
          this.logoutOTT();
          return Observable.throw(new Error(error.status));
        }
      });
  }

  logoutOTT() {
    Utility.clearAllSessionStorageItems();
    // this._complier.clearCache();
    window.location.href = Utility.urlParams.wssoLogoutUrl.url;
  }

  getAPIResponse(url, request = null, type): Observable<any[]> {
    if (!url) {
      return null;
    }
    if (type === 'GET') {
      let str = '';
      if (request) {
        // tslint:disable-next-line: forin
        for (const i in request) {
          if (str) {
            str += '&';
          } else {
            str += '?';
          }
          str += `${i}=${request[i]}`;
        }
      }
      url += str;
      return this.getHttpGetResponse(url, request);
    } else if (type === 'DELETE') {
      let str = '';
      if (request) {
        // tslint:disable-next-line: forin
        for (const i in request) {
          if (str) {
            str += '&';
          } else {
            str += '?';
          }
          str += `${i}=${request[i]}`;
        }
      }
      url += str;
      return this.getHttpDeleteResponse(null, url);
    } else if (type === 'POST') {
      return this.getHttpPostResponse(request, url);
    } else if (type === 'PUT') {
      return this.getHttpPutResponse(request, url);
    } else if (type === 'MultiPart') {
      const formData = request;
      return this.getHttpPostMultiPartResponse(formData, url);
    } else if (type === 'Download') {
      return this.getHttpDownloadResponse(request, url);
    } else {
      return null;
    }
  }

  getGenericForkJoin(requestArr) {
    const responseArr = [];
    requestArr.map((request) => {
      responseArr.push(this.getAPIResponse(request.url, request.param, request.type));
    });
    return forkJoin(responseArr);
  }

  formatDateTime(date: Date = new Date(), format: string = 'dd/mm/yyyy') {
    return moment(date).format(format);
  }

  getMomentDate(date) {
    return moment(date).format();
  }

  checkNullOrUndefined(value) {
    if (value == null || typeof value === 'undefined') {
      return true;
    }
    return false;
  }

  showNotifier(message, type) {
    let color = '';
    if (type === 'error') {
      color = 'danger';
    } else if (type === 'warning') {
      color = 'warning';
    } else if (type === 'info') {
      color = 'info';
    } else if (type === 'success') {
      color = 'success';
    }

    $.notify({
      icon: 'notifications',
      message: message

    }, {
      type: color,
      timer: 3000,
      placement: {
        from: 'top',
        align: 'right'
      },
      template: '<div data-notify="container" class="col-xl-4 col-lg-4' +
        'col-11 col-sm-4 col-md-4 alert alert-{0} alert-with-icon" role="alert">' +
        '<button mat-button  type="button" aria-hidden="true" class="close ' +
        'mat-button" data-notify="dismiss">  <i class="material-icons">close</i></button>' +
        '<i class="material-icons" data-notify="icon">notifications</i> ' +
        '<span data-notify="title">{1}</span> ' +
        '<span data-notify="message">{2}</span>' +
        '<div class="progress" data-notify="progressbar">' +
        '<div class="progress-bar progress-bar-{0}" role="progressbar"' +
        'aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 0%;"></div>' +
        '</div>' +
        '<a href="{3}" target="{4}" data-notify="url"></a>' +
        '</div>'
    });
  }
  // The below code should be removed
  setComponent(name, reference) {
    this.components[name] = reference;
  }
  getComponent(name) {
    return this.components[name];
  }
  // The above code should be removed

  buildField(frmCnfg = null, availableObject) {
    const fieldConfigMap = {};
    const formConfigObj: any = {};
    if (frmCnfg) {
      const config: any = JSON.parse(JSON.stringify(frmCnfg));
      const fieldConfigs: FieldConfig[] = [];
      if (config.fields) {
        config.fields.map((field) => {
          let elementConfig: FieldConfig;
          const elementObj: any = {};
          elementObj.inputType = field.inputType;
          elementObj.type = field.type;
          elementObj.label = field.label;
          elementObj.name = field.name;
          elementObj.styleClass = field.styleClass;
          elementObj.styleColor = field.styleColor;
          elementObj.styleId = field.styleId;
          elementObj.disabled = field.disabled;
          elementObj.hidden = field.hidden;
          elementObj.min = field.min;
          elementObj.max = field.max;
          if (field.value) {
            elementObj.value = field.value;
          }
          if (field.options) {
            elementObj.options = field.options;
          }
          // Override the default Value
          if (availableObject && availableObject[field.name]) {
            if (field.type === 'select') {
              if (availableObject[field.name].values) {
                elementObj.options = availableObject[field.name].values;
              }
              elementObj.value = availableObject[field.name].value ? availableObject[field.name].value : availableObject[field.name];
            } else {
              elementObj.value = availableObject[field.name];
            }

            if (field.type === 'date') {
              elementObj.dateFilter = availableObject[field.name].dateFilter;
              if (availableObject[field.name].value) {
                elementObj.value = this.formatDate(availableObject[field.name].value);
              } else {
                elementObj.value = this.formatDate(availableObject[field.name]);
              }
            }
            if (field.type === 'labelDesc') {
              if (elementObj.options) {
                elementObj.options.map((obj) => {
                  if (availableObject[field.name] === obj.value) {
                    field.value = obj.name;
                    elementObj.value = obj.name;
                  }
                });
                // field.value = elementObj.objects[availableObject[field.name]].name;
              }
            }
            // elementObj.disabled = !!availableObject[field.name].disabled;
          }

          if (field.utilFieldNm) {
            if (field.type === 'select' || field.type === 'radiobutton') {
              elementObj.options = Utility.commonStaticObject[field.utilFieldNm];
            }
            if (field.defaultValueRef) {
              elementObj.value = Utility.commonStaticObject[field.defaultValueRef];
            }
          }
          if (field.validations) {
            let validator: Validator[];
            const validatorArr = [];
            field.validations.map((validation) => {
              const validatorObj: any = {};
              if (validation.name === 'required') {
                validatorObj.name = validation.name;
                validatorObj.validator = Validators.required;
                validatorObj.message = validation.message;
              } else if (validation.name === 'pattern') {
                validatorObj.name = validation.name;
                validatorObj.validator = Validators.pattern(validation.value);
                validatorObj.message = validation.message;
              } else if (validation.name === 'maxlength') {
                validatorObj.name = validation.name;
                validatorObj.validator = Validators.maxLength(validation.value);
                validatorObj.message = validation.message;
              } else if (validation.name === 'minlength') {
                validatorObj.name = validation.name;
                validatorObj.validator = Validators.minLength(validation.value);
                validatorObj.message = validation.message;
              }
              validatorArr.push(validatorObj);
            });
            validator = validatorArr;
            elementObj.validations = validator;
          }
          elementConfig = elementObj;
          fieldConfigs.push(elementConfig);
        });
      }
      formConfigObj.fieldsConfig = fieldConfigs;
      fieldConfigMap[formConfigObj.form_name] = formConfigObj;
    }
    return formConfigObj;
  }

  formatDate(date) {
    // tslint:disable-next-line: prefer-const
    let d = new Date(date),
      month = '' + (d.getMonth() + 1),
      day = '' + d.getDate(),
      // tslint:disable-next-line: prefer-const
      year = d.getFullYear();

    if (month.length < 2) { month = '0' + month; }
    if (day.length < 2) { day = '0' + day; }

    return [year, month, day].join('-');
  }
}
