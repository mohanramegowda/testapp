import { ControlValueAccessor, FormGroup } from '@angular/forms';
import { Input } from '@angular/core';

export class ControlValueBase implements ControlValueAccessor {

    @Input() form: FormGroup;
    disabled: boolean;

    onChange = (_: any) => { };
    onTouched = () => { };

    writeValue(obj: any): void {
        this.onChange(obj);
        obj = null;
    }
    registerOnChange(fn: any): void {
        this.onChange = fn;
    }
    registerOnTouched(fn: any): void {
        this.onTouched = fn;
    }
    setDisabledState?(isDisabled: boolean): void {
        this.disabled = isDisabled;
    }
}
