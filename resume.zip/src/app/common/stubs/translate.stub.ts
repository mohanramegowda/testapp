import { Observable } from 'rxjs';

export class TranslateServiceStub {

    public get(key: any): any {
        Observable.of(key);
    }
}
