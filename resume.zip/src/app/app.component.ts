import { Component } from '@angular/core';
import { CommonService } from './common/common.service';
import { Router, ActivatedRoute } from '@angular/router';
import { Utility } from './common/Utility';
import { TranslateService } from '@ngx-translate/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

  activate: Boolean = true;
  idleState = 'Not started.';
  timedOut = false;
  lastPing?: Date = null;
  roles = ['dashboard'];
  actions = [];
  roleName = '';
  roleUser = '';
  countryAccessDetails: any;

  newRoleLiterals = {
    'ActivityView,View': ((value) => {
      if (value) {
        this.actions.push('activity');
      }
    }),
    'AgreementTemplate,View': ((value) => {
      if (value) {
        //  this.actions.push('activity');
      }
    }),
    'EsignTrigger,Trigger': ((value) => {
      if (value) {
        //  this.actions.push('activity');
      }
    }),
    'Notification,View': ((value) => {
      if (value) {
        //  this.actions.push('activity');
      }
    }),
    'PricingContract,Manage': ((value) => {
      if (value) {
        //  this.actions.push('activity');
      }
    }),
    'PricingTemplate,View': ((value) => {
      if (value) {
        //  this.actions.push('activity');
      }
    }),
    'Application,Login': ((value) => {
      this.activate = value;
    }),
    'Proposal,View': ((value) => {
      if (value) {
        this.actions.push('create');
      }
    }),
    'CreateProposal,View': ((value) => {
      if (value && this.actions.indexOf('create') === -1) {
        this.actions.push('create');
      }
    })
  };

  computeURL() {
    const path = Utility.getLocalStorageItem('DATA');
    Utility.setLocalStorageItem('DATA', '');
    // Check for URL
    if (path && path.indexOf('?') > 1) {
      const params = this.getParams(path);
      if (params['page'] && params['page'] === 'activity') {
        this.router.navigate([params['page'], params['feed'], params['ctry']]);
      }
    } else {
      if (Utility.redirection) {
        this.router.navigate([Utility.redirection]);
        Utility.redirection = '';
      }
    }
  }

  getParams(url) {
    const params = {};
    const parser = document.createElement('a');
    parser.href = url;
    const query = parser.search.substring(1);
    const vars = query.split('&');
    for (let i = 0; i < vars.length; i++) {
      const pair = vars[i].split('=');
      params[pair[0]] = decodeURIComponent(pair[1]);
    }
    return params;
  }

  reset() {
    // this.idle.watch();
    this.idleState = 'Started.';
    this.timedOut = false;
  }

  constructor(private commonService: CommonService,
    // private idle: Idle,
    // private keepalive: Keepalive,
    private router: Router,
    public translate: TranslateService,
    private activatedRoute: ActivatedRoute) {
    // Change Auth Guard after implementation of Authentication

    // this.activate = true;
    // tslint:disable-next-line: max-line-length
    // Utility.userDetails = { 'userId': '3699007', 'userFirstName': 'Madan', 'userLastName': 'Srivats', 'countryCode': 'NL', 'userEmail': 'madan.madan.osv@fedex.com', 'authroizes': { 'PROUD-CreateProposal,PROUD-Login': true, 'PROUD-CreateProposal,PROUD-View': true, 'PROUD-PricingTemplate,PROUD-View': false, 'PROUD-ActivityView,PROUD-View': true, 'PROUD-CreateProposal,PROUD-Create': true }, 'roleNm': ['PROUD-SalesAE', 'PricingHQ', 'PROUD-ProposalRequestor'], 'accessibleCountries': null, 'fullName': 'Madan Srivats' };
    // Utility.roleActions = { 'actions': ['activity', 'create'], 'roleName': '', 'roleUser': '', 'roles': ['dashboard'] };
    this.getLoginDetails();

    // // sets an idle timeout of 1800 seconds (30min)
    // idle.setIdle(1800);
    // // sets a timeout period of 5 seconds. after 1805 seconds of inactivity, the user will be considered timed out.
    // idle.setTimeout(5);
    // // sets the default interrupts, in this case, things like clicks, scrolls, touches to the document
    // idle.setInterrupts(DEFAULT_INTERRUPTSOURCES);
    // idle.onIdleEnd.subscribe(() => this.idleState = 'No longer idle.');
    // idle.onTimeout.subscribe(() => {
    //   this.idleState = 'Timed out!';
    //   this.timedOut = true;
    //   this.logOut()
    // });
    // idle.onIdleStart.subscribe(() => this.logOut());
    // idle.onTimeoutWarning.subscribe((countdown) => console.log('You will time out in ' + countdown + ' seconds!'));
    // // sets the ping interval to 15 seconds
    // keepalive.interval(15);
    // keepalive.onPing.subscribe(() => this.lastPing = new Date());
    translate.addLangs(['En-US', 'NL']);
    translate.setDefaultLang('En-US');

    const browserLang = translate.getBrowserLang();
    translate.use(browserLang.match(/En-US|NL/) ? browserLang : 'En-US');
    this.reset();
  }

  getLoginDetails() {
    const url = Utility.urlParams.escSrvc.url;
    this.commonService.getHttpLoginResponse(url).subscribe((response: any) => {
      if (response) {
        response.fullName = `${response.userFirstName} ${response.userLastName}`;
        Utility.userDetails = response;
        if (response && response.authroizes && Object.keys(response.authroizes).length > 0) {
          // tslint:disable-next-line:forin
          for (const i in response.authroizes) {
            if (this.newRoleLiterals[i]) {
              this.newRoleLiterals[i](response.authroizes[i]);
            }
          }
          if (this.activate) {
            this.actions = Array.from(new Set(this.actions.map((item: any) => item)));
            Utility.roleActions = {
              roles: this.roles,
              actions: this.actions,
              roleUser: this.roleUser,
              roleName: this.roleName
            };
            this.commonService.loggedInDetails.next(response);

            Utility.seSessionStorageItem('userDetails', JSON.stringify(response));
            if (response.accessibleCountries) {
              this.countryAccessDetails = response.accessibleCountries;
            }
            if (!this.countryAccessDetails) {
              this.countryAccessDetails = '';
            }
            if (this.countryAccessDetails) {
              let arr = this.countryAccessDetails.split(',');
              arr = arr.sort();
              this.countryAccessDetails = arr.join(',');
            }
            this.getCountryLists();
          }
        } else {
          this.activate = false;
        }
      }
    },
      (error) => {
        if (error && error.toString().indexOf('Error: 401') > -1) {
          this.activate = false;
        }
        this.activate = false;
      });
  }

  getCountryLists() {
    this.commonService.getAPIResponse(Utility.urlParams.countryList.url, { type: 'ALL' },
      Utility.urlParams.countryList.type).subscribe((response) => {
        Utility.commonStaticObject.cnty = response;
        Utility.commonStaticObject.cntyDefault = Utility.userDetails.countryCode;

        Utility.countryCodeNameMap = {};
        Utility.commonStaticObject.cnty.map((country) => {
          country.name = country.ctryNm;
          Utility.countryCodeNameMap[country.ctryCd] = country.ctryNm;
          Utility.countryCodeDetailMap[country.ctryCd] = country;
          country.value = country.ctryCd;
        });
        this.computeURL();
      });
  }

  logOut() {
    this.commonService.logoutOTT();
  }
}
