import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { HttpClientModule, HttpClient } from '@angular/common/http';
import { RouterModule } from '@angular/router';


import { AppRoutingModule } from './app.routing';
import { ComponentsModule } from './components/components.module';
import { AppComponent } from './app.component';
import { PendingInterceptorModule } from './components/loading-indicator/pending-interceptor.module';
import { LayoutComponent } from './layouts/layout/layout.component';
import { CommonService } from './common/common.service';
import { TranslateModule } from '@ngx-translate/core';
import { from } from 'rxjs';


@NgModule({
  imports: [
    BrowserAnimationsModule,
    FormsModule,
    ReactiveFormsModule,
    HttpModule,
    HttpClientModule,
    ComponentsModule,
    RouterModule,
    AppRoutingModule,
    PendingInterceptorModule,
  ],
  declarations: [
    AppComponent,
    LayoutComponent,

  ],
  providers: [CommonService],
  bootstrap: [AppComponent]
})
export class AppModule { }
