
import { ComponentFixture, async, TestBed } from "@angular/core/testing";
import { HttpClientTestingModule } from "@angular/common/http/testing";
import { RouterTestingModule } from "@angular/router/testing";
import { FormsModule, ReactiveFormsModule, FormGroup } from "@angular/forms";

import { MaterialModule } from "app/components/material.module";
import { DynFormModule } from "app/components/dyn-forms/dyn-forms.module";

import { WorkFlowComponent } from "./workflow.component";
import { RenderEngineComponent } from "./render-engine/render-engine.component";

import { RenderEngineDirective } from "./render-engine/render-engine.directive";

import { CommonService } from "app/common/common.service";
import { WorkFlowService } from "./workflow.service";
import { GET_API_RESPONSE, MODULENAMES, WORKFLOWSCREENNAMES } from "./workflow-items/workflow";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { WorkFlowItemModule } from "./workflow-items/workflow-item.module";
import { CustomerComponent } from "./workflow-items/customer/customer.component";

const MockCommonService = {
    getAPIResponse: jasmine.createSpy('getAPIResponse ').and.returnValue({subscribe: () => GET_API_RESPONSE}),
    getGenericForkJoin: jasmine.createSpy('getGenericForkJoin').and.returnValue({subscribe: () => {}}),
}

const MockWorkFlowService = {

}

describe('WorkFlowComponent', () => {
    let component: WorkFlowComponent;
    let fixture: ComponentFixture<WorkFlowComponent>;

    let renderEngineComponent: RenderEngineComponent;
    let renderEngineFixture: ComponentFixture<RenderEngineComponent>;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            declarations: [
                WorkFlowComponent,
                RenderEngineComponent,
                RenderEngineDirective,
            ],
            imports: [
                BrowserAnimationsModule,
                FormsModule,
                ReactiveFormsModule,
                RouterTestingModule,
                HttpClientTestingModule,
                MaterialModule,
                DynFormModule,
                WorkFlowItemModule
            ],
            providers: [
                { provide: CommonService, useValue: MockCommonService },
                { provide: WorkFlowService, useValue: MockWorkFlowService },
            ],
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(WorkFlowComponent);
        component = fixture.componentInstance;

        renderEngineFixture = TestBed.createComponent(RenderEngineComponent);
        renderEngineComponent = renderEngineFixture.componentInstance;

        renderEngineComponent.form = new FormGroup({});
        renderEngineFixture.detectChanges();
        fixture.detectChanges();

    });

    it('should create', () => {
        expect(WorkFlowComponent).toBeTruthy();
        component.ngOnInit();
        fixture.detectChanges();
        component.breadCrumbsData = GET_API_RESPONSE;       
        component.noSteps = component.breadCrumbsData.length;
        
        renderEngineFixture.detectChanges();
        fixture.detectChanges();
    });

    it('should define render engine form', () => {
        component.workFlowItems[MODULENAMES.AGREEMENTMODULE] = component.getForm(MODULENAMES.AGREEMENTMODULE);
        component.workFlowItems[MODULENAMES.CUSTOMERMODULE] = component.getForm(MODULENAMES.CUSTOMERMODULE);
        component.workFlowItems[MODULENAMES.PRICINGMODULE] = component.getForm(MODULENAMES.PRICINGMODULE);
        component.workFlowItems[MODULENAMES.PRICINGMODULE] = component.getForm(MODULENAMES.PRICINGMODULE);
        expect(component.workFlowItems.AGREEMENTMODULE).toBeDefined();
        expect(component.workFlowItems.CUSTOMERMODULE).toBeDefined();
        expect(component.workFlowItems.PRICINGMODULE).toBeDefined();
        expect(component.workFlowItems.PRICINGMODULE).toBeDefined();
    });

    it('should initiate the workflow', () => {
        component.workFlowComm = new WorkFlowComm();
        component.workFlowComm.workFlowItems = {};
        component.workFlowComm.workFlowResponses = {};
        component.workFlowComm.pKey = '562';
        component.workFlowComm.isEdit = false; 

        component.pKey = component.workFlowComm.pKey;
        
        component.isActivated = true;
        component.breadCrumbsData = GET_API_RESPONSE;
        component.workFlowScreenNames = WORKFLOWSCREENNAMES;
        renderEngineComponent.data = component.workFlowComm;
        
        renderEngineFixture.detectChanges();
        fixture.detectChanges();
        
        expect(component.isActivated).toBeTruthy();
    });
});

class WorkFlowComm {
    isEdit: boolean;
    workFlowResponses: any;
    workFlowItems: any;
    pKey: string;
}