/*
 * SonarQube, open source software quality management tool.
 * Copyright (C) 2008-2013 SonarSource
 * mailto:contact AT sonarsource DOT com
 *
 * SonarQube is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or (at your option) any later version.
 *
 * SonarQube is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

import {
    ComponentFactoryResolver,
    ComponentRef,
    Directive,
    Input,
    OnInit,
    ViewContainerRef
} from '@angular/core';
import { FormGroup } from '@angular/forms';
import { CustomerComponent } from '../workflow-items/customer/customer.component';
import { PricingComponent } from '../workflow-items/pricing/pricing.component';
import { AgreementComponent } from '../workflow-items/agreement/agreement.component';
import { PrintPresentComponent } from '../workflow-items/print-present/print-present.component';

const componentMapper = {
    CUSTOMERMODULE: CustomerComponent,
    PRICINGMODULE: PricingComponent,
    AGREEMENTMODULE: AgreementComponent,
    PRINTPRESENT: PrintPresentComponent
};
@Directive({
    // tslint:disable-next-line:directive-selector
    selector: '[dynamicComponent]'
})
export class RenderEngineDirective implements OnInit {
    @Input() component: string;
    @Input() form: FormGroup;
    @Input() data: any;
    @Input() currentModuleName: any;

    componentRef: any;
    constructor(
        private resolver: ComponentFactoryResolver,
        private container: ViewContainerRef
    ) { }
    ngOnInit() {
        if (!componentMapper[this.component]) {
            return;
        }
        const factory = this.resolver.resolveComponentFactory(
            componentMapper[this.component]
        );
        this.componentRef = this.container.createComponent(factory);
        this.componentRef.instance.field = this.component;
        this.componentRef.instance.form = this.form;
        this.componentRef.instance.data = this.data;
        this.componentRef.instance.currentModuleName = this.currentModuleName;
    }
}
