/*
 * SonarQube, open source software quality management tool.
 * Copyright (C) 2008-2013 SonarSource
 * mailto:contact AT sonarsource DOT com
 *
 * SonarQube is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or (at your option) any later version.
 *
 * SonarQube is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */


import { Injectable } from '@angular/core';
import { Utility } from '../common/Utility';
import { Observable } from 'rxjs';
import { Validator, Validators } from '@angular/forms';
import { CommonService } from '../common/common.service';
declare var $: any;


@Injectable()
export class WorkFlowService {
    isEditMode = false;
    countryCode: any;
    screenRelatedData = [];
    workFlowComponent: any;

    constructor ( private commonService: CommonService ) {  }

    isEditAllowed() {
        const promise = new Promise((resolve, reject) => {
            this.commonService.getAPIResponse(Utility.urlParams.getProposalStatus.url,
                { prpsId: this.workFlowComponent.salesFeedNumber}, Utility.urlParams.getProposalStatus.type)
                .subscribe((response: any) => {
                    if ( Utility.commonStaticObject.editAllowed.indexOf(response.status) > -1) {
                        resolve(true)
                    } else {
                        resolve(false)
                    }
                })
        });
        return promise;
    }
}
