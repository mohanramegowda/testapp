/*
* SonarQube, open source software quality management tool.
* Copyright (C) 2008-2013 SonarSource
* mailto:contact AT sonarsource DOT com
*
* SonarQube is free software; you can redistribute it and/or
* modify it under the terms of the GNU Lesser General Public
* License as published by the Free Software Foundation; either
* version 3 of the License, or (at your option) any later version.
*
* SonarQube is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
* Lesser General Public License for more details.
*
* You should have received a copy of the GNU Lesser General Public License
* along with this program; if not, write to the Free Software Foundation,
* Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/


import {
    Component, OnInit, ViewChild, ViewContainerRef,
    ChangeDetectorRef, ComponentFactoryResolver, ComponentFactory, ComponentRef, Input, Output, forwardRef
} from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { Location } from '@angular/common';
import { Observable, Subject } from 'rxjs';
import { DateAdapter, MAT_DATE_FORMATS, MatDialog, MatStepper, MatInput } from '@angular/material';

import { CommonService } from '../../../common/common.service';
import { Utility } from '../../../common/Utility';
import { FormBuilder, FormGroup, FormControl, NG_VALUE_ACCESSOR } from '@angular/forms';

import { APP_DATE_FORMATS, AppDateAdapter } from '../../../common/customDatePicker';
import { startWith } from 'rxjs/operators/startWith';
import { map } from 'rxjs/operators/map';
import { ControlValueBase } from '../../../common/control-value.base';
import { PricingScreenConfig } from './pricing-screenconfig';


@Component({
    selector: 'app-pricing',
    templateUrl: './pricing.component.html',
    styleUrls: ['./pricing.component.scss'],
    providers: [
        {
            provide: NG_VALUE_ACCESSOR,
            useExisting: forwardRef(() => PricingComponent),
            multi: true
        },
        {
            provide: DateAdapter, useClass: AppDateAdapter
        },
        {
            provide: MAT_DATE_FORMATS, useValue: APP_DATE_FORMATS
        },
        {
            provide: MatInput
        }]
})

export class PricingComponent extends ControlValueBase implements OnInit {

    regConfig: any;
    dialogRef: any;
    dialogData: any;
    @ViewChild('fileupload', { static: false })
    fileupload: ViewContainerRef;
    showDiscount = false;
    discountData: any;
    fullPath = `${Utility.urlParams.exportTemplate.url}/${Utility.userDetails.countryCode}`;
    sortedOrder = ['PARCELS', 'FREIGHT'];
    tempDiscountData: any;
    isEdit = false;
    pKey: any;
    data: any;
    existingData: any;
    form: FormGroup;
    currentModuleName: any;
    hideDiscount = false;

    constructor(private commonService: CommonService, private dialog: MatDialog) {
        super();
        this.constructScreen();
    }

    ngOnInit() {
        this.pKey = this.data.pKey;
        if (this.data.workFlowItems && this.data.workFlowItems.PRICINGMODULE && this.data.workFlowItems.PRICINGMODULE.discountData) {
            this.isEdit = true;
            this.discountData = JSON.parse(JSON.stringify(this.data.workFlowItems.PRICINGMODULE.discountData));
            this.existingData = JSON.parse(JSON.stringify(this.data.workFlowItems.PRICINGMODULE.discountData));
            this.tempDiscountData = this.existingData;
            this.hideDiscount = true;
            this.constructScreen();
            this.constructPivot();
            this.showDiscount = true;
            return;
        } else if (this.data.isEdit) {
            this.isEdit = true;
            this.getById();
            return;
        }
    }

    getById() {
        this.commonService.getAPIResponse(`${Utility.urlParams.wfGetStep.url}/${this.currentModuleName}/${this.pKey}`, null,
            Utility.urlParams.wfGetStep.type).subscribe((response: any) => {
                if (response) {
                    if (response.parentScreen && response.parentScreen.pricing) {
                        this.discountData = JSON.parse(JSON.stringify(response.parentScreen.pricing));
                        $(document).trigger('wf-store-response',
                            { moduleName: 'PRICINGMODULE', parentScreen: this.discountData });
                        this.tempDiscountData = JSON.parse(JSON.stringify(response.parentScreen.pricing));
                        this.showDiscount = true;
                        this.constructPivot();
                        this.putDiscountData();
                    }
                }
            })
    }

    checkForm(data) {
        if (data && data.PRICINGMODULE) {
            if (!data.PRICINGMODULE.valid) {
                this.commonService.showNotifier('Please Import Pricing Template to continue', 'error');
            }
        }
    }

    onClick(event) {
        if (!event || (event && !event.field)) {
            return
        }
        switch (event.field.name) {
            case 'exportTemplate':
                this.exportTemplate();
                break;
            case 'importTemplate':
                this.importTemplate();
                break;
        }
    }

    private exportTemplate() {
        const url = this.fullPath;
        window.open(url);
    }

    private importTemplate() {
        const formData = new FormData();
        this.openModal(this.fileupload, { ptFiles: formData });
    }

    private openModal(templateRef, data = null) {
        this.dialogData = data;
        this.dialogRef = this.dialog.open(templateRef, {});
        this.dialogRef.afterClosed().subscribe(result => {
            this.dialogData = null;
        });
    }

    closeModal(val = null) {
        this.dialogRef.close(val);
    }

    putDiscountData() {
        this.form.get('discountData').patchValue(this.discountData);
    }

    constructScreen(existingData = null) {
        this.regConfig = this.commonService.buildField(PricingScreenConfig.config, { discountData: this.discountData });
        this.regConfig = this.regConfig.fieldsConfig;
    }

    uploadfiles(val = null) {
        this.dialogRef.close(val);
        const files: FileList = val.filesList;
        if (!files || (files && files.length <= 0)) {
            this.commonService.showNotifier('Please Import Pricing Template to continue', 'error')
            return;
        }
        const formData = new FormData();
        for (let i = 0; i < files.length; i += 1) {
            formData.append('fileUpload', files[i]);
        }
        //
        // Utility.urlParams.importTemplate.url
        this.commonService.getAPIResponse(Utility.urlParams.importTemplate.url, formData,
            Utility.urlParams.importTemplate.type).subscribe((response: any) => {
                if (response.data) {
                    this.discountData = JSON.parse(JSON.stringify(response.data));
                    this.tempDiscountData = JSON.parse(JSON.stringify(response.data));
                    this.showDiscount = true;
                    this.constructPivot();
                    this.putDiscountData();
                }
            });
    }

    toUpperCase(str) {
        if (!str) {
            return '';
        }
        return str.toUpperCase();
    }

    toLowerCase(str) {
        if (!str) {
            return '';
        }
        return str.toLowerCase();
    }

    constructPivot() {
        if (this.tempDiscountData) {
            for (const i in this.tempDiscountData) {
                if (this.tempDiscountData[i] && this.tempDiscountData[i].length > 0) {
                    this.tempDiscountData[i].map((typeDiscount) => {
                        typeDiscount.uiDiscounts = [];
                        typeDiscount.minPrices = [];
                        if (typeDiscount.packageTypes && typeDiscount.packageTypes.length > 0) {
                            const packagePrimaryMap = {};
                            const packageSecondaryMap = {};
                            const zones = [];
                            const packages = {};
                            typeDiscount.packageTypes.map((pkg: any) => {
                                const str = `${pkg.packageType};${pkg.weightFrom};${pkg.weightTo}`;
                                const strZne = `${pkg.packageType};${pkg.zoneName} - Discount`;
                                if (!packagePrimaryMap[str] && !packageSecondaryMap[str]) {
                                    packagePrimaryMap[str] = [];
                                    packageSecondaryMap[str] = [];
                                    packagePrimaryMap[str].push(pkg.packageType);
                                    packageSecondaryMap[str].push(pkg.packageType);
                                    packagePrimaryMap[str].push(pkg.weightFrom);
                                    packagePrimaryMap[str].push(pkg.weightTo);
                                }
                                if (pkg.minCharge) {
                                    if (!packages[strZne]) {
                                        packageSecondaryMap[str].push(pkg.minCharge);
                                        packages[strZne] = true;
                                    }
                                } else {
                                    if (!packages[strZne]) {
                                        packageSecondaryMap[str].push(pkg.minimumBillable);
                                        packages[strZne] = true;
                                    }
                                }
                                packagePrimaryMap[str].push(pkg.discountPercentage);
                                if (zones.indexOf(pkg.zoneName + ' - Discount') === -1) {
                                    if (pkg.minCharge) {
                                        zones.push(pkg.zoneName + ' - Min Charge');
                                    } else {
                                        zones.push(pkg.zoneName + ' - Min Billable');
                                    }
                                    zones.push(pkg.zoneName + ' - Discount');
                                }
                            });
                            if (i === 'parcels') {
                                typeDiscount.uiDiscounts.push(['Package Type', 'Weight From', 'Weight To']);
                                typeDiscount.minPrices.push(['Package Type']);
                            } else {
                                typeDiscount.uiDiscounts.push(['Package Type', 'Weight From', 'Weight To']);
                                typeDiscount.minPrices.push(['Package Type']);
                            }
                            zones.map((zone) => {
                                if (zone.match(/Min Charge/g) || zone.match(/Min Billable/g)) {
                                    typeDiscount.minPrices[0].push(zone);
                                } else {
                                    typeDiscount.uiDiscounts[0].push(zone);
                                }
                            })
                            for (const packageKey in packagePrimaryMap) {
                                if (packagePrimaryMap[packageKey]) {
                                    typeDiscount.uiDiscounts.push(packagePrimaryMap[packageKey]);
                                }
                            }
                            for (const packageKey in packageSecondaryMap) {
                                if (packageSecondaryMap[packageKey] && packageSecondaryMap[packageKey].length > 1) {
                                    typeDiscount.minPrices.push(packageSecondaryMap[packageKey]);
                                }
                            }
                        }
                    })
                }
            }
        }
    }
}
