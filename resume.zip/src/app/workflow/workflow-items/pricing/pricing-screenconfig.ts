export class PricingScreenConfig {
    static config = {
        fields: [
            {
                type: 'button',
                inputType: 'button',
                label: 'Export Template',
                name: 'exportTemplate',
                styleColor: 'primary',
                styleId: 'protract-export',
                styleClass: 'col-6'
            },
            {
                type: 'button',
                inputType: 'button',
                label: 'Import Template',
                name: 'importTemplate',
                styleId: 'protract-import',
                styleColor: 'warn',
                value: '',
                styleClass: 'col-6'
            },
            {
                type: 'input',
                label: '',
                inputType: 'text',
                hidden: true,
                name: 'discountData',
                utilFieldNm: 'discountData',
                defaultValueRef: 'discountData',
                value: '',
                validations: [{
                    name: 'required',
                    value: '',
                    message: 'Discount is Required'
                }]
            },
        ]
    }
}
