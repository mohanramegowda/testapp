export class PrintPreviewScreenConfig {
    static config = {
        fields: [
            {
                type: 'labelDesc',
                label: 'Legal Name on Agreement',
                value: '',
                inputType: 'text',
                styleClass: 'col-12',
                styleSubClass: 'col-4',
                styleId: 'protract-name',
                name: 'lglNm',
            },
            {
                type: 'labelDesc',
                label: 'Contract Start Date',
                value: '',
                inputType: 'text',
                styleClass: 'col-12',
                styleSubClass: 'col-4',
                styleId: 'protract-s-date',
                name: 'ctrcStrtDtFormat',
            },
            {
                type: 'labelDesc',
                label: 'Contract End Date',
                value: '',
                inputType: 'text',
                styleClass: 'col-12',
                styleSubClass: 'col-4',
                styleId: 'protract-e-date',
                name: 'ctrcEndDtFormat',
            },
            {
                type: 'labelDesc',
                label: 'Country Customer Belongs To',
                name: 'ctryCusSignatoryBelongsTo',
                styleClass: 'col-12',
                styleId: 'protract-cust',
                styleSubClass: 'col-4',
                value: '2',
                validations: []
            },
            {
                type: 'radiobutton',
                label: '',
                value: 'PRINT',
                styleClass: 'col-12 mt-4',
                styleSubClass: 'col-4',
                utilFieldNm: 'radioOpts',
                name: 'agmtOptCd',
                styleId: 'protract-print-radio',
                options: [],
                validations: []
            }
        ]
    }
}
