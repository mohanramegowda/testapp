/*
* SonarQube, open source software quality management tool.
* Copyright (C) 2008-2013 SonarSource
* mailto:contact AT sonarsource DOT com
*
* SonarQube is free software; you can redistribute it and/or
* modify it under the terms of the GNU Lesser General Public
* License as published by the Free Software Foundation; either
* version 3 of the License, or (at your option) any later version.
*
* SonarQube is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
* Lesser General Public License for more details.
*
* You should have received a copy of the GNU Lesser General Public License
* along with this program; if not, write to the Free Software Foundation,
* Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/


import { Component, OnInit, ViewChild, forwardRef, ViewContainerRef, ChangeDetectorRef } from '@angular/core';
import { DateAdapter, MAT_DATE_FORMATS, MatDialog, MatStepper } from '@angular/material';


import { FormControl, Validators, NG_VALUE_ACCESSOR, FormGroup } from '@angular/forms';

import { APP_DATE_FORMATS, AppDateAdapter } from '../../../common/customDatePicker';
import { DynamicFormComponent } from '../../../components/dyn-forms/dynamic-form/dynamic-form.component';
import { FieldConfig } from '../../../components/dyn-forms/field.interface';
import { CommonService } from 'app/common/common.service';
import { Utility } from 'app/common/Utility';
import { PrintPreviewScreenConfig } from './print-present-screenconfig';

@Component({
    selector: 'app-print-present',
    templateUrl: './print-present.component.html',
    styleUrls: ['./print-present.component.scss'],
    providers: [
        {
            provide: NG_VALUE_ACCESSOR,
            useExisting: forwardRef(() => PrintPresentComponent),
            multi: true
        },
        {
            provide: DateAdapter, useClass: AppDateAdapter
        },
        {
            provide: MAT_DATE_FORMATS, useValue: APP_DATE_FORMATS
        }]
})

export class PrintPresentComponent implements OnInit {
    @ViewChild(DynamicFormComponent, { static: false }) dynForm: DynamicFormComponent;
    @ViewChild('fileupload', { static: false })
    fileupload: ViewContainerRef;
    regConfig: any;
    showFields = false;
    agreementOptions = {};
    ctrcStrtDt = new Date();
    showDownload = false;
    form: FormGroup;
    paymentTerms: any;
    dialogRef: any;
    dialogData: any;
    commentsList: any = [];
    uploadedFiles: any = [];
    documentTypes: any = [];
    allDocumentTypes: any = [];
    documentDesc = '';
    isEdit = false;
    pKey = '';
    documentType = '';
    documentTypeOptions = {
        'ONBEHALF': ['EMAIL', 'SDOC'],
        'PRINT': ['SIGN', 'SDOC']
    }
    data: any;
    agreementData: any;
    existingData: any;

    constructor(private commonService: CommonService, private dialog: MatDialog, private cdRef: ChangeDetectorRef) {
    }

    ngOnInit() {
        this.isEdit = this.data.isEdit;
        this.pKey = this.data.pKey;
        this.showFields = false;
        if (this.data.workFlowItems && this.data.workFlowItems.AGREEMENTMODULE
            && this.data.workFlowItems.AGREEMENTMODULE) {
            this.agreementData = JSON.parse(JSON.stringify(this.data.workFlowItems.AGREEMENTMODULE));
            this.activate();
        }
    }

    activate() {
        const reqArr = [];
        reqArr.push({
            url: Utility.urlParams.agreementoption.url, param: { type: 'ALL' },
            type: Utility.urlParams.agreementoption.type
        });
        reqArr.push({
            url: Utility.urlParams.getDocumentTypes.url,
            param: { type: 'ALL' },
            type: Utility.urlParams.getDocumentTypes.type
        });
        reqArr.push({
            url: Utility.urlParams.getComments.url,
            param: { prpsId: this.pKey },
            type: Utility.urlParams.getComments.type
        });
        reqArr.push({
            url: Utility.urlParams.getAllFiles.url,
            param: { prpsId: this.pKey },
            type: Utility.urlParams.getAllFiles.type
        });
        this.commonService.getGenericForkJoin(reqArr).subscribe((responses: any) => {
            if (responses) {
                if (responses[0]) {
                    Utility.commonStaticObject.radioOpts = responses[0];
                    Utility.commonStaticObject.radioOpts.map((country) => {
                        country.name = country.optionNM;
                        country.value = country.agmtOptCd;
                    });
                }
                if (responses[1]) {
                    this.allDocumentTypes = (responses[1]) ? responses[1] : [];
                }
                if (responses[2]) {
                    this.commentsList = (responses[2] && responses[2].data) ? responses[2].data : [];
                }
                if (responses[3]) {
                    this.uploadedFiles = (responses[3] && responses[3].data) ? responses[3].data : [];
                }
                this.constructScreen();
                if (this.allDocumentTypes.length > 0) {
                    this.changeDocTypeList()
                }
            }
        }, (error) => {

        });
    }

    constructScreen() {
        let agreementData = this.agreementData;
        agreementData = (agreementData.ctrcEndDt) ? agreementData : agreementData.agreement || {};
        this.ctrcStrtDt = agreementData['ctrcStrtDt'];
        this.paymentTerms = agreementData['paymentTerms'];
        agreementData['ctrcStrtDtFormat'] = this.commonService.formatDateTime(this.ctrcStrtDt, 'DD-MMM-YYYY');
        agreementData['ctrcEndDtFormat'] = this.commonService.formatDateTime(agreementData['ctrcEndDt'], 'DD-MMM-YYYY');
        agreementData['ctryCusSignatoryBelongsTo'] = Utility.countryCodeNameMap[agreementData['ctryCusSignatoryBelongsTo']];
        this.regConfig = this.commonService.buildField(PrintPreviewScreenConfig.config, agreementData).fieldsConfig;
        this.showFields = true;
        this.checkAgrmtOption(agreementData.agmtOptCd);
        if (!this.cdRef['destroyed']) {
            this.cdRef.detectChanges();
        }
    }

    checkAgrmtOption(agmtOptCd = null) {
        this.form.valueChanges.subscribe(val => {
            if (val && val.agmtOptCd === 'PRINT') {
                this.showDownload = true;
            } else {
                this.showDownload = false;
            }
            this.changeDocTypeList();
        });
    }

    generatePreview() {
        let url = `${Utility.urlParams.generateAgreement.url}?prpsId=${this.pKey}`;
        url += `&effectiveDate=${this.commonService.formatDateTime(this.ctrcStrtDt, 'DD-MMM-YYYY')}`;
        url += `&paymentTerms=${this.paymentTerms}`;
        window.open(url);
    }

    addComment(event) {
        const request = {
            prpsId: this.pKey,
            comment: event,
            userId: Utility.userDetails.userId
        }
        // WORST PART. API to be changed to handle JSON
        const str = `${Utility.urlParams.addComments.url}?prpsId=${request.prpsId}&comment=${request.comment}&userId=${request.userId}`;
        this.commonService.getAPIResponse(str, request,
            Utility.urlParams.getDocumentTypes.type).subscribe((response: any) => {
                if (response && response.data && response.data.length > 0) {
                    if (!this.commentsList) {
                        this.commentsList = [];
                    }
                    this.commentsList.push(response.data[response.data.length - 1]);
                    this.commonService.showNotifier('Comment Added Successfully', 'success');
                }
            });
    }

    removeComment(commentData) {
        this.commonService.getAPIResponse(Utility.urlParams.deleteComment.url, {
            prpsId: this.pKey,
            commentId: commentData.comment.commentId
        }, Utility.urlParams.deleteComment.type).subscribe((response: any) => {
            this.commentsList.splice(commentData.index, 1);
            this.commonService.showNotifier('Comment Deleted Successfully', 'success');
        });

    }

    onUpload() {
        const formData = new FormData();
        this.openModal(this.fileupload, { ptFiles: formData });
    }

    private openModal(templateRef, data = null) {
        this.dialogData = data;
        this.dialogRef = this.dialog.open(templateRef, {});
        this.dialogRef.afterClosed().subscribe(result => {
            this.dialogData = null;
        });
    }

    closeModal(val = null) {
        this.dialogRef.close(val);
    }

    uploadfiles(val = null) {
        const files: FileList = val.filesList;
        if (!files || (files && files.length <= 0)) {
            this.commonService.showNotifier('Please select file to upload', 'error')
            return;
        }
        if (!this.documentType || (this.documentType && this.documentType.length <= 0)) {
            this.commonService.showNotifier('Please select a document type', 'error')
            return;
        }
        if (this.documentType === 'Signed Agreement') {
            for (let j = 0; j < files.length; j++) {
                const fileExtention = files[j].name.substr(files[j].name.lastIndexOf('.') + 1).toLowerCase();
                if (fileExtention !== 'pdf') {
                    this.commonService.showNotifier('Signed Agreement should be a PDF document ', 'error')
                    return;
                }
            }
        }
        const formData = new FormData();
        for (let i = 0; i < files.length; i += 1) {
            formData.append('fileUpload', files[i]);
            formData.append('prpsId', this.pKey);
            formData.append('userId', Utility.userDetails.userId);
            formData.append('documentType', this.documentType);
            formData.append('description', this.documentDesc)
        }

        this.commonService.getAPIResponse(Utility.urlParams.uploadDocument.url, formData,
            Utility.urlParams.uploadDocument.type).subscribe((response: any) => {
                this.commonService.showNotifier('Document Uploaded Successfully', 'success');
                this.uploadedFiles.push(response.data);
                this.documentDesc = '';
                this.documentType = '';
            });
    }

    downloadFile(val = null) {
        if (val) {
            window.open(`${Utility.urlParams.downloadDocument.url}/${this.pKey}/${val}`);
        }
    }

    removeFile(event) {
        console.log(event);
    }

    changeDocTypeList() {
        if (!this.allDocumentTypes.length) {
            return;
        }
        const radioSelect = (this.form.value.agmtOptCd) ?
            this.form.value.agmtOptCd : this.agreementData.agmtOptCd ||
            Utility.commonStaticObject.radioOpts[0].value;
        const docTypes = value => this.documentTypeOptions[value];
        this.documentTypes = [];
        if (this.documentTypeOptions[radioSelect]) {
            const docTypeObject = value => this.allDocumentTypes.find((item) => item.CTG_CD === value);
            docTypes(radioSelect).map((item) => {
                const type = docTypeObject(item);
                this.documentTypes.push(type)
            });
            if (this.documentTypes && this.documentTypes.length > 0) {
                this.documentType = this.documentTypes[0].CTG_NM || '';
            }
        }
    }
}
