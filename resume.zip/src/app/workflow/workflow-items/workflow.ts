export const MODULENAMES = {
	AGREEMENTMODULE: 'AGREEMENTMODULE',
	CUSTOMERMODULE: 'CUSTOMERMODULE',
	PRICINGMODULE: 'PRICINGMODULE',
	PRINTPRESENT: 'PRINTPRESENT'
}

export const WORKFLOWSCREENNAMES = {
	CUSTOMERMODULE: 'Customer Information',
	PRICINGMODULE: 'Pricing Profile',
	AGREEMENTMODULE: 'Agreement Module',
	PRINTPRESENT: 'Print Present Module',
}

export const GET_API_RESPONSE = [{
	"currentStepNo": 1,
	"requestedCountry": null,
	"requesterUserId": null,
	"workflowId": null,
	"currentModuleName": "proud-customer-service",
	"currentModuleRelativeURL": "proud-customer-service/customer",
	"screenName": "CUSTOMERMODULE",
	"formName": "customer",
	"nextModuleName": null
}, {
	"currentStepNo": 2,
	"requestedCountry": null,
	"requesterUserId": null,
	"workflowId": null,
	"currentModuleName": "proud-products-service",
	"currentModuleRelativeURL": "proud-products-service/pricing",
	"screenName": "PRICINGMODULE",
	"formName": "pricing",
	"nextModuleName": null
}, {
	"currentStepNo": 3,
	"requestedCountry": null,
	"requesterUserId": null,
	"workflowId": null,
	"currentModuleName": "proud-agreement-service",
	"currentModuleRelativeURL": "proud-agreement-service/agreements",
	"screenName": "AGREEMENTMODULE",
	"formName": "agreement",
	"nextModuleName": null
}, {
	"currentStepNo": 4,
	"requestedCountry": null,
	"requesterUserId": null,
	"workflowId": null,
	"currentModuleName": "proud-print-present-service",
	"currentModuleRelativeURL": "proud-print-present-service/printpresent",
	"screenName": "PRINTPRESENT",
	"formName": "agreement",
	"nextModuleName": null
}];