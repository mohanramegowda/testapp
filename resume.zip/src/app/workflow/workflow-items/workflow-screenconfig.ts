export class WorkflowScreenConfig {
    static config = {
        customerDetail: {
            fields: [
                {
                    name: 'ean',
                    inputType: 'text',
                    type: 'input',
                    label: 'Enterprise Account Number',
                    styleClass: 'protract-ean',
                    opco: 'both',
                    validations: []
                },
                {
                    name: 'vatNm',
                    inputType: 'text',
                    type: 'input',
                    label: 'VAT Number',
                    opco: 'both',
                    styleClass: 'protract-vat',
                    validations: []
                },
                {
                    name: 'cmpyNm',
                    inputType: 'text',
                    type: 'input',
                    label: 'Company Name',
                    styleClass: 'protract-company',
                    opco: 'both',
                    validations: []
                },
                {
                    name: 'fedexContactNm',
                    inputType: 'text',
                    type: 'input',
                    label: 'FedEx Contact Name',
                    styleClass: 'protract-fedex-contact',
                    utilFieldNm: 'fullName',
                    opco: 'both',
                    validations: [{
                        name: 'required',
                        value: '',
                        message: 'FedEx Contact Name is Required'
                    }]
                },
                {
                    name: 'custContactNm',
                    inputType: 'text',
                    type: 'input',
                    label: 'Customer Contact Name',
                    opco: 'both',
                    validations: [
                        {
                            name: 'required',
                            value: '',
                            message: 'Customer Contact Name is Required'
                        }
                    ]
                },
                {
                    name: 'cnty',
                    type: 'select',
                    label: 'Country',
                    utilFieldNm: 'cnty',
                    defaultValueRef: 'cntyDefault',
                    opco: 'both',
                    value: '1',
                    options: [
                        {
                            'value': '1',
                            'name': 'Netherlands'
                        },
                        {
                            'value': '2',
                            'name': 'France'
                        },
                        {
                            'value': '3',
                            'name': 'Belgium'
                        }
                    ],
                    validations: [
                        {
                            name: 'required',
                            value: '',
                            message: 'Country is Required'
                        }
                    ]
                },
                {
                    name: 'custEmail',
                    inputType: 'text',
                    type: 'input',
                    label: 'Customer Email',
                    opco: 'both',
                    validations: [
                        {
                            name: 'required',
                            value: '',
                            message: 'Customer Email is Required'
                        },
                        {
                            name: 'pattern',
                            value: '^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$',
                            message: 'Invalid Email'
                        }
                    ]
                },
                {
                    name: 'custSegment',
                    type: 'select',
                    label: 'Customer Segment',
                    utilFieldNm: 'segment',
                    defaultValueRef: 'segmentDefault',
                    opco: 'both',
                    value: '1',
                    options: [
                        {
                            'value': '1',
                            'name': 'Segment 1'
                        },
                        {
                            'value': '2',
                            'name': 'Segment 2'
                        },
                        {
                            'value': '3',
                            'name': 'Segment 3'
                        }
                    ],
                    validations: [
                        {
                            name: 'required',
                            value: '',
                            message: 'Country is Required'
                        }
                    ]
                }
            ]
        },
        priceingDetail: {
            fields: [
                {
                    type: 'button',
                    label: 'Export Template',
                    name: 'exportTemplate',
                    styleColor: 'primary',
                    styleClass: 'col-md-4 col-xs-12',
                },
                {
                    type: 'button',
                    label: 'Import Template',
                    name: 'importTemplate',
                    styleColor: 'warn',
                    styleClass: 'col-md-4 col-xs-12',
                },
                {
                    type: 'tabTable',
                    label: '',
                    inputType: 'tabs',
                    name: 'discountData',
                    value: [],
                    validations: []
                },
            ]
        },
        agreementDetail: {
            fields: [
                {
                    type: 'select',
                    label: 'Agreement Template',
                    name: 'agreementTemplateCd',
                    value: '1',
                    options: [
                        {
                            'value': 'Template 1',
                            'name': 'Template 1'
                        },
                        {
                            'value': 'Template 2',
                            'name': 'Template 2'
                        },
                        {
                            'value': 'Template 3',
                            'name': 'Template 3'
                        }
                    ],
                    validations: [{
                        name: 'required',
                        value: '',
                        message: 'Template is Required'
                    }]
                },
                {
                    type: 'input',
                    label: 'Legal Name on Agreement',
                    inputType: 'text',
                    name: 'legaLName',
                    validations: [
                        {
                            name: 'required',
                            value: '',
                            message: 'Legal Name is Required'
                        },
                    ]
                },
                {
                    type: 'date',
                    label: 'Contract Start Date',
                    name: 'ctrcStrtDt',
                    validations: [
                        {
                            name: 'required',
                            value: '',
                            message: 'Contract Start Date is Required'
                        }
                    ]
                },
                {
                    type: 'date',
                    label: 'Contract End Date',
                    name: 'ctrcEndDt',
                    validations: [
                        {
                            name: 'required',
                            value: '',
                            message: 'Contract End Date is Required'
                        }
                    ]
                },
                {
                    type: 'select',
                    label: 'Alternate Language',
                    name: 'altLangCd',
                    value: '1',
                    options: [
                        {
                            'value': '1',
                            'name': 'English'
                        },
                    ],
                    validations: []
                },
                {
                    type: 'select',
                    label: 'Country Customer Belongs To',
                    name: 'ctryCusSignatoryBelongsTo',
                    value: '2',
                    options: [
                        {
                            'value': '1',
                            'name': 'Belgium'
                        },
                        {
                            'value': '2',
                            'name': 'Netherlands'
                        },
                        {
                            'value': '3',
                            'name': 'France'
                        }
                    ],
                    validations: []
                },
                {
                    'name': 'hidden1',
                    'inputType': 'hidden',
                    'type': 'text',
                    'label': '',
                    'opco': 'fedex',
                    'options': [],
                    'validations': []
                },
                {
                    'type': 'button',
                    'inputType': 'submit',
                    'name': 'exportTemplate',
                    'styleColor': 'warn',
                    'styleClass': 'float-right mb-3',
                    'label': 'Preview Agreement'
                }
            ]
        },
        printPresentDetail: {
            fields: [
                {
                    type: 'labelDesc',
                    label: 'Legal Name on Agreement',
                    value: '',
                    inputType: 'text',
                    styleClass: 'col-12',
                    styleSubClass: 'col-4',
                    name: 'legaLName',
                },
                {
                    type: 'labelDesc',
                    label: 'Contract Start Date',
                    value: '',
                    inputType: 'text',
                    styleClass: 'col-12',
                    styleSubClass: 'col-4',
                    name: 'ctrcStrtDt',
                },
                {
                    type: 'labelDesc',
                    label: 'Contract End Date',
                    value: '',
                    inputType: 'text',
                    styleClass: 'col-12',
                    styleSubClass: 'col-4',
                    name: 'ctrcEndDt',
                },
                {
                    type: 'labelDesc',
                    label: 'Legal Name on Agreement(Alternate)',
                    value: '',
                    inputType: 'text',
                    styleClass: 'col-12',
                    styleSubClass: 'col-4',
                    name: 'altLangCd',
                },
                {
                    type: 'labelDesc',
                    label: 'Country Customer Belongs To',
                    name: 'ctryCusSignatoryBelongsTo',
                    styleSubClass: 'col-4',
                    value: '2',
                    options: [
                        {
                            'value': '1',
                            'name': 'Belgium'
                        },
                        {
                            'value': '2',
                            'name': 'Netherlands'
                        },
                        {
                            'value': '3',
                            'name': 'France'
                        }
                    ],
                    validations: []
                },
                {
                    type: 'radiobutton',
                    label: '',
                    name: 'agreementOptionCd',
                    styleClass: 'mt-4',
                    styleSubClass: 'display:block',
                    value: '',
                    utilFieldNm: 'radioOpts',
                    options: [
                        'Print the agreement, present it to the customer and scan/fax/mail the signed copy to Pricing Administration',
                        'Sign on Behalf'
                    ],
                    validations: []
                }
            ]
        }
    }
}
