export class AgreementScreenConfig {
    static endDate = new Date();
    static config = {
        fields: [
            {
                type: 'select',
                label: 'Agreement Template',
                name: 'agmtTemId',
                value: 'Template 1',
                utilFieldNm: 'agreementTemplates',
                defaultValueRef: 'agreementTemplateDflt',
                styleId: 'protract-template',
                options: [
                    {
                        'value': 'Template 1',
                        'name': 'Template 1'
                    },
                    {
                        'value': 'Template 2',
                        'name': 'Template 2'
                    },
                    {
                        'value': 'Template 3',
                        'name': 'Template 3'
                    }
                ],
                validations: [{
                    name: 'required',
                    value: '',
                    message: 'Country is Required'
                }]
            },
            {
                type: 'input',
                disabled: true,
                label: 'Legal Name on Agreement',
                inputType: 'text',
                name: 'lglNm',
                styleId: 'protract-name',
                validations: [
                    {
                        name: 'required',
                        value: '',
                        message: 'Legal Name is Required'
                    },
                    {
                        name: 'pattern',
                        value: '^[^\\s].+$',
                        message: 'Legal name is invalid'
                    }
                ]
            },
            {
                type: 'select',
                disabled: true,
                label: 'Payment Terms',
                name: 'paymentTerms',
                styleId: 'protract-payment-terms',
                value: '7',
                options: [
                    {
                        'value': '1',
                        'name': '1'
                    },
                    {
                        'value': '7',
                        'name': '7'
                    },
                    {
                        'value': '14',
                        'name': '14'
                    },
                    {
                        'value': '28',
                        'name': '28'
                    }
                ],
                validations: []
            },
            {
                type: 'select',
                disabled: true,
                label: 'Invoicing Frequency',
                name: 'invoicingFreq',
                styleId: 'protract-invoice-freq',
                value: 'Week',
                options: [
                    {
                        'value': 'Day',
                        'name': 'Day'
                    },
                    {
                        'value': 'Week',
                        'name': 'Week'
                    },
                    {
                        'value': 'Bi-Weekly',
                        'name': 'Bi-Weekly'
                    }
                ],
                validations: []
            },
            {
                type: 'date',
                label: 'Contract Start Date',
                value: new Date(),
                styleId: 'protract-s-date',
                name: 'ctrcStrtDt',
                validations: [
                    {
                        name: 'required',
                        value: '',
                        message: 'Contract Start Date is Required'
                    }
                ]
            },
            {
                type: 'date',
                label: 'Contract End Date',
                name: 'ctrcEndDt',
                value:  '',
                styleId: 'protract-e-date',
                min: new Date(),
                validations: [
                    {
                        name: 'required',
                        value: '',
                        message: 'Contract End Date is Required'
                    }
                ]
            },
            {
                type: 'select',
                label: 'Language',
                name: 'altLangCd',
                utilFieldNm: 'altLngs',
                styleId: 'protract-a-lang',
                defaultValueRef: 'altLngsDflt',
                value: '1',
                options: [
                    {
                        'value': '1',
                        'name': 'English'
                    },
                ],
                validations: []
            },
            {
                type: 'select',
                label: 'Country Customer Belongs To',
                name: 'ctryCusSignatoryBelongsTo',
                utilFieldNm: 'cnty',
                defaultValueRef: 'cntyDefault',
                styleId: 'protract-cust',
                value: '2',
                options: [
                    {
                        'value': '1',
                        'name': 'Belgium'
                    },
                    {
                        'value': '2',
                        'name': 'Netherlands'
                    },
                    {
                        'value': '3',
                        'name': 'France'
                    }
                ],
                validations: []
            },
            {
                type: 'input',
                label: '',
                inputType: 'text',
                hidden: true,
                name: 'agreementData',
                value: '',
                validations: [{
                    name: 'required',
                    value: '',
                    message: 'Please Generate Agreement'
                }]
            },
        ]
    }
}
