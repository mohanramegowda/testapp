/*
* SonarQube, open source software quality management tool.
* Copyright (C) 2008-2013 SonarSource
* mailto:contact AT sonarsource DOT com
*
* SonarQube is free software; you can redistribute it and/or
* modify it under the terms of the GNU Lesser General Public
* License as published by the Free Software Foundation; either
* version 3 of the License, or (at your option) any later version.
*
* SonarQube is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
* Lesser General Public License for more details.
*
* You should have received a copy of the GNU Lesser General Public License
* along with this program; if not, write to the Free Software Foundation,
* Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/


import { Component, OnInit, ViewChild, forwardRef, ChangeDetectorRef } from '@angular/core';
import { DateAdapter, MAT_DATE_FORMATS, MatDialog, MatStepper } from '@angular/material';


import { FormControl, Validators, NG_VALUE_ACCESSOR, FormGroupDirective, FormGroup } from '@angular/forms';

import { APP_DATE_FORMATS, AppDateAdapter } from '../../../common/customDatePicker';
import { DynamicFormComponent } from '../../../components/dyn-forms/dynamic-form/dynamic-form.component';
import { FieldConfig } from '../../../components/dyn-forms/field.interface';
import { AgreementScreenConfig } from './agreement-screenconfig';
import { Utility } from 'app/common/Utility';
import { CommonService } from 'app/common/common.service';

@Component({
    selector: 'app-agreement',
    templateUrl: './agreement.component.html',
    styleUrls: ['./agreement.component.scss'],
    providers: [
        {
            provide: NG_VALUE_ACCESSOR,
            useExisting: forwardRef(() => AgreementComponent),
            multi: true
        },
        {
            provide: DateAdapter, useClass: AppDateAdapter
        },
        {
            provide: MAT_DATE_FORMATS, useValue: APP_DATE_FORMATS
        }]
})

export class AgreementComponent implements OnInit {
    @ViewChild(DynamicFormComponent, { static: false }) rmdynForm: DynamicFormComponent;

    regConfig: any;
    showPreview = false;
    showFields = false;
    form: FormGroup;
    showDownload = false;
    isEdit: boolean;
    editData: any;
    pKey: any;
    data: any;
    customerData: any;
    existingData: any;
    currentModuleName: any;

    constructor(
        private commonService: CommonService,
        private cdRef: ChangeDetectorRef
    ) { }

    ngOnInit() {
        this.pKey = this.data.pKey;
        this.isEdit = this.data.isEdit;
        if (this.data.workFlowItems && this.data.workFlowItems.CUSTOMERMODULE
            && this.data.workFlowItems.CUSTOMERMODULE) {
            this.customerData = this.data.workFlowItems.CUSTOMERMODULE;
        }
        // TODO: Change this to Object Literals
        if (this.data.workFlowItems && this.data.workFlowItems.AGREEMENTMODULE
            && this.data.workFlowItems.AGREEMENTMODULE) {
            this.isEdit = true;
            this.existingData = this.data.workFlowItems.AGREEMENTMODULE;
            this.processData([Utility.commonStaticObject.agreementTemplates, Utility.commonStaticObject.altLngs]);
            return;
        } else if (this.isEdit || !this.existingData || (!Utility.commonStaticObject.agreementTemplates
            || !Utility.commonStaticObject.altLngs)) {
            this.getScreenConfig();
        } else if (this.isEdit && Utility.commonStaticObject.agreementTemplates
            && Utility.commonStaticObject.altLngs) {
            this.processData([Utility.commonStaticObject.agreementTemplates, Utility.commonStaticObject.altLngs]);
            return;
        }
        this.getScreenConfig();

    }

    getScreenConfig() {
        const request = { type: 'ALL' };
        const reqArr = [{
            url: Utility.urlParams.agreementTemplate.url, param: request,
            type: Utility.urlParams.agreementTemplate.type
        }, {
            url: Utility.urlParams.altLanguage.url, param: request,
            type: Utility.urlParams.altLanguage.type
        }];
        if (!this.existingData && this.isEdit) {
            const req = {
                url: `${Utility.urlParams.wfGetStep.url}/${this.currentModuleName}/${this.pKey}`, param: null,
                type: Utility.urlParams.wfGetStep.type
            }
            reqArr.push(req);
        }
        this.commonService.getGenericForkJoin(reqArr).subscribe((responses) => {
            this.processData(responses);
        });
    }

    processData(responses) {
        let dataObject = null;
        if (responses) {
            if (this.pKey && responses[2]) {
                dataObject = responses[2];
                if (dataObject && dataObject.parentScreen && dataObject.parentScreen.agreement) {
                    $(document).trigger('wf-store-response',
                        { moduleName: 'AGREEMENTMODULE', parentScreen: dataObject.parentScreen });
                    $(document).trigger('wf-store-response',
                        { moduleName: 'PRINTPRESENT', parentScreen: dataObject.parentScreen });
                    dataObject = dataObject.parentScreen.agreement;
                    this.showDownload = true;
                }
            }
            if (this.existingData) {
                dataObject = JSON.parse(JSON.stringify(this.existingData));
            }
            Utility.commonStaticObject.agreementTemplates = responses[0];
            Utility.commonStaticObject.agreementTemplateDflt = responses[0][0].agmtTemId;

            Utility.commonStaticObject.agreementTemplates.map((agreement) => {
                agreement.value = agreement.agmtTemId;
                agreement.name = agreement.temNm;
            });

            Utility.commonStaticObject.altLngs = responses[1];
            Utility.commonStaticObject.altLngsDflt = responses[1][0].langCd;

            Utility.commonStaticObject.altLngs.map((altLng) => {
                altLng.name = altLng.langNm;
                altLng.value = altLng.langCd;
            });
            if (dataObject) {
                dataObject['agreementData'] = 'true';
            } else {
                dataObject = {};
            }
            dataObject.lglNm = this.customerData.coNm;
            this.regConfig = this.commonService.buildField(AgreementScreenConfig.config, dataObject).fieldsConfig;
            this.showFields = true;

            if (!this.cdRef['destroyed']) {
                this.cdRef.detectChanges();
            }

            // TODO: need to remove this and handle from validation configuration.
            this.form.valueChanges.subscribe(val => {
                if (val && val.ctrcEndDt) {
                    this.showDownload = true;
                } else {
                    this.showDownload = false;
                }
            });

            if (this.form && this.isEdit) {
                this.setCtrEndDateMinValue({ field: { name: 'ctrcStrtDt', value: dataObject.ctrcEndDt } });
            }
        }
    }

    onClick(event) {
        if (!event || (event && !event.field)) {
            return;
        }
        this.setCtrEndDateMinValue(event);
    }

    setCtrEndDateMinValue(event) {
        if (event.field.name === 'ctrcStrtDt') {
            if (event.field.value && this.form.getRawValue().ctrcEndDt) {
                this.validateContractDates(new Date(this.form.getRawValue().ctrcStrtDt),
                    new Date(this.form.getRawValue().ctrcEndDt));
            }
            const ctrcEndDtIdx = this.regConfig.findIndex(field => field.name === 'ctrcEndDt');
            if (ctrcEndDtIdx !== -1) {
                this.regConfig[ctrcEndDtIdx].min = new Date(this.form.getRawValue().ctrcStrtDt);
            }
        }
    }

    generatePreview() {
        this.form.get('agreementData').patchValue('true');
        let url = `${Utility.urlParams.generateAgreement.url}?prpsId=${this.pKey}`;
        url += `&effectiveDate=${this.commonService.formatDateTime(this.form.get('ctrcStrtDt').value, 'DD-MMM-YYYY')}`;
        url += `&paymentTerms=${this.form.get('paymentTerms').value}`;
        window.open(url);
    }

    private validateContractDates(startDate: Date, endDate: Date = null) {
        if (startDate.getTime() > endDate.getTime()) {
            this.form.get('ctrcEndDt').reset();
        }
    }
}
