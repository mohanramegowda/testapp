/*
 * SonarQube, open source software quality management tool.
 * Copyright (C) 2008-2013 SonarSource
 * mailto:contact AT sonarsource DOT com
 *
 * SonarQube is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or (at your option) any later version.
 *
 * SonarQube is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

export class CustomerConfig {
    static config = {
        'fields': [
            {
                'name': 'ean',
                'inputType': 'text',
                'type': 'input',
                'label': 'Enterprise Account Number',
                'opco': 'both',
                'validations': []
            },
            {
                'name': 'vatNm',
                'inputType': 'text',
                'type': 'input',
                'label': 'VAT Number',
                'opco': 'both',
                'validations': [
                    {
                        'name': 'pattern',
                        'value': '^[A-Za-z 0-9]+$',
                        'message': 'VAT Number should contain only numbers and alphabets'
                    }
                ]
            },
            {
                'name': 'cmpyNm',
                'inputType': 'text',
                'type': 'input',
                'label': 'Company Name',
                'opco': 'both',
                'validations': [
                    {
                        'name': 'required',
                        'value': '',
                        'message': 'Company name is required'
                    },
                    {
                        'name': 'pattern',
                        'value': '^[^\\s].+$',
                        'message': 'Company name is invalid'
                    }
                ]
            },
            {
                'name': 'fedexContactNm',
                'inputType': 'text',
                'type': 'input',
                'utilFieldNm': 'fedexContactNm',
                'label': 'FedEx Contact Name',
                'validations': []
            },
            {
                'name': 'custContNm',
                'inputType': 'text',
                'type': 'input',
                'opco': 'both',
                'label': 'Customer Contact Name',
                'validations': [
                    {
                        'name': 'required',
                        'value': '',
                        'message': 'Customer name is required'
                    },
                    {
                        'name': 'pattern',
                        'value': '^[^\\s].+$',
                        'message': 'Customer name is invalid'
                    }
                ]
            },
            {
                'name': 'cnty',
                'inputType': 'text',
                'type': 'select',
                'label': 'Country',
                'options': [{
                    'value': '1',
                    'name': 'Netherlands'
                }, {
                    'value': '2',
                    'name': 'France'
                }, {
                    'value': '3',
                    'name': 'Belgium'
                }],
                'opco': 'both',
                'validations': []
            },
            {
                'name': 'custEmail',
                'inputType': 'text',
                'type': 'input',
                'label': 'Customer Email',
                'opco': 'both',
                'validations': [
                    {
                        'name': 'pattern',
                        'value': '^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$',
                        'message': 'Invalid Email'
                    }
                ]
            },
            {
                'name': 'contactNumber',
                'inputType': 'phone',
                'type': 'input',
                'value': '',
                'label': 'Phone Number',
                'opco': 'fedex',
                'validations': [
                    {
                        'name': 'pattern',
                        'value': '^(\\+\\d{1,2}\\s)?\\(?\\d{3}\\)?[\\s.-]?\\d{3}[\\s.-]?\\d{4}$',
                        'message': 'Invalid Phone Number'
                    }
                ]
            },
            {
                'name': 'custSegNm',
                'inputType': 'text',
                'type': 'select',
                'label': 'Customer Segment',
                'opco': 'both',
                'validations': []
            },
            {
                'name': 'hidden1',
                'inputType': 'hidden',
                'type': 'text',
                'label': '',
                'opco': 'both',
                'options': [],
                'validations': []
            }
        ]
    }
}

