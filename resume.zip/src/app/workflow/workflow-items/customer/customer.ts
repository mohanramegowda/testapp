export const GET_GENERIC_FORKJOIN = [
	[{
		"segCd": "SEG-1",
		"segNm": "SEGMENT-1",
		"crtById": 1,
		"crtDt": "04:00:2019",
		"lstMdfyById": null,
		"lstMdfyDt": null
	}, {
		"segCd": "SEG-2",
		"segNm": "SEGMENT-2",
		"crtById": 1,
		"crtDt": "04:00:2019",
		"lstMdfyById": null,
		"lstMdfyDt": null
	}],
	[{
		"ctryCd": "NL",
		"ctryNm": "NETHERLANDS",
		"langCd": "DUTCH",
		"currCd": "ÉURO",
		"segCd": "SEG_1",
		"crtById": 1,
		"lstMdfyById": null,
		"crtDt": "03:00:2019",
		"lstMdfyDt": null
	}, {
		"ctryCd": "DE",
		"ctryNm": "Germany",
		"langCd": "German",
		"currCd": "CHF",
		"segCd": "SEG_2",
		"crtById": 1,
		"lstMdfyById": null,
		"crtDt": "03:00:2019",
		"lstMdfyDt": null
	}]
]

export const FORM_ELEMENTS = [{
	"inputType": "number",
	"type": "input",
	"label": "Enterprise Account Number",
	"name": "ean",
	"styleClass": "protract-ean",
	"validations": [{
		"name": "pattern",
		"message": "Invalid Enterprise Account Number"
	}]
}, {
	"inputType": "text",
	"type": "input",
	"label": "VAT Number",
	"name": "vatNbr",
	"styleClass": "protract-vat",
	"validations": [{
		"name": "pattern",
		"message": "Invalid VAT Number"
	}]
}, {
	"inputType": "text",
	"type": "input",
	"label": "Company Name",
	"name": "coNm",
	"styleClass": "protract-company",
	"validations": [{
		"name": "required",
		"message": "Company Name is Required"
	}, {
		"name": "pattern",
		"message": "Company name is invalid"
	}]
}, {
	"inputType": "text",
	"type": "input",
	"label": "FedEx Contact Name",
	"name": "fedexConNm",
	"styleClass": "protract-fedex-contact",
	"value": "Madan Srivats",
	"validations": [{
		"name": "required",
		"message": "FedEx Contact Name is Required"
	}, {
		"name": "pattern",
		"message": "FedEx Contact name is invalid"
	}]
}, {
	"inputType": "text",
	"type": "input",
	"label": "Customer Contact Name",
	"name": "cusConNm",
	"validations": [{
		"name": "required",
		"message": "Customer Contact Name is Required"
	}, {
		"name": "pattern",
		"message": "Customer name is invalid"
	}]
}, {
	"type": "select",
	"label": "Country",
	"name": "ctryCd",
	"value": "NL",
	"options": [{
		"ctryCd": "NL",
		"ctryNm": "NETHERLANDS",
		"langCd": "DUTCH",
		"currCd": "ÉURO",
		"segCd": "SEG_1",
		"crtById": 1,
		"lstMdfyById": null,
		"crtDt": "03:00:2019",
		"lstMdfyDt": null,
		"value": "NL",
		"name": "NETHERLANDS"
	}, {
		"ctryCd": "DE",
		"ctryNm": "Germany",
		"langCd": "German",
		"currCd": "CHF",
		"segCd": "SEG_2",
		"crtById": 1,
		"lstMdfyById": null,
		"crtDt": "03:00:2019",
		"lstMdfyDt": null,
		"value": "DE",
		"name": "Germany"
	}],
	"validations": [{
		"name": "required",
		"message": "Country is Required"
	}]
}, {
	"inputType": "email",
	"type": "input",
	"label": "Customer Email",
	"name": "cusEml",
	"validations": [{
		"name": "required",
		"message": "Customer Email is Required"
	}, {
		"name": "pattern",
		"message": "Invalid Email"
	}]
}, {
	"type": "select",
	"label": "Customer Segment",
	"name": "cusSegCd",
	"value": "SEG-1",
	"options": [{
		"segCd": "SEG-1",
		"segNm": "SEGMENT-1",
		"crtById": 1,
		"crtDt": "04:00:2019",
		"lstMdfyById": null,
		"lstMdfyDt": null,
		"value": "SEG-1",
		"name": "SEGMENT-1"
	}, {
		"segCd": "SEG-2",
		"segNm": "SEGMENT-2",
		"crtById": 1,
		"crtDt": "04:00:2019",
		"lstMdfyById": null,
		"lstMdfyDt": null,
		"value": "SEG-2",
		"name": "SEGMENT-2"
	}],
	"validations": []
}]
	

export const DATA = {
	"workFlowItems": {},
	"workFlowResponses": {},
	"pKey": 527,
	"isEdit": false
}