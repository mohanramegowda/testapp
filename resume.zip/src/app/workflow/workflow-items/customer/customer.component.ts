/*
* SonarQube, open source software quality management tool.
* Copyright (C) 2008-2013 SonarSource
* mailto:contact AT sonarsource DOT com
*
* SonarQube is free software; you can redistribute it and/or
* modify it under the terms of the GNU Lesser General Public
* License as published by the Free Software Foundation; either
* version 3 of the License, or (at your option) any later version.
*
* SonarQube is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
* Lesser General Public License for more details.
*
* You should have received a copy of the GNU Lesser General Public License
* along with this program; if not, write to the Free Software Foundation,
* Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/


import {
    Component, OnInit, ViewChild, ViewContainerRef,
    ChangeDetectorRef, ComponentFactoryResolver, ComponentFactory, ComponentRef, Input,
    Output, forwardRef, ChangeDetectionStrategy
} from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { Location } from '@angular/common';
import { Observable, Subject } from 'rxjs';
import { DateAdapter, MAT_DATE_FORMATS, MatDialog, MatStepper } from '@angular/material';

import { CommonService } from '../../../common/common.service';
import { Utility } from '../../../common/Utility';
import { FormBuilder, FormGroup, FormControl, Validators, NG_VALUE_ACCESSOR } from '@angular/forms';

import { APP_DATE_FORMATS, AppDateAdapter } from '../../../common/customDatePicker';
import { startWith } from 'rxjs/operators/startWith';
import { map } from 'rxjs/operators/map';
import { FieldConfig } from '../../../components/dyn-forms/field.interface';
import { DynamicFormComponent } from 'app/components/dyn-forms/dynamic-form/dynamic-form.component';
import { CustomerScreenConfig } from './customer-screenconfig';


@Component({
    changeDetection: ChangeDetectionStrategy.Default,
    selector: 'app-customer',
    templateUrl: './customer.component.html',
    styleUrls: ['./customer.component.scss'],
    providers: [
        {
            provide: NG_VALUE_ACCESSOR,
            useExisting: forwardRef(() => CustomerComponent),
            multi: true
        },
        {
            provide: DateAdapter, useClass: AppDateAdapter
        },
        {
            provide: MAT_DATE_FORMATS, useValue: APP_DATE_FORMATS
        }]
})

export class CustomerComponent implements OnInit {

    customerData = {};

    @ViewChild(DynamicFormComponent, { static: false }) dynForm: DynamicFormComponent;

    regConfig: any;
    disabled: boolean;
    customereInfoControl: FormControl;
    wfScrCfg = JSON.parse(JSON.stringify(CustomerScreenConfig.config));
    showFields = false;
    isEdit = false;
    form: FormGroup;
    pKey = '';
    data: any;
    currentModuleName: any;
    existingData: any;

    constructor(private commonService: CommonService) { }

    ngOnInit() {
        this.pKey = this.data.pKey;
        this.isEdit = this.data.isEdit;
        if (this.data.workFlowItems && this.data.workFlowItems.CUSTOMERMODULE
            && this.data.workFlowItems.CUSTOMERMODULE) {
            this.existingData = this.data.workFlowItems.CUSTOMERMODULE;
            this.showFields = false;
            this.processData([Utility.commonStaticObject.segment, Utility.commonStaticObject.cnty]);
            return;
        }
        this.showFields = false;
        this.getScreenConfigs();
    }

    getScreenConfigs() {
        const request: any = {
            'type': 'ALL'
        };
        const reqArr = [
            {
                url: Utility.urlParams.customerSegment.url, param: request,
                type: Utility.urlParams.customerSegment.type
            },
            ,
            {
                url: Utility.urlParams.countryList.url, param: request,
                type: Utility.urlParams.countryList.type
            }];
        if (!this.existingData && this.isEdit) {
            const req = {
                url: `${Utility.urlParams.wfGetStep.url}/${this.currentModuleName}/${this.pKey}`, param: null,
                type: Utility.urlParams.wfGetStep.type
            }
            reqArr.push(req);
        }
        this.commonService.getGenericForkJoin(reqArr).subscribe((responses: any) => {
            this.processData(responses);
        });
    }

    processData(responses) {
        let dataObject = null;
        if (this.existingData) {
            dataObject = JSON.parse(JSON.stringify(this.existingData));
        } else if (this.isEdit && responses[2]) {
            dataObject = responses[2];
            if (dataObject && dataObject.parentScreen && dataObject.parentScreen.customer) {
                $(document).trigger('wf-store-response',
                    {
                        moduleName: 'CUSTOMERMODULE', parentScreen: dataObject.parentScreen,
                        workflowRequest: dataObject.workflowRequest
                    });
                dataObject = dataObject.parentScreen.customer;
            }
        }
        Utility.commonStaticObject.fullName = Utility.userDetails.fullName;
        Utility.commonStaticObject.segment = responses[0];
        Utility.commonStaticObject.segment.map((segment) => {
            segment.value = segment.segCd;
            segment.name = segment.segNm;
        });
        Utility.commonStaticObject.segmentDefault = dataObject ? dataObject.cusSegCd : responses[0][0].value;

        Utility.commonStaticObject.cnty = responses[1];
        Utility.commonStaticObject.cnty.map((cnty) => {
            cnty.value = cnty.ctryCd;
            cnty.name = cnty.ctryNm;
        });
        Utility.commonStaticObject.cntyDefault = dataObject ? dataObject.ctryCd : responses[1][0].value;

        this.regConfig = this.commonService.buildField(CustomerScreenConfig.config, dataObject || null);
        this.regConfig = this.regConfig.fieldsConfig;
        this.showFields = true;
    }
}
