export class CustomerScreenConfig {
    static config = {
        fields: [
            {
                name: 'ean',
                inputType: 'number',
                type: 'input',
                label: 'Enterprise Account Number',
                styleClass: 'protract-ean',
                styleId: 'protract-ean',
                opco: 'both',
                validations: [{
                    name: 'pattern',
                    value: '^[0-9]+$',
                    message: 'Invalid Enterprise Account Number'
                }]
            },
            {
                name: 'vatNbr',
                inputType: 'text',
                type: 'input',
                label: 'VAT Number',
                opco: 'both',
                styleClass: 'protract-vat',
                styleId: 'protract-vat',
                validations: [{
                    name: 'pattern',
                    value: '^[a-zA-z0-9]+$',
                    message: 'Invalid VAT Number'
                }]
            },
            {
                name: 'coNm',
                inputType: 'text',
                type: 'input',
                label: 'Company Name',
                styleClass: 'protract-company',
                styleId: 'protract-company',
                opco: 'both',
                validations: [{
                    name: 'required',
                    value: '',
                    message: 'Company Name is Required'
                },
                {
                    name: 'pattern',
                    value: '^[^\\s].+$',
                    message: 'Company name is invalid'
                }]
            },
            {
                name: 'fedexConNm',
                inputType: 'text',
                type: 'input',
                label: 'FedEx Contact Name',
                styleClass: 'protract-fedex-contact',
                styleId: 'protract-fedex-contact',
                defaultValueRef: 'fullName',
                utilFieldNm: 'fullName',
                opco: 'both',
                validations: [{
                    name: 'required',
                    value: '',
                    message: 'FedEx Contact Name is Required'
                },
                {
                    name: 'pattern',
                    value: '^[^\\s].+$',
                    message: 'FedEx Contact name is invalid'
                }]
            },
            {
                name: 'cusConNm',
                inputType: 'text',
                type: 'input',
                label: 'Customer Contact Name',
                styleId: 'protract-contact',
                opco: 'both',
                validations: [
                    {
                        name: 'required',
                        value: '',
                        message: 'Customer Contact Name is Required'
                    },
                    {
                        name: 'pattern',
                        value: '^[^\\s].+$',
                        message: 'Customer name is invalid'
                    }
                ]
            },
            {
                name: 'ctryCd',
                type: 'select',
                label: 'Country',
                utilFieldNm: 'cnty',
                defaultValueRef: 'cntyDefault',
                styleId: 'protract-country',
                opco: 'both',
                value: '1',
                options: [
                    {
                        'value': '1',
                        'name': 'Netherlands'
                    },
                    {
                        'value': '2',
                        'name': 'France'
                    },
                    {
                        'value': '3',
                        'name': 'Belgium'
                    }
                ],
                validations: [
                    {
                        name: 'required',
                        value: '',
                        message: 'Country is Required'
                    }
                ]
            },
            {
                name: 'cusEml',
                inputType: 'email',
                type: 'input',
                label: 'Customer Email',
                styleId: 'protract-email',
                opco: 'both',
                validations: [
                    {
                        name: 'required',
                        value: '',
                        message: 'Customer Email is Required'
                    },
                    {
                        name: 'pattern',
                        value: '^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$',
                        message: 'Invalid Email'
                    }
                ]
            },
            {
                name: 'cusSegCd',
                type: 'select',
                label: 'Customer Segment',
                utilFieldNm: 'segment',
                styleId: 'protract-segment',
                defaultValueRef: 'segmentDefault',
                opco: 'both',
                value: '1',
                options: [
                    {
                        'value': '1',
                        'name': 'Segment 1'
                    },
                    {
                        'value': '2',
                        'name': 'Segment 2'
                    },
                    {
                        'value': '3',
                        'name': 'Segment 3'
                    }
                ],
                validations: []
            }
        ]
    }
}
