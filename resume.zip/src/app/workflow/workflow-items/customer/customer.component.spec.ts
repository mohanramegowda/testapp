import { ComponentFixture, async, TestBed } from "@angular/core/testing";
import { RouterTestingModule } from "@angular/router/testing";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { HttpClientTestingModule } from "@angular/common/http/testing";

import { MaterialModule } from "app/components/material.module";
import { DynFormModule } from "app/components/dyn-forms/dyn-forms.module";

import { CustomerComponent } from "./customer.component";
import { DynamicFormComponent } from "app/components/dyn-forms/dynamic-form/dynamic-form.component";

import { CommonService } from "app/common/common.service";

import { Observable } from "rxjs/Observable";
import { FORM_ELEMENTS, GET_GENERIC_FORKJOIN, DATA } from "./customer";

const MockCommonService = {
  // getGenericForkJoin: jasmine.createSpy('getGenericForkJoin').and.returnValue({subscribe: () => {}}),
  buildField: jasmine.createSpy('buildField').and.returnValue(FORM_ELEMENTS)
}

// class MockCommonService {
//   getGenericForkJoin(): Observable<any> {
//     return Observable.of(GET_GENERIC_FORKJOIN)
//   };
//   buildField() {
//     return FORM_ELEMENTS;
//   };
// }

describe('CustomerComponent', () => {
  let component: CustomerComponent;
  let fixture: ComponentFixture<CustomerComponent>;

  let commonService: CommonService;

  let dynFormComponent: DynamicFormComponent;
  let dynFormFixture: ComponentFixture<DynamicFormComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        CustomerComponent
      ],
      imports: [
        HttpClientTestingModule,
        RouterTestingModule,
        FormsModule,
        ReactiveFormsModule,
        MaterialModule,
        DynFormModule,
      ],
      providers: [
        {provide: CommonService, useValue: MockCommonService}
      ]
    }).compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CustomerComponent);
    component = fixture.componentInstance;

    dynFormFixture = TestBed.createComponent(DynamicFormComponent);
    dynFormComponent = dynFormFixture.componentInstance;

    commonService = TestBed.get(CommonService);
    // spyOn(commonService, 'getGenericForkJoin').and.callThrough();
    // spyOn(commonService, 'buildField').and.callThrough();

    fixture.detectChanges();
    dynFormFixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();

    // component.ngOnInit();
    component.showFields = false;
    
    component.regConfig = FORM_ELEMENTS;
    dynFormComponent.fields = component.regConfig;

    component.pKey = String(DATA.pKey);
    component.isEdit = DATA.isEdit;
    component.showFields = true;
    fixture.detectChanges();

    expect(dynFormComponent).toBeTruthy();
    dynFormComponent.ngOnInit();
    dynFormFixture.detectChanges();
  });

});