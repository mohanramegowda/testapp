/*
* SonarQube, open source software quality management tool.
* Copyright (C) 2008-2013 SonarSource
* mailto:contact AT sonarsource DOT com
*
* SonarQube is free software; you can redistribute it and/or
* modify it under the terms of the GNU Lesser General Public
* License as published by the Free Software Foundation; either
* version 3 of the License, or (at your option) any later version.
*
* SonarQube is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
* Lesser General Public License for more details.
*
* You should have received a copy of the GNU Lesser General Public License
* along with this program; if not, write to the Free Software Foundation,
* Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/


import {
    Component, OnInit, ViewChild, ViewContainerRef,
    ChangeDetectorRef, ComponentFactoryResolver, ComponentFactory, ComponentRef, Input, Output, AfterViewInit, AfterContentInit
} from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { Location } from '@angular/common';
import { Observable, Subject } from 'rxjs';
import { DateAdapter, MAT_DATE_FORMATS, MatDialog, MatStepper } from '@angular/material';

import { CommonService } from '../common/common.service';
import { Utility } from '../common/Utility';
import { FormBuilder, FormGroup, FormControl } from '@angular/forms';

import { APP_DATE_FORMATS, AppDateAdapter } from '../common/customDatePicker';
import { WorkFlowService } from './workflow.service';
import { startWith } from 'rxjs/operators/startWith';
import { map } from 'rxjs/operators/map';

class WorkFlowComm {
    isEdit: boolean;
    workFlowResponses: any;
    workFlowItems: any;
    pKey: string;
}

@Component({
    selector: 'app-workflow',
    templateUrl: './workflow.component.html',
    styleUrls: ['./workflow.component.scss'],
    providers: [
        {
            provide: DateAdapter, useClass: AppDateAdapter
        },
        {
            provide: MAT_DATE_FORMATS, useValue: APP_DATE_FORMATS
        }]
})

export class WorkFlowComponent implements OnInit {

    @ViewChild('saveAlert', { static: false })
    saveAlert: ViewContainerRef;

    @ViewChild('notAllowed', { static: false })
    notAllowed: ViewContainerRef;

    dialogRef: any;
    dialogData: any;
    stepNo = 0;
    noSteps = 1;
    mode = 'create';
    breadCrumbsData: any;
    isActivated = false;
    showNext = false;
    showPrev = false;
    workFlowItems: any;
    pKey = '';
    isEdit = false;
    workflowRequest: any;
    workFlowData = {};
    workFlowComm: WorkFlowComm;
    workFlowScreenNames = {
        CUSTOMERMODULE: 'Customer Information',
        PRICINGMODULE: 'Pricing Profile',
        AGREEMENTMODULE: 'Agreement Module',
        PRINTPRESENT: 'Print Present Module',
    }
    constructor(private dialog: MatDialog, private commonService: CommonService,
        private route: ActivatedRoute,
        private router: Router, private workflowService: WorkFlowService,
        private location: Location) {
        this.workflowService.workFlowComponent = this;
    }

    ngOnInit() {
        this.workFlowItems = {}

        this.route.params.subscribe(params => {
            this.isActivated = false;
            if (params.prNumber) {
                this.isEdit = true;
                this.pKey = params.prNumber;
            } else {
                this.isEdit = false;
            }
            this.activate();
            // TODO: uncomment once status check is required for routing

            // if (this.isEdit) {
            //     this.workflowService.isEditAllowed().then((isAllowed) => {
            //         if (isAllowed) {
            //             this.activate()
            //         } else {
            //             this.openModal(this.notAllowed, {});
            //         }
            //     })
            // } else {
            //     this.activate();
            // }
        });
    }

    activate() {
        /*  1. Breadcrumbs
            2. Render Engine Micro Frontend
        */
        this.breadCrumbsData = [];
        this.mode = this.isEdit ? 'update' : 'create';
        this.commonService.getAPIResponse(Utility.urlParams.breadCrumbs.url, {},
            Utility.urlParams.breadCrumbs.type).subscribe((response: any) => {
                this.breadCrumbsData = response;
                this.noSteps = this.breadCrumbsData.length;
                this.canShowPrevNextWf();
                this.initiateWorkFlow();
            });
        $(document).on('wf-store-response', (event, data) => {
            if (data && data.moduleName) {
                this.workFlowComm.workFlowResponses[data.moduleName] = data.parentScreen;
            }
            if (data && data.workflowRequest) {
                this.workflowRequest = data.workflowRequest;
            }
        });

        $(document).on('wf-complete', (event, data) => {
            this.navigateToActivity();
        });
    }

    selectionChange(event, isSubmit = false) {
        if (!isSubmit && (!event || this.stepNo > event.selectedIndex)) {
            this.stepNo = event.selectedIndex;
            this.canShowPrevNextWf();
            return;
        }
        const moduleName = this.breadCrumbsData[this.stepNo].screenName;
        if (this.workFlowComm.workFlowResponses[moduleName]) {
            const prevModule = moduleName;
            this.updateWorkFlow(true, prevModule, isSubmit);
            if (event) {
                this.stepNo = event.selectedIndex;
            }
            this.canShowPrevNextWf();
            return;
        }

        const urlParam = Utility.urlParams.wfSaveStage;
        const req: any = {
            parentScreen: {},
            prpsId: this.pKey,
            workflowRequest: this.workflowRequest || {}
        };
        req.workflowRequest.prpsId = this.pKey;
        req.parentScreen[this.breadCrumbsData[this.stepNo].formName]
            = this.workFlowItems[moduleName].getRawValue();
        // TODO: need to decouple the dependency on Workflow items
        if (moduleName === 'PRICINGMODULE') {
            req.parentScreen['pricing'] = req.parentScreen.pricing.discountData ?
                req.parentScreen.pricing.discountData
                : undefined;
        }
        if (moduleName === 'AGREEMENTMODULE') {
            delete req.parentScreen.agreement.agreementData;
        }
        if (moduleName === 'PRINTPRESENT') {
            const agmtOptCd = req.parentScreen[this.breadCrumbsData[this.stepNo].formName].agmtOptCd;
            req.parentScreen[this.breadCrumbsData[this.stepNo].formName] = { agmtOptCd: agmtOptCd };
        }
        this.workFlowComm.workFlowItems[moduleName] = this.workFlowItems[moduleName].getRawValue();
        this.workFlowItems[moduleName].valueChanges.complete();
        if (event) {
            this.stepNo = event.selectedIndex;
        }
        this.commonService.getAPIResponse(Utility.urlParams.wfSaveStage.url, req, urlParam.type).subscribe((response: any) => {
            if (!response) {
                this.canShowPrevNextWf();
                return;
            }
            this.workflowRequest = response.workflowRequest;
            if (!this.workFlowComm.workFlowResponses) {
                this.workFlowComm.workFlowResponses = {};
            }
            this.workFlowComm.workFlowResponses[moduleName] = response.parentScreen;
            if (isSubmit) {
                this.commonService.showNotifier('Workflow Submitted Successfully', 'success');
                this.mode = 'update';
                this.navigateToActivity();
            }
            this.canShowPrevNextWf();
        }, (error) => {
            console.error(error);
            this.canShowPrevNextWf();
        });
    }

    getForm(moduleName) {
        if (!this.workFlowItems[moduleName]) {
            this.workFlowItems[moduleName] = new FormGroup({});
        }
        return this.workFlowItems[moduleName];
    }

    canShowPrevNextWf() {
        this.showNext = true;
        this.showPrev = true;
        if (this.stepNo === 0) {
            this.showPrev = false;
        }
        if (this.stepNo === (this.noSteps - 1)) {
            this.showNext = false;
        }
    }

    openModal(templateRef, data = null) {
        this.dialogData = data;
        this.dialogRef = this.dialog.open(templateRef, {});
        this.dialogRef.afterClosed().subscribe(result => {
            this.dialogData = null;
        });
    }

    closeModal(val = null) {
        this.dialogRef.close(val);
    }

    initiateWorkFlow() {
        if (!this.isEdit) {
            this.commonService.getAPIResponse(Utility.urlParams.wfInitiate.url,
                { workflowRequest: { 'wflAppId': '1', 'wflReqCrteById': Utility.userDetails.userId } },
                Utility.urlParams.wfInitiate.type).subscribe((response: any) => {
                    this.workflowRequest = response.workflowRequest;
                    this.pKey = response.prpsId;
                    this.populateWorkFlowComm();
                    this.isActivated = true;
                });
        } else {
            this.populateWorkFlowComm();
            this.isActivated = true;
        }
    }

    updateWorkFlow(shouldUpdate = false, prevModule = '', isConfirm = false) {
        if (!prevModule) {
            return false;
        }
        const request: any = {
            parentScreen: {}
        }
        const prevStep = this.stepNo;
        const formName = this.breadCrumbsData[prevStep].formName;
        const endPointName = this.breadCrumbsData[prevStep].currentModuleName;
        request.parentScreen[formName]
            = this.workFlowItems[prevModule].getRawValue();
        if (prevModule === 'PRICINGMODULE') {
            request.parentScreen[formName] = (request.parentScreen.discountData) ? request.parentScreen.discountData
                : request.parentScreen.pricing.discountData;
        }
        if (prevModule === 'AGREEMENTMODULE') {
            delete request.parentScreen.agreement.agreementData;
        }
        if (prevModule === 'PRINTPRESENT') {
            const agmtOptCd = request.parentScreen[formName].agmtOptCd;
            request.parentScreen[formName] = { agmtOptCd: agmtOptCd };
        }

        if (shouldUpdate) {
            this.workFlowComm.workFlowItems[prevModule] = this.workFlowItems[prevModule].getRawValue();
            this.commonService.getAPIResponse(
                `${Utility.urlParams.wfUpdateStep.url}/${endPointName}/${this.pKey}`, request,
                Utility.urlParams.wfUpdateStep.type).subscribe((response: any) => {
                    if (!response) {
                        this.canShowPrevNextWf();
                        return;
                    }
                    if (response && response.parentScreen) {
                        this.workFlowComm.workFlowResponses[prevModule] = response.parentScreen;
                    }
                    // this.workFlowComm.workFlowResponses[prevModule] = this.workFlowItems[prevModule].getRawValue();
                });
            if (isConfirm) {
                this.commonService.showNotifier('Workflow Updated Successfully', 'success');
                this.navigateToActivity();
            }
        }
    }

    navigateToActivity() {
        Utility.forcedRoute = true;
        this.router.navigate(['/activity']);
    }

    closeAndNavigate() {
        this.closeModal();
        this.navigateToActivity();
    }

    populateWorkFlowComm() {
        this.workFlowComm = new WorkFlowComm();
        this.workFlowComm.workFlowItems = {};
        this.workFlowComm.workFlowResponses = {};
        this.workFlowComm.pKey = this.pKey;
        this.workFlowComm.isEdit = this.isEdit;
    }
}
