
/*
 * SonarQube, open source software quality management tool.
 * Copyright (C) 2008-2013 SonarSource
 * mailto:contact AT sonarsource DOT com
 *
 * SonarQube is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or (at your option) any later version.
 *
 * SonarQube is distributed in the hope that it will be useful, * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */


import { TestBed, async, fakeAsync, tick, ComponentFixture } from '@angular/core/testing';
import { Utility } from './common/Utility';
import { AppComponent } from './app.component';
import { HttpClientTestingModule } from '@angular/common/http/testing';
// import { Idle, DEFAULT_INTERRUPTSOURCES } from '@ng-idle/core';
// import { NgIdleKeepaliveModule } from '@ng-idle/keepalive';
// import { Keepalive } from '@ng-idle/keepalive';

import { RouterTestingModule } from '@angular/router/testing';
import { CommonService } from '../app/common/common.service';
import { Observable, Observer, of } from 'rxjs';
import { TranslateModule } from '@ngx-translate/core';

describe('AppComponent', () => {
  let component: AppComponent;
  let fixture: ComponentFixture<AppComponent>;
  let commonService: CommonService;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [
        AppComponent
      ],
      providers: [
        CommonService,
      ],
      imports: [
        RouterTestingModule,
        HttpClientTestingModule,
        TranslateModule.forRoot()
      ]
    }).compileComponents();
    commonService = TestBed.get(CommonService);
    jasmine.DEFAULT_TIMEOUT_INTERVAL = 10000;
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AppComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create the app', () => {
    expect(component).toBeTruthy();
  });

  // it(`should login`, (() => {
  //   const loggedinResponse = {
  //     'userId': '5164632',
  //     'userFirstName': 'Arun',
  //     'userLastName': 'Bijapur',
  //     'countryCode': 'NL',
  //     'userEmail': 'arun.bijapur.osv@fedex.com',
  //     'authroizes': {
  //         'PROUD-CreateProposal,PROUD-Login': true,
  //         'PROUD-CreateProposal,PROUD-View': true,
  //         'PROUD-PricingTemplate,PROUD-View': false,
  //         'PROUD-ActivityView,PROUD-View': true,
  //         'PROUD-CreateProposal,PROUD-Create': true
  //     },
  //     'roleNm': [
  //         'PROUD-SalesAE',
  //         'PROUD-ProposalRequestor'
  //     ],
  //     'accessibleCountries': null
  // }

  //   spyOn(commonService, 'getHttpLoginResponse').and.returnValue(of(loggedinResponse));
  //   component.getLoginDetails();
  //   expect(component.activate).toBe(true);
  //   expect(Utility.userDetails).toBe(loggedinResponse);

  //   // commonService.getHttpLoginResponse(OttUtility.urlParams.wssoLoginHdr.url).subscribe((res: any) => {
  //   //   console.log(OttUtility.userDetails)
  //   //   fixture.detectChanges();
  //   //   expect(OttUtility.userDetails.userId).toBe('146381');
  //   //   expect(res.userId).toBe('3756661');

  //   // });

  //   // tick();
  // }))
});
