import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TableListComponent } from './table-list.component';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { TableListRoutesModule } from './table-list.routing';
import { ComponentsModule } from 'app/components/components.module';
import { TableListDetailModule } from './table-list-detail/table-list-detail.module';
import { ListComponent } from './list/list.component';
import { DynamicFilterComponent } from './dynamic-filter/dynamic-filter.component';
import { TableListService } from './table-list.service';
import { DynamicFilterService } from './dynamic-filter/dynamic-filter.service';
import { CommonService } from 'app/common/common.service';
import { HttpClientModule } from '@angular/common/http';
import { RouterModule, ActivatedRoute, Params } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { Subject } from 'rxjs';

describe('TableListComponent', () => {
  let component: TableListComponent;
  let fixture: ComponentFixture<TableListComponent>;
  // tslint:disable-next-line: prefer-const
  let params: Subject<Params>;
  const methods: any = {
    populateDynamicEventsMethod: null,
  }

  beforeEach(async(() => {
    params = new Subject<Params>();
    TestBed.configureTestingModule({
      imports: [
        BrowserAnimationsModule,
        HttpClientModule,
        RouterTestingModule,
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        TableListRoutesModule,
        ComponentsModule,
        TableListDetailModule
      ],
      declarations: [
        TableListComponent,
        ListComponent,
        DynamicFilterComponent,
        ListComponent
      ],
      providers: [
        CommonService,
        TableListService,
        DynamicFilterService,
        { provide: ActivatedRoute, useValue: { params: params } }
      ],
    })
      .compileComponents();
  }), 30000);

  beforeEach(() => {
    fixture = TestBed.createComponent(TableListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
    params.next({ 'profileConfig': 'PRC' });
    methods.populateDynamicEventsMethod = spyOn(component, 'populateDynamicEvents');
    methods.processTableHeaders = spyOn(component, 'processTableHeaders');
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });

  it('should populate have screen Config', () => {
    expect(component.title).toBeTruthy();
  });

  it('should populate have screen Config', () => {
    expect(component.subTitle).toBeTruthy();
  });

  it('should populate have screen Config', () => {
    component.populateDynamicEvents();
    expect(methods.populateDynamicEventsMethod).toHaveBeenCalled();
  });

  it('should call Process Table Headers', () => {
    component.processTableHeaders(null);
    expect(methods.processTableHeaders).toHaveBeenCalled();
  });

  it('should contain resultSubscription', () => {
    expect(component.resultSubscription).toBeTruthy();
  });

  it('should contain resultSubscription', () => {
    expect(component.resultSubscription).toBeTruthy();
  });
});
