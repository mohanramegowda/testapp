/*
 * SonarQube, open source software quality management tool.
 * Copyright (C) 2008-2013 SonarSource
 * mailto:contact AT sonarsource DOT com
 *
 * SonarQube is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or (at your option) any later version.
 *
 * SonarQube is distributed in the hope that it will be useful, * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TableListDetailComponent } from '../table-list-detail/table-list-detail.component';
import { Utility } from '../../common/Utility';
import { Observable } from 'rxjs';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientModule } from '@angular/common/http';
import { RouterTestingModule } from '@angular/router/testing';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { TableListRoutesModule } from '../table-list.routing';
import { ComponentsModule } from 'app/components/components.module';
import { TableListDetailModule } from './table-list-detail.module';
import { TableListComponent } from '../table-list.component';
import { ListComponent } from '../list/list.component';
import { DynamicFilterComponent } from '../dynamic-filter/dynamic-filter.component';
import { CommonService } from 'app/common/common.service';
import { TableListService } from '../table-list.service';
import { DynamicFilterService } from '../dynamic-filter/dynamic-filter.service';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material/dialog';

const response = new Observable(observer => {
    observer.next(Utility.urlParams);
});


describe('TableListDetailComponent', () => {
    let component: TableListDetailComponent;
    let fixture: ComponentFixture<TableListDetailComponent>;

    beforeEach(async(() => {
        TestBed.configureTestingModule({
            imports: [
                BrowserAnimationsModule,
                HttpClientModule,
                RouterTestingModule,
                CommonModule,
                FormsModule,
                ReactiveFormsModule,
                TableListRoutesModule,
                ComponentsModule,
                TableListDetailModule
            ],
            declarations: [
                TableListComponent,
                ListComponent,
                DynamicFilterComponent,
            ],
            providers: [
                CommonService,
                TableListService,
                DynamicFilterService,
                { provide: MAT_DIALOG_DATA, useValue: {} },
                { provide: MatDialogRef, useValue: {} }
            ],
        })
            .compileComponents();
    }), 30000);

    beforeEach(() => {
        fixture = TestBed.createComponent(TableListDetailComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
        spyOn(component, 'buildField');

    });

    it('should create the app', () => {
        expect(component).toBeTruthy();
    });
});
