/*
 * SonarQube, open source software quality management tool.
 * Copyright (C) 2008-2013 SonarSource
 * mailto:contact AT sonarsource DOT com
 *
 * SonarQube is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or (at your option) any later version.
 *
 * SonarQube is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */


import { Component, OnInit, ViewChild, Inject, Output, EventEmitter } from '@angular/core';

import { FormBuilder, Validator, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef, DateAdapter, MAT_DATE_FORMATS } from '@angular/material';
import { Utility } from '../../common/Utility';
import { CommonService } from '../../common/common.service';
import { DynamicFormComponent } from '../../components/dyn-forms/dynamic-form/dynamic-form.component';
import { FieldConfig } from '../../components/dyn-forms/field.interface';
import { AppDateAdapter, APP_DATE_FORMATS } from 'app/common/customDatePicker';

@Component({
    selector: 'app-table-list-detail',
    templateUrl: './table-list-detail.component.html',
    styleUrls: ['./table-list-detail.component.scss'],
    providers: [
        {
            provide: DateAdapter, useClass: AppDateAdapter
        },
        {
            provide: MAT_DATE_FORMATS, useValue: APP_DATE_FORMATS
        }]
})
export class TableListDetailComponent implements OnInit {
    static id = 0;
    static modalType = '';
    static configuration: any;
    static existingData: any;

    mode: any = 'create';
    config: any;
    data: any;

    @Output() onSubmit = new EventEmitter<any>();
    @ViewChild(DynamicFormComponent, { static: false }) form: DynamicFormComponent;
    fieldConfigMap: any = {};
    currentFormTitle = '';
    regConfig: FieldConfig[] = [];

    constructor(@Inject(MAT_DIALOG_DATA) public defaults: any,
        private dialogRef: MatDialogRef<TableListDetailComponent>,
        private fb: FormBuilder, private commonService: CommonService) {
    }

    ngOnInit() {
        this.mode = TableListDetailComponent.modalType;
        this.config = { form: [TableListDetailComponent.configuration] };
        this.data = TableListDetailComponent.existingData;
        if (TableListDetailComponent && TableListDetailComponent.configuration
            && TableListDetailComponent.configuration.form_name) {
            this.buildField();
            this.initializeFormView(TableListDetailComponent.configuration.form_name);
        }
    }

    initializeFormView(form_name) {
        if (this.fieldConfigMap[form_name]) {
            const form = this.fieldConfigMap[form_name];
            this.currentFormTitle = form.title;
            this.regConfig = form.fieldsConfig;
        }
    }

    buildField(frmCnfg = null) {
        if (this.config) {
            const configs: any = JSON.parse(JSON.stringify(this.config));
            if (configs.form) {
                const form = configs.form;
                this.fieldConfigMap = {};
                form.map((config) => {
                    // let formConfig: FormConfig;
                    if (!config) {
                        config = {};
                    }
                    const formConfigObj: any = {};
                    formConfigObj.title = config.name;
                    formConfigObj.form_name = config.form_name;
                    formConfigObj.entity = config.entity;
                    formConfigObj.submitUrl = config.submitUrl;
                    const fieldConfigs: FieldConfig[] = [];

                    if (config.fields) {
                        config.fields.map((field) => {
                            let elementConfig: FieldConfig;
                            const elementObj: any = {};
                            elementObj.inputType = field.inputType;
                            elementObj.type = field.type;
                            elementObj.label = field.label;
                            elementObj.name = field.name;
                            elementObj.styleClass = field.styleClass;
                            elementObj.styleColor = field.styleColor;
                            elementObj.multiSelect = field.multiSelect;
                            elementObj.disabled = field.disabled;
                            if (field.value) {
                                elementObj.value = field.value;
                            }
                            if (field.options) {
                                elementObj.options = field.options;
                            }
                            if (field.utilFieldNm) {
                                if (field.type === 'select') {
                                    elementObj.options = Utility.commonStaticObject[field.utilFieldNm];
                                }
                                if (field.defaultValueRef) {
                                    elementObj.value = Utility.commonStaticObject[field.defaultValueRef];
                                }
                            }
                            if (field.validations) {
                                let validator: Validator[];
                                const validatorArr = [];
                                field.validations.map((validation) => {
                                    const validatorObj: any = {};
                                    if (validation.name === 'required') {
                                        validatorObj.name = validation.name;
                                        validatorObj.validator = Validators.required;
                                        validatorObj.message = validation.message;
                                    } else if (validation.name === 'pattern') {
                                        validatorObj.name = validation.name;
                                        validatorObj.validator = Validators.pattern(validation.validator);
                                        validatorObj.message = validation.message;
                                    }

                                    validatorArr.push(validatorObj);
                                });
                                validator = validatorArr;
                                elementObj.validations = validator;
                            }
                            elementConfig = elementObj;
                            fieldConfigs.push(elementConfig);
                        });
                    }
                    formConfigObj.fieldsConfig = fieldConfigs;
                    this.fieldConfigMap[formConfigObj.form_name] = formConfigObj;
                });
            }
        }
    }

    submit(value: any) {
        this.onSubmit.emit(value);
    }

    closeModal() {
        this.dialogRef.close(null);
    }

    save() {
        if (this.mode === 'create') {
            this.createCustomer();
        } else if (this.mode === 'update') {
            this.updateCustomer();
        }
    }


    createCustomer() {
        const customer = this.form.value;
        this.dialogRef.close(customer);
    }

    updateCustomer() {
        const customer = this.form.value;
        customer.id = this.defaults.id;
        this.dialogRef.close(customer);
    }

    cancelModal() {
        this.dialogRef.close(null);
    }

    isCreateMode() {
        return this.mode === 'create';
    }

    isUpdateMode() {
        return this.mode === 'update';
    }
}
