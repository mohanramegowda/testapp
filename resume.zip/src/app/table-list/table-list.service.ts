/*
 * SonarQube, open source software quality management tool.
 * Copyright (C) 2008-2013 SonarSource
 * mailto:contact AT sonarsource DOT com
 *
 * SonarQube is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or (at your option) any later version.
 *
 * SonarQube is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */


import { Injectable } from '@angular/core';
import { Utility } from 'app/common/Utility';
import { CommonService } from 'app/common/common.service';
declare var $: any;
@Injectable()
export class TableListService {
    currentTableData = [];
    eventConfigObject = {
        'TTS': {
            'init': '',
            'get': (payload) => {
                if (payload && payload.component) {
                    if (payload.getResponse) {
                        payload.getResponse.map(function (response) {
                            if (response.TRF_TYP_ID_NBR === 1) {
                                response.TRF_TYP = 'Standard Tariff';
                            } else if (response.TRF_TYP_ID_NBR === 2) {
                                response.TRF_TYP = 'Fast Track Tariff';
                            } else if (response.TRF_TYP_ID_NBR === 3) {
                                response.TRF_TYP = 'Personalised Tariff';
                            }
                            if (response.REV_TYP_NM === 'D') {
                                response.REV_TYP = 'Domestic';
                            } else {
                                response.REV_TYP = 'International';
                            } response.countryCode = response.CTRY_CD_NM;
                        });
                    }
                } return payload.getResponse;
            },
            'add': (payload) => {
                const arr = [];
                if (payload && payload.component) {
                    let revTypeStr = 'international'; if (payload.createData.premiumType === 'D') {
                        revTypeStr = 'domestic';
                    }
                    const thresholdObj = {
                        trfTypRevIdNbr: null,
                        trfTypIdNbr: parseInt(payload.createData.trfTypIdNbr, 0),
                        effectiveDate: payload.component.gridChangeFormat(payload.createData.effectiveDate),
                        countryCode: payload.createData.countryCode,
                        loggedInUserId: payload.utility.userDetails.userId,
                        threshHoldDetail: {
                            tariffTypeid: parseInt(payload.createData.trfTypIdNbr, 0),
                            premiumType: payload.createData.premiumType
                        }
                    }; thresholdObj.threshHoldDetail[revTypeStr] = {
                        entryPoint: parseFloat(payload.createData.entryPoint),
                        exitPoint: parseFloat(payload.createData.exitPoint)
                    }; arr.push(thresholdObj);
                } return arr;
            },
            'update': (payload) => {
                const arr = [];
                if (payload && payload.component) {
                    if (payload.updateArr) {
                        payload.updateArr.map(function (updateObj) {
                            let tariffTypeId = 1, revTypeChr = 'I', revTypeStr = 'international';
                            if (updateObj.TRF_TYP === 'Standard Tariff') {
                                tariffTypeId = 1;
                            } else if (updateObj.TRF_TYP === 'Fast Track Tariff') {
                                tariffTypeId = 2;
                            } else if (updateObj.TRF_TYP === 'Personalised Tariff') {
                                tariffTypeId = 3;
                            }
                            if (updateObj.REV_TYP === 'Domestic') {
                                revTypeChr = 'D';
                                revTypeStr = 'domestic';
                            }
                            const thresholdObj = {
                                trfTypRevIdNbr: updateObj.TRF_TYP_REV_ID_NBR,
                                trfTypIdNbr: tariffTypeId,
                                effectiveDate: payload.component.gridChangeFormat(updateObj.EFF_DT),
                                countryCode: updateObj.countryCode,
                                loggedInUserId: payload.utility.userDetails.userId,
                                threshHoldDetail: {
                                    tariffTypeid: tariffTypeId,
                                    premiumType: revTypeChr
                                }
                            }; thresholdObj.threshHoldDetail[revTypeStr] = {
                                entryPoint: parseFloat(updateObj.MIN_TRF_REV_AMT),
                                exitPoint: parseFloat(updateObj.MAX_TRF_REV_AMT)
                            }; arr.push(thresholdObj);
                        });
                    }
                } return arr;
            },
            'delete': (payload) => {
                const obj: any = {}; if (payload && payload.component) {
                    if (payload.deleteData) {
                        obj.trfTypRevIdNbr = payload.deleteData.TRF_TYP_REV_ID_NBR;
                    }
                }
                return obj;
            }
        },
        'STS': {
            // 'init': (payload) => {
            //     if (payload && payload.component) {
            //         if (payload.initResponse) {
            //             payload.component.dynamicHierarchy['countryName'] = payload.initResponse;
            //             payload.component.filterFieldMap['countryName'].values = Object.keys(payload.initResponse);
            //             Object.keys(payload.initResponse).map(function (key) {
            //                 if (payload.initResponse[key]
            //                     && (payload.initResponse[key].countryCode === payload.component.loggedInCountryCode)) {
            //                     payload.component.dynamicModel['countryName'] = key;
            //                     payload.component.dynamicModel['countryCode'] = payload.initResponse[key].countryCode;
            //                     payload.component.dynamicModel['currencyCode'] = payload.initResponse[key].currencyCode;
            //                     payload.component.filterFieldMap['availableDates'].values = payload.initResponse[key].availableDates;
            //                     payload.component.dynamicModel['availableDates'] = payload.initResponse[key].currentDate;
            //                 }
            //             });
            //             payload.component.filterData();
            //         }
            //     }
            // },
            'get': (payload) => {
                if (payload && payload.component) {
                    if (payload.getResponse) {
                        payload.getResponse.map(function (response) {
                            if (response.TYP_NM === 'D') {
                                response.TYP_NM = 'Domestic';
                            } else {
                                response.TYP_NM = 'International';
                            }
                        });
                    }
                } return payload.getResponse;
            },
            'add': (payload) => {
                let data = new FormData();
                if (payload && payload.component) {
                    if (payload.createData) {
                        const obj = payload.createData;
                        const formData = new FormData();
                        formData.append('cntryCd ', obj.CTRY_CD_NM);
                        formData.append('startDate', payload.utility.formatDateTime(new Date(obj.EFF_DT), 'MM/DD/YYYY'));
                        if (obj.files_file_content && (obj.FILE_EXT_TYP_NM || !obj.STD_TRF_DISC_ID_NBR)) {
                            formData.append('replaceFile', 'true');
                            formData.append('attachedFile', payload.utility.files[0]);
                        } else {
                            formData.append('replaceFile', 'false');
                        } formData.append('attachedFileNm', 'testFile.pdf');
                        formData.append('ldapId', obj.UPLD_LDAP_ID_NBR || 3535076);
                        formData.append('positionNbr', obj.NET_REV_POS_NBR);
                        formData.append('description', obj.DESC_TXT);
                        formData.append('ratingCategoryCd', obj.RTNG_CTGY_ID_NM);
                        formData.append('localMaxRev', obj.MAX_CURR_AMT);
                        formData.append('localMinRev', obj.MIN_CURR_AMT);
                        formData.append('typeNm', obj.TYP_NM);
                        data = formData;
                    }
                } return data;
            },
            'update': (payload) => {
                let data = new FormData();
                if (payload && payload.component) {
                    if (payload.updateArr) {
                        payload.updateArr.map(function (obj) {
                            const formData = new FormData();
                            formData.append('cntryCd ', obj.CTRY_CD_NM);
                            formData.append('startDate', payload.utility.formatDateTime(new Date(obj.EFF_DT), 'MM/DD/YYYY'));
                            if (obj.files && (obj.FILE_EXT_TYP_NM || obj.FILE_EXT_TYP_NM === null || !obj.STD_TRF_DISC_ID_NBR)) {
                                formData.append('replaceFile', 'true');
                                formData.append('attachedFile', obj.files);
                            } else {
                                formData.append('replaceFile', 'false');
                            } formData.append('attachedFileNm', obj.FILE_EXT_TYP_NM);
                            formData.append('ldapId', obj.UPLD_LDAP_ID_NBR || 3535076);
                            formData.append('positionNbr', obj.NET_REV_POS_NBR);
                            formData.append('description', obj.DESC_TXT);
                            formData.append('ratingCategoryCd', obj.RTNG_CTGY_ID_NM);
                            formData.append('localMaxRev', obj.MAX_CURR_AMT);
                            formData.append('localMinRev', obj.MIN_CURR_AMT);
                            formData.append('stdTrfDscIdNbr', obj.STD_TRF_DISC_ID_NBR);
                            const typeNm = (obj.TYP_NM === 'International') ? 'I' : 'D';
                            formData.append('typeNm', typeNm);
                            data = formData;
                        });
                    }
                } return data;
            },
            'delete': (payload) => {
                const obj: any = {};
                if (payload && payload.component) {
                    if (payload.deleteData) {
                        obj.cntryCd = payload.deleteData.CTRY_CD_NM;
                        obj.ratingCategoryCd = payload.deleteData.RTNG_CTGY_ID_NM;
                        obj.startDate = payload.utility.formatDateTime(new Date(payload.deleteData.EFF_DT), 'DD/MM/YYYY');
                        obj.typeNm = payload.deleteData.TYP_NM === 'International' ? 'I' : 'D';
                    }
                } return obj;
            },
        },
        'FTT': {},
        'PTS': {},
        'UA': {
            'init': (payload) => { },
            'get': (payload) => {
                if (payload && payload.component) {
                    if (payload.getResponse) {
                        const filteredList = [];
                        JSON.parse(JSON.stringify(payload.getResponse)).forEach(record => {
                            // if ((['Sales User', 'Pricing User', 'Pricing MD', 'Pricing Manager',
                            //     'FTT_PRICING_EUROPE', 'Pricing HQ', 'Rating Admin']
                            //     .includes(record.roleNm)) && record.countryList) {
                            if (record.roleNm === 'FTT_PRICING_EUROPE') {
                                record.roleNm = 'Pricing Europe';
                            }
                            record.countryList = record.countryList.split(',');
                            filteredList.push(record);
                            // }
                        });
                        return filteredList;
                    }
                }
            },
            'add': (payload) => {
                return {
                    userId: payload.createData.userId - 0,
                    userName: payload.createData.userName,
                    roleNm: payload.createData.roleName,
                    ctryCdArr: payload.createData.countryCodes,
                    createUserId: Utility.userDetails.userId
                }
            },
            'update': (payload) => {
                if (payload && payload.component) {
                    if (payload.updateArr && payload.updateArr[0].countryList.length > 0) {
                        const request: any = {};
                        request.ctryCdArr = payload.updateArr[0].countryList;
                        request.userId = payload.updateArr[0].userId;
                        request.createUserId = payload.updateArr[0].createduserId;
                        request.roleNm = payload.updateArr[0].roleNm;
                        return request;
                    }
                    this.commonService.showNotifier('Atleast one country should be selected', 'error');
                } return false;
            },
            'delete': (payload) => {
                const obj: any = {};
                if (payload && payload.component) {
                    if (payload.deleteData) {
                        obj.userId = payload.deleteData.userId;
                    }
                }
                $('.clearBtn').trigger('click');
                return obj;
            },
        },
        'FTTDISC': {
            'init': {},
            'get': (payload) => {
                if (payload && payload.getResponse) {
                    payload.getResponse.map((record) => {
                        record.zone = record.zone.split('ZONE')[1];
                    });
                    return payload.getResponse;
                }
            },
            'add': (payload) => {
                return [{
                    wgtLvlId: payload.createData.wgtLvlId,
                    ctryCd: payload.createData.countryCode,
                    svcIdNbr: payload.createData.svcIdNbr,
                    loggedInUserId: payload.utility.userDetails.userId,
                    effectiveDate: payload.component.gridChangeFormat(payload.createData.availableDate),
                    capDiscountDetails: [{
                        zoneCd: 'ZONE' + payload.createData.zoneCd,
                        capDiscNbr: payload.createData.capDiscNbr
                    }],
                }]
            },
            'update': (payload) => {
                if (payload && payload.component) {
                    if (payload.updateArr) {
                        const request = [];
                        payload.updateArr.map(function (updateObj) {
                            const requestObj: any = {};
                            requestObj.wgtLvlId = updateObj.id,
                                requestObj.ctryCd = updateObj.ctryCd,
                                requestObj.svcIdNbr = updateObj.svcIdNbr,
                                requestObj.loggedInUserId = payload.utility.userDetails.userId,
                                requestObj.effectiveDate = payload.component.gridChangeFormat(updateObj.effDt),
                                requestObj.capDiscountDetails = [{
                                    zoneCd: 'ZONE' + updateObj.zone,
                                    capDiscNbr: updateObj.capDiscNbr
                                }]
                            request.push(requestObj)
                        });
                        return request;
                    }
                    this.commonService.showNotifier('Atleast one country should be selected', 'error');
                } return false;
            },
            'delete': (payload) => {
                const obj: any = {};
                if (payload && payload.component) {
                    if (payload.deleteData) {
                        obj.id = payload.deleteData.id;
                        obj.zoneCd = 'ZONE' + payload.deleteData.zone;
                    }
                }
                return [obj];
            }
        },
        'FTTRL': {
            'init': (payload) => { },
            'add': (payload) => {
                return [{
                    ctryCd: payload.createData.countryCode,
                    svcIdNbr: payload.createData.svcIdNbr,
                    loggedInUserId: payload.utility.userDetails.userId,
                    effectiveDate: payload.component.gridChangeFormat(payload.createData.effectiveDate),
                    revenueLevelDetails: {
                        revMinAmt: payload.createData.revMinAmt,
                        revMaxAmt: payload.createData.revMaxAmt,
                        recDiscAmt: payload.createData.recDiscAmt,
                        minDiscGrp1Amt: payload.createData.minDiscGrp1Amt,
                        maxDiscGrp1Amt: payload.createData.maxDiscGrp1Amt,
                        discInctGrp1Nbr: payload.createData.discInctGrp1Nbr,
                        minDiscGrp2Amt: payload.createData.minDiscGrp2Amt,
                        maxDiscGrp2Amt: payload.createData.maxDiscGrp2Amt,
                        discInctGrp2Nbr: payload.createData.discInctGrp2Nbr,
                    },
                }]
            },
            'update': (payload) => {
                if (payload && payload.component) {
                    if (payload.updateArr) {
                        const request = [];
                        payload.updateArr.map(function (updateObj) {
                            const requestObj: any = {};
                            requestObj.revenueId = updateObj.id,
                                requestObj.ctryCd = updateObj.ctryCd,
                                requestObj.svcIdNbr = updateObj.svcIdNbr,
                                requestObj.loggedInUserId = payload.utility.userDetails.userId,
                                requestObj.effectiveDate = payload.component.gridChangeFormat(updateObj.effDt),
                                requestObj.revenueLevelDetails = {
                                    revMinAmt: updateObj.minTrfRevAmt,
                                    revMaxAmt: updateObj.maxTrfRevAmt,
                                    recDiscAmt: updateObj.recDiscAmt,
                                    minDiscGrp1Amt: updateObj.minDiscGrp1Amt,
                                    maxDiscGrp1Amt: updateObj.maxDiscGrp1Amt,
                                    discInctGrp1Nbr: updateObj.discInctGrp1Nbr,
                                    minDiscGrp2Amt: updateObj.minDiscGrp2Amt,
                                    maxDiscGrp2Amt: updateObj.maxDiscGrp2Amt,
                                    discInctGrp2Nbr: updateObj.discInctGrp2Nbr,
                                }
                            request.push(requestObj)
                        });
                        return request;
                    }
                    this.commonService.showNotifier('Atleast one country should be selected', 'error');
                } return false;
            },
            'delete': (payload) => {
                const obj: any = {};
                if (payload && payload.component) {
                    if (payload.deleteData) {
                        obj.id = payload.deleteData.id;
                    }
                }
                return [obj];
            }
        },
        'FTTWL': {
            'init': (payload) => { },
            get: (payload) => {
                if (payload && payload.getResponse) {
                    payload.getResponse.map((record) => {
                        record.docFlag = record.docFlag === 0 ? 'Non Documents' : 'Documents';
                        record.dispFlag = record.dispFlag === 0 ? 'No' : 'Yes';
                    });
                    return payload.getResponse;
                }
            },
            'add': (payload) => {
                const serviceValue = payload.createData.svcIdNbr,
                serviceName = JSON.parse(JSON.stringify(Utility.commonStaticObject['services']))
                .filter((serv) => {
                    return serv.value === serviceValue;
                })[0].name;
                let weightName = `${serviceName} ${payload.createData.wgnMinNbr} - ${payload.createData.wgnMaxNbr}`;
                const max = payload.createData.wgnMaxNbr;
                let min = payload.createData.wgnMinNbr;
                if (`${max}` === '999999999') {
                    min = `${`${min}`.split('.')[0]}+`;
                    weightName = `${serviceName} ${min}`;
                }
                if (payload.createData.docFlag === 1) {
                    weightName = 'Documents'
                }
                return [{
                    ctryCd: payload.createData.countryCode,
                    svcIdNbr: serviceValue,
                    effectiveDate: payload.component.gridChangeFormat(payload.createData.effectiveDate),
                    loggedInUserId: payload.utility.userDetails.userId,
                    weightDetails: {
                        wgtNm: weightName,
                        wgnMinNbr: payload.createData.wgnMinNbr,
                        wgnMaxNbr: payload.createData.wgnMaxNbr,
                        dispFlag: payload.createData.dispFlag,
                        docFlg: payload.createData.docFlag
                    },
                }]
            },
            'update': (payload) => {
                if (payload && payload.component) {
                    if (payload.updateArr) {
                        const request = [];
                        payload.updateArr.map(function (updateObj) {
                            let weightName = `${updateObj.serviceNm} ${updateObj.minWgtNbr} - ${updateObj.maxWgtNbr}`;
                            const max = updateObj.maxWgtNbr;
                            let min = updateObj.minWgtNbr;
                            if (`${max}` === '999999999') {
                                min = `${`${min}`.split('.')[0]}+`;
                                weightName = `${updateObj.serviceNm} ${min}`;
                            }
                            if (updateObj.docFlag === 'Documents') {
                                weightName = 'Documents';
                            }
                            const requestObj: any = {};
                            requestObj.wgtLblId = updateObj.id,
                                requestObj.ctryCd = updateObj.ctryCd,
                                requestObj.svcIdNbr = updateObj.svcIdNbr,
                                requestObj.loggedInUserId = payload.utility.userDetails.userId,
                                requestObj.effectiveDate = payload.component.gridChangeFormat(updateObj.effDt),
                                requestObj.weightDetails = {
                                    wgtNm: weightName,
                                    wgnMinNbr: updateObj.minWgtNbr,
                                    wgnMaxNbr: updateObj.maxWgtNbr,
                                    dispFlag: updateObj.dispFlag === 'Yes' ? 1 : 0,
                                    docFlg: updateObj.docFlag === 'Documents' ? 1 : 0,
                                }
                            request.push(requestObj)
                        });
                        return request;
                    }
                    this.commonService.showNotifier('Atleast one country should be selected', 'error');
                } return false;
            },
            'delete': (payload) => {
                const obj: any = {};
                if (payload && payload.component) {
                    if (payload.deleteData) {
                        obj.id = payload.deleteData.id;
                    }
                }
                return [obj];
            }
        },
        'FTTUpload': {
            'init': (payload) => { },
            'add': (payload) => {
                return [{
                    ctryCd: payload.createData.ctryCd,
                    svcIdNbr: payload.createData.svcIdNbr,
                    effectiveDate: payload.component.gridChangeFormat(payload.createData.effectiveDate),
                    loggedInUserId: payload.utility.userDetails.userId,
                    weightDetails: {
                        wgtNm: `${payload.createData.wgnMinNbr} - ${payload.createData.wgnMaxNbr}`,
                        wgnMinNbr: payload.createData.wgnMinNbr,
                        wgnMaxNbr: payload.createData.wgnMaxNbr,
                        dispFlag: payload.createData.dispFlag,
                        docFlg: payload.createData.docFlag
                    },
                }]
            },
            'update': (payload) => {
                if (payload && payload.component) {
                    if (payload.updateArr) {
                        const request = [];
                        payload.updateArr.map(function (updateObj) {
                            const requestObj: any = {};
                            requestObj.wgtLblId = updateObj.id,
                                requestObj.countryName = updateObj.countryName,
                                requestObj.svcIdNbr = updateObj.svcIdNbr,
                                requestObj.loggedInUserId = payload.utility.userDetails.userId,
                                requestObj.effectiveDate = payload.component.gridChangeFormat(updateObj.effDt),
                                requestObj.weightDetails = {
                                    wgtNm: `${updateObj.minWgtNbr} - ${updateObj.maxWgtNbr}`,
                                    wgnMinNbr: updateObj.minWgtNbr,
                                    wgnMaxNbr: updateObj.maxWgtNbr,
                                    dispFlag: updateObj.dispFlag,
                                    docFlg: updateObj.docFlag
                                }
                            request.push(requestObj)
                        });
                        return request;
                    }
                    this.commonService.showNotifier('Atleast one country should be selected', 'error');
                } return false;
            }
        },
        'ListPrice': {
            'get': (data) => {
                return {
                    data: data.getResponse,
                    title: Utility.commonStaticObject.serviceTitle
                }
            }
        }
    }
    constructor(private commonService: CommonService) { }
    setTableData(data) {
        this.currentTableData = data;
    }
}
