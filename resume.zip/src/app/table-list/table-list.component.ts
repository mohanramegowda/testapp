/*
 * SonarQube, open source software quality management tool.
 * Copyright (C) 2008-2013 SonarSource
 * mailto:contact AT sonarsource DOT com
 *
 * SonarQube is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or (at your option) any later version.
 *
 * SonarQube is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */


import {
  Component, OnInit, Input, ViewChild, OnDestroy,
  ElementRef, ComponentRef, ComponentFactory, ViewContainerRef, ComponentFactoryResolver
} from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs/internal/Observable';
import { ReplaySubject } from 'rxjs/internal/ReplaySubject';
import { filter } from 'rxjs/operators';
import { MatDialog, MatPaginator, MatSort, MatTableDataSource, DateAdapter, MAT_DATE_FORMATS } from '@angular/material';

import { CommonService } from '../common/common.service';
import { Utility } from '../common/Utility';
import { ListColumn } from './list/list-column.model';

// TODO: THIS needs to be removed.

import { TTConfig } from './dynamic-filter/static-data/TT-screens.config';
import { STConfig } from './dynamic-filter/static-data/ST-screens.config';
import { PTConfig } from './dynamic-filter/static-data/PT-screens.config';
import { UAConfig } from './dynamic-filter/static-data/UA-screens.config';
import { FTTDiscConfig } from './dynamic-filter/static-data/FTTDISC-screens.config';
import { FTTRLConfig } from './dynamic-filter/static-data/FTTRL-screens-config';
import { FTTWLConfig } from './dynamic-filter/static-data/FTTWL-screens-config';
import { FTTUploadConfig } from './dynamic-filter/static-data/FTTUploadSetting-screens.config';
import { PRCConfig } from './dynamic-filter/static-data/PRC-screens.config';
import { CRCConfig } from './dynamic-filter/static-data/CRC-screens.config';


import { Subscription } from 'rxjs';
import { TableListDetailComponent } from './table-list-detail/table-list-detail.component';
import { AppDateAdapter, APP_DATE_FORMATS } from 'app/common/customDatePicker';
import { TableListService } from './table-list.service';


declare var $: any;
@Component({
  selector: 'app-table-list',
  templateUrl: './table-list.component.html',
  styleUrls: ['./table-list.component.scss'],
  providers: [
    {
      provide: DateAdapter, useClass: AppDateAdapter
    },
    {
      provide: MAT_DATE_FORMATS, useValue: APP_DATE_FORMATS
    }]
})
export class TableListComponent implements OnInit, OnDestroy {

  subject$: ReplaySubject<any[]> = new ReplaySubject<any[]>(1);
  data$: Observable<any[]> = this.subject$.asObservable();
  users: any[];
  roles: string[];
  filter: any = {};
  component: any;
  tempData: any;
  title;
  subTitle;
  formData: FormData = new FormData();
  @Input()
  columns: ListColumn[] = [] as ListColumn[];

  profileConfigName: any = '';
  pageSize = 10;
  dataSource: MatTableDataSource<File> | null;

  @ViewChild('sneakPreviewContainer', { read: ViewContainerRef, static: false })
  sneakPreviewContainer;

  @ViewChild(MatPaginator, { static: false }) paginator: MatPaginator;
  @ViewChild(MatSort, { static: false }) sort: MatSort;
  @ViewChild('tableScroll', { read: ElementRef, static: false }) public tableScroll: ElementRef<any>;

  columnsTemplate: any = [
    { name: 'Checkbox', property: 'checkbox', visible: false },
    { name: 'Actions', property: 'actions', visibleType: 'both', visible: true },
  ]

  resultSubscription: Subscription;
  dynamicEvents: any = {};

  screenConfig: any = {};
  previousRow: any;
  rowsToUpdate: any;
  currentRow: any;
  blockBulkUpdate: boolean;

  initConfig = null;
  inlineRows: any = [];
  enableDelete: boolean;
  clearSearch = false;
  noTable: Boolean;
  noTableConfig = false;

  constructor(private commonService: CommonService,
    private route: ActivatedRoute,
    private dialog: MatDialog,
    private resolver: ComponentFactoryResolver,
    private tableListService: TableListService) {
    let scrnConfig: any;
    this.component = this;
    this.route.params.subscribe(params => {
      this.clearData();
      if (params.profileConfig) {
        this.profileConfigName = params.profileConfig;
        this.columns = JSON.parse(JSON.stringify(this.columnsTemplate));
        if (this.profileConfigName === 'PRC') {
          scrnConfig = JSON.parse(JSON.stringify(PRCConfig.config));
          this.screenConfig = scrnConfig;
          this.processTableHeaders(this.screenConfig);
        } else if (this.profileConfigName === 'CRC') {
          scrnConfig = JSON.parse(JSON.stringify(CRCConfig.config));
          this.screenConfig = scrnConfig;
          this.processTableHeaders(this.screenConfig);
        } else if (this.profileConfigName === 'STS') {
          scrnConfig = JSON.parse(JSON.stringify(STConfig.config));
          this.screenConfig = scrnConfig;
          this.processTableHeaders(this.screenConfig);
        } else if (this.profileConfigName === 'UA') {
          scrnConfig = JSON.parse(JSON.stringify(UAConfig.config));
          this.screenConfig = scrnConfig;
          this.processTableHeaders(this.screenConfig);
        } else if (this.profileConfigName === 'FTTDISC') {
          scrnConfig = JSON.parse(JSON.stringify(FTTDiscConfig.config));
          this.screenConfig = scrnConfig;
          this.processTableHeaders(this.screenConfig);
        } else if (this.profileConfigName === 'FTTRL') {
          scrnConfig = JSON.parse(JSON.stringify(FTTRLConfig.config));
          this.screenConfig = scrnConfig;
          this.processTableHeaders(this.screenConfig);
        } else if (this.profileConfigName === 'FTTWL') {
          scrnConfig = JSON.parse(JSON.stringify(FTTWLConfig.config));
          this.screenConfig = scrnConfig;
          this.processTableHeaders(this.screenConfig);
        } else if (this.profileConfigName === 'FTTUpload') {
          this.noTable = false;
          scrnConfig = JSON.parse(JSON.stringify(FTTUploadConfig.config));
          this.screenConfig = scrnConfig;
          this.processTableHeaders(this.screenConfig);
        }
        if (this.profileConfigName) {
          this.screenConfig.eventConfig = this.tableListService.eventConfigObject[this.profileConfigName];
        }
        if (this.screenConfig.ajaxUrls.delete) {
          this.enableDelete = true;
        } else {
          this.enableDelete = false;
        }
      }
      if (scrnConfig) {
        this.title = scrnConfig.title;
        this.subTitle = scrnConfig.subTitle;
        this.populateDynamicEvents();
      }
    });
  }

  populateDynamicEvents() {
    if (this.screenConfig.eventConfig) {
      this.dynamicEvents = [];
      try {
        for (const i in this.screenConfig.eventConfig) {
          if (this.screenConfig.eventConfig[i]) {
            this.dynamicEvents[i] = this.screenConfig.eventConfig[i];
          } else {
            this.dynamicEvents[i] = {};
          }
        }
      } catch (e) {
        console.log(e);
      }
    } else {
      this.dynamicEvents = [];
    }
  }

  processTableHeaders(configObj) {
    if (!configObj) {
      throw new Error('No Config Found');
    }
    if (configObj.table && configObj.table.length > 0) {
      let count = 1;
      const cols = this.columns;
      configObj.table.map((colConfig) => {
        cols.splice(count, 0, colConfig);
        count += 1;
      });
    }
  }

  ngOnInit() {
    this.resultSubscription = this.commonService.getFilteredResults()
      .subscribe((data) => {
        const payload = { component: this.component, getResponse: data, utility: Utility };
        if (this.dynamicEvents.get) {
          data = this.dynamicEvents.get(payload);
        }
        this.subject$.next(data);
        this.tableListService.setTableData(data);
        this.clearSearch = true;
        this.dataSource = new MatTableDataSource();

        this.data$.pipe(
          filter(Boolean)
        ).subscribe((users: any) => {
          this.users = users;
          this.dataSource.data = users;
        });

        this.dataSource.paginator = this.paginator;
        if (this.paginator) {
          this.paginator.pageIndex = 0;
        }
        this.dataSource.sort = this.sort;
        const defaultPredicate = this.dataSource.filterPredicate;
        this.dataSource.filterPredicate = (dataFilter, filterPredicate) => {
          const formatted = this.gridChangeFormat(dataFilter['EFF_DT']);
          return formatted.indexOf(filterPredicate) >= 0 || defaultPredicate(dataFilter, filterPredicate);
        }
      });
  }

  clearData() {
    this.noTable = true;
    this.subject$.next([]);
    this.dataSource = new MatTableDataSource();
    this.rowsToUpdate = [];
    this.noTableConfig = false;
    this.data$.pipe(
      filter(Boolean)
    ).subscribe((users: any) => {
      this.users = users;
      this.dataSource.data = users;
    });
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;
  }
  getConfig() {
    // TODO: Need to complete the config part.
  }

  // TODO: THis is a temp function delete this
  deleteDefaults(data) {
    const result = [];
    for (const i in data) {
      if (i !== 'default' && data[i]) {
        result.push(data[i]);
      }
    }
    return result;
  }

  get visibleColumns() {
    return this.columns.filter(column => column.visible).map(column => column.property);
  }

  onFilterChange(value) {
    if (!this.dataSource) {
      return;
    }
    this.clearSearch = false;
    value = value.trim();
    value = value.toLowerCase();
    this.dataSource.filter = value;
  }

  createRow() {
    if (!this.screenConfig.createUpdateForm) {
      this.commonService.showNotifier('No Crud Operations Configured', 'error');
      return;
    }
    TableListDetailComponent.configuration = this.screenConfig.createUpdateForm;
    TableListDetailComponent.existingData = null;
    const ref = this.dialog.open(TableListDetailComponent);
    const sub = ref.componentInstance.onSubmit.subscribe((data) => {
      if (!data) {
        return;
      }
      let request = [];
      const payload = { component: this.component, createData: data, utility: Utility };
      if (this.dynamicEvents.add) {
        request = this.dynamicEvents.add(payload);
      } else {
        request = this.rowsToUpdate;
      }
      if (this.screenConfig.ajaxUrls.add) {
        const url = Utility.urlParams[this.screenConfig.ajaxUrls.add].url;
        const type = Utility.urlParams[this.screenConfig.ajaxUrls.add].type;
        this.commonService.getAPIResponse(url, request, type).subscribe((response: any) => {
          if (response && response.status === 'EXCEPTION') {
            if (response.message) {
              this.commonService.showNotifier(response.message, 'error');
            } else {
              this.commonService.showNotifier('An error occurred while updating data.', 'error');
            }
            return;
          }
          if (response) {
            this.commonService.showNotifier('Row Added Successfully.', 'success');
            ref.close();
            $('.goBtn').trigger('click')
          }
        }, (error) => {
          console.log(error);
          this.commonService.showNotifier('An error occurred while adding data.', 'error');
        });
      } else {
        this.commonService.showNotifier('No Save Operations Configured', 'error');
        return;
      }
    });
    ref.afterClosed().subscribe(() => {
      sub.unsubscribe();
    });
  }

  deleteRow(row) {
    let request = row;
    const payload = { component: this.component, deleteData: row, utility: Utility };
    if (this.dynamicEvents.delete) {
      request = this.dynamicEvents.delete(payload);
    }
    if (this.screenConfig.ajaxUrls.delete) {
      const url = Utility.urlParams[this.screenConfig.ajaxUrls.delete].url;
      const type = Utility.urlParams[this.screenConfig.ajaxUrls.delete].type;
      this.commonService.getAPIResponse(url, request, type).subscribe((response: any) => {
        if (response && response.status === 'EXCEPTION') {
          if (response.message) {
            this.commonService.showNotifier(response.message, 'error');
          } else {
            this.commonService.showNotifier('An error occurred while updating data.', 'error');
          }
          return;
        }
        if (response) {
          this.commonService.showNotifier('Row Deleted Successfully.', 'success');
          $('.goBtn').trigger('click');
        }
      }, (error) => {
        console.log(error);
      });
    } else {
      this.commonService.showNotifier('No Delete Operations Configured', 'error');
      return;
    }
  }

  updateRow(row) {
    // Intentionally Commented
    // if (!row && this.previousRow) {
    //   this.previousRow.isEditing = false;
    //   this.previousRow = null;
    //   return;
    // } else if (!row && !this.previousRow) {
    //   return;
    // }

    if (!this.screenConfig.createUpdateForm) {
      this.commonService.showNotifier('No Crud Operations Configured', 'error');
      return;
    }
    if (this.previousRow) {
      this.previousRow.isEditing = false;
    }
    row.isEditing = true;
    row.isEdited = false;
    this.previousRow = row;
    this.tempData = JSON.parse(JSON.stringify(row));
  }

  gridChangeFormat(date) {
    return this.commonService.formatDateTime(new Date(date), 'DD/MM/YYYY');
  }

  validateRow(row) {
    let validity = true;
    this.screenConfig.createUpdateForm.fields.map((formField) => {
      this.screenConfig.table.map((tableField) => {
        if ((tableField.name === formField.label)) {
          if (formField.validations) {
            formField.validations.map((validation) => {
              if (validation.name === 'required' && !row[tableField.property] && ![0, false].includes(row[tableField.property])) {
                this.commonService.showNotifier(validation.message, 'error')
                validity = false;
              }
              if (validation.name === 'pattern' && row[tableField.property]
                && !new RegExp(validation.validator).test(row[tableField.property])) {
                this.commonService.showNotifier(validation.message, 'error')
                validity = false;
              }
            })
          }
        }
      })
    });
    return validity;
  }
  saveUpdateRow(row) {
    if (!this.rowsToUpdate) {
      this.rowsToUpdate = [];
    }
    if (!this.validateRow(row)) {
      return false;
    }
    if (JSON.stringify(this.tempData) !== JSON.stringify(row)) {
      const temRow = JSON.parse(JSON.stringify(row));
      delete temRow['isEditing'];
      delete temRow['isEdited'];
      this.rowsToUpdate.push(temRow);
      row.isEdited = true;
    } else {
      row.isEdited = false;
    }
    row.isEditing = false;
    if (this.screenConfig.isInlineEdit) {
      this.rowsToUpdate = [row];
      this.currentRow = row;
      this.update(true);
    }
  }
  dismissRow(row) {
    row.isEditing = false;
    const rowCopy = JSON.parse(JSON.stringify(row));
    delete this.tempData['isEditing'];
    delete this.tempData['isEdited'];
    delete rowCopy['isEditing'];
    delete rowCopy['isEdited'];
    if (JSON.stringify(this.tempData) !== JSON.stringify(rowCopy)) {
      Object.keys(this.tempData).forEach(prop => {
        row[prop] = this.tempData[prop];
      });
      row.isEdited = false;
    }
  }


  update(isPartial = false) {
    if (this.blockBulkUpdate && !isPartial) {
      $('.goBtn').trigger('click');
    }
    if (this.rowsToUpdate && this.rowsToUpdate.length > 0) {
      let request;
      const payload = { component: this.component, updateArr: this.rowsToUpdate, utility: Utility };
      if (this.dynamicEvents.update) {
        request = this.dynamicEvents.update(payload);
      } else {
        request = this.rowsToUpdate;
      }

      if (this.screenConfig.ajaxUrls.update && request) {
        const url = Utility.urlParams[this.screenConfig.ajaxUrls.update].url;
        const type = Utility.urlParams[this.screenConfig.ajaxUrls.update].type;
        this.commonService.getAPIResponse(url, request, type).subscribe((response: any) => {
          if (response && response.status === 'EXCEPTION') {
            if (isPartial) { // TODO: Row level Validation
              this.blockBulkUpdate = true;
            } else {
              this.blockBulkUpdate = false;
            }
            if (response.message) {
              this.commonService.showNotifier(response.message, 'error');
            } else {
              this.commonService.showNotifier('An error occurred while updating data.', 'error');
            }
            return;
          }
          if (response) {
            if (this.screenConfig.isInlineEdit) {
              this.inlineRows = this.rowsToUpdate;
            }
            this.rowsToUpdate = [];
            if (!isPartial) {
              this.commonService.showNotifier('Rows Updated Successfully.', 'success');
              $('.goBtn').trigger('click');
            } else {
              // Intentionally Commented
              // this.commonService.showNotifier('Record Updated.', 'success');
            }
          }

        }, (error) => {
          console.log(error);
          if (!isPartial) {
            this.commonService.showNotifier('An error occurred while updating data.', 'error');
          }
        });
      } else {
        if (!request) {
          return;
        }
        this.commonService.showNotifier('No Save Operations Configured', 'error');
        return;
      }

    } else if (this.screenConfig.isInlineEdit) {
      if (this.inlineRows.length > 0) {
        this.commonService.showNotifier('Rows Updated Successfully.', 'success');
        this.inlineRows = []
        if (this.screenConfig.clientFilter) {
          $('.clearBtn').trigger('click');
        } else {
          $('.goBtn').trigger('click');
        }
      } else {
        this.commonService.showNotifier('Please Edit and Confirm to update rows.', 'error');
      }
    } else {
      this.commonService.showNotifier('Please Edit and Confirm to update rows.', 'error');
    }
  }

  getColumnProperty(paramName) {
    return Utility.commonStaticObject[paramName];
  }

  ngOnDestroy(): void {
    this.resultSubscription.unsubscribe();
  }

  selectAll(row, arr, select, event) {
    row = [];
    if (select) {
      arr.map((val) => {
        if (val.value) {
          row.push(val.value);
        }
      });
      $(event.target).parents().find('.mat-select-panel').find('mat-pseudo-checkbox').addClass('mat-pseudo-checkbox-checked');
      return row;
    }
    $(event.target).parents().find('.mat-select-panel').find('mat-pseudo-checkbox').removeClass('mat-pseudo-checkbox-checked');
    return row;
  }
  public scrollRight() {
    this.tableScroll.nativeElement.scrollTo({ left: (this.tableScroll.nativeElement.scrollLeft + 150), behavior: 'smooth' });
  }
  public scrollLeft() {
    this.tableScroll.nativeElement.scrollTo({ left: (this.tableScroll.nativeElement.scrollLeft - 150), behavior: 'smooth' });
  }
}
