/*
 * SonarQube, open source software quality management tool.
 * Copyright (C) 2008-2013 SonarSource
 * mailto:contact AT sonarsource DOT com
 *
 * SonarQube is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or (at your option) any later version.
 *
 * SonarQube is distributed in the hope that it will be useful, * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */


export class FTTDiscConfig {
    static config = {
        'title': 'FTT Zone Setings',
        'subTitle': 'Configure FTT Zones and its capped discounts',
        'advancedFilterTitle': 'Filter Country Types',
        'screen': 'FTTDISC',
        'filters': [
            {
                'field': 'CTRY_NM',
                'displayName': 'Country',
                'defaultValue': '',
                'type': 'dropdown',
                'values': [],
                'hierarchyRoot': true
            },
            {
                'field': 'CTRY_CD_NM',
                'displayName': 'Country Code',
                'defaultValue': '',
                'type': 'input',
                'disabled': true,
                'inputType': 'text',
                'hierarchyParent': 'CTRY_NM'
            },
            {
                'field': 'services',
                'displayName': 'Services',
                'defaultValueField': 0,
                'defaultValue': 0,
                'type': 'dropdown',
                'kvp': true,
                'values': [],
                'hierarchyParent': 'CTRY_NM'
            },
            {
                'field': 'weightLevels',
                'displayName': 'Weight Levels',
                'defaultValueField': 0,
                'defaultValue': 0,
                'type': 'dropdown',
                'dateDropDown': false,
                'disabled': false,
                'kvp': true,
                'values': [],
                'hierarchyParent': 'CTRY_NM'
            },
            {
                'field': 'availableDates',
                'displayName': 'Available Dates',
                'defaultValueField': '',
                'defaultValue': '',
                'type': 'dropdown',
                'dateDropDown': true,
                'disabled': false,
                'hierarchyParent': 'CTRY_NM',
                'hierarchyRoot': true
            }
        ],
        'ajaxUrls': {
            'defaultGet': {
                'url': 'cappedLevelDetails',
                'defaultParams': {
                    'type': 'GET'
                },
                'params': {
                    'CTRY_CD_NM': 'ctryCd',
                    'weightLevels': 'wgtLblId',
                    'availableDates': 'effDate'
                },
                'beforeFilter': true
            },
            'filterGet': {
                'url': 'cappedLevelDetails',
                'defaultParams': {
                    'type': 'GET'
                },
                'params': {
                    'CTRY_CD_NM': 'ctryCd',
                    'weightLevels': 'wgtLblId',
                    'availableDates': 'effDate'
                },
                'beforeFilter': true
            },
            'update': 'capDiscountSetting',
            'add': 'capDiscountSetting',
            'delete': 'deleteCapDiscountSetting',
            'init': {
                'countryDetails': {
                    'url': 'CountryDetails',
                    'filterFieldMap': {
                        'CTRY_NM': 'CTRY_NM'
                    },
                    'defaultRequest': {
                        'type': 'ALL'
                    },
                    'dynamicParam': null
                },
                'availableDates': {
                    'url': 'weightLevelDetailsAvailableDates',
                    'dynamicFieldMap': 'availableDates',
                    'filterFieldMap': {
                        'AVAILABLE_DATE_ARRAY': 'availableDates'
                    },
                    'defaultRequest': {
                        'type': 'GET'
                    },
                    'dynamicParam': {
                        'ctryCd': 'CTRY_CD_NM'
                    }
                },
                'closestDate': {
                    'url': 'closestCappedLevelDetails',
                    'dynamicModelMap': {
                        'CLOSESTDATE': 'availableDates'
                    },
                    'defaultRequest': {
                        'type': 'GET'
                    },
                    'dynamicParam': {
                        'ctryCd': 'CTRY_CD_NM',
                        'inputValue': 'newOttFormatedDate'
                    }
                },
                'capDiscountDropDown': {
                    'url': 'capDiscountDropDown',
                    'dynamicFieldMap': 'weightLevels',
                    'storeToGlobal': true,
                    'defaultRequest': {
                        'type': 'GET'
                    },
                    'dynamicParam': {
                        'ctryCd': 'CTRY_CD_NM',
                        'effDate': 'availableDates'
                    }
                },
                'serviceDropDown': {
                    'url': 'serviceDropDown',
                    'dynamicFieldMap': 'services',
                    'storeToGlobal': true,
                    'defaultRequest': {
                        'type': 'GET'
                    },
                    'dynamicParam': {
                        'ctryCd': 'CTRY_CD_NM'
                    }
                },
                'url': null
            }
        },
        'eventConfig': {
            'init': '',
            'get': '',
            'add': '',
            'update': '',
            'delete': ''
        },
        'crudConfig': {},
        'table': [
            {
                'name': 'Weight Level ID',
                'property': 'ID',
                'visibleType': 'ID',
                'type': 'number',
                'inputType': 'text',
                'visible': false,
                'editable': false,
                'isModelProperty': true,
                'showEdit': false,
                'isPrimaryKey': true
            },
            // {
            //     'name': 'Service',
            //     'property': 'serviceNm',
            //     'visibleType': 'serviceNm',
            //     'type': 'text',
            //     'inputType': 'text',
            //     'visible': false,
            //     'editable': false,
            //     'isModelProperty': true,
            //     'showEdit': false
            // },
            {
                'name': 'Weight Level',
                'property': 'wgtLbl',
                'visibleType': 'wgtLbl',
                'type': 'text',
                'inputType': 'text',
                'visible': true,
                'editable': false,
                'isModelProperty': true,
                'showEdit': false
            },
            {
                'name': 'Zone',
                'property': 'zone',
                'visibleType': 'zone',
                'type': 'number',
                'inputType': 'text',
                'visible': true,
                'editable': false,
                'isModelProperty': true,
                'showEdit': false
            },
            {
                'name': 'Capped Discount',
                'property': 'capDiscNbr',
                'visibleType': 'capDiscNbr',
                'type': 'number',
                'inputType': 'text',
                'visible': true,
                'editable': true,
                'isModelProperty': true
            },
            {
                'name': 'Effective Date',
                'property': 'effDt',
                'visibleType': 'effDt',
                'type': 'date',
                'visible': true,
                'editable': false,
                'isModelProperty': true
            },
            {
                'name': 'Country',
                'property': 'ctryCd',
                'visibleType': 'ctryCd',
                'type': 'text',
                'inputType': 'text',
                'utilFieldNm': 'countryCodeArr',
                'values': [],
                'visible': true,
                'editable': false,
                'isModelProperty': true,
            }
        ],
        'createUpdateForm': {
            'name': 'Test',
            'submitUrl': '',
            'form_name': 'FTTDISC',
            'entity': 'FTTDISC',
            'fields': [
                {
                    'label': 'Country',
                    'name': 'countryCode',
                    'type': 'select',
                    'required': true,
                    'inputType': 'text',
                    'disabled': true,
                    'value': '',
                    'utilFieldNm': 'countryCodeArr',
                    'defaultValueRef': 'filteredCountryCode',
                    'options': [],
                    'validations': [
                        {
                            'name': 'required',
                            'validator': '',
                            'message': 'country Required'
                        }
                    ]
                },
                {
                    'label': 'Service',
                    'name': 'svcIdNbr',
                    'type': 'select',
                    'required': true,
                    'inputType': 'text',
                    'utilFieldNm': 'services',
                    'defaultValueRef': '',
                    'options': [],
                    'values': '',
                    'validations': [
                        {
                            'name': 'required',
                            'validator': '',
                            'message': 'Service Name Required'
                        }
                    ]
                },
                {
                    'label': 'Weight Level Label',
                    'name': 'wgtLvlId',
                    'type': 'select',
                    'required': true,
                    'inputType': 'text',
                    'utilFieldNm': 'weightLevels',
                    'defaultValueRef': '',
                    'options': [],
                    'values': '',
                    'validations': [
                        {
                            'name': 'required',
                            'validator': '',
                            'message': 'Weight Level Required'
                        }
                    ]
                },
                {
                    'label': 'Zone',
                    'name': 'zoneCd',
                    'type': 'input',
                    'value': 0,
                    'required': true,
                    'inputType': 'number',
                    'validations': [
                        {
                            'name': 'required',
                            'validator': '',
                            'message': 'Minimum Value Required'
                        },
                        {
                            'name': 'pattern',
                            'validator': '^[1-9]+[0-9]*$',
                            'message': 'Only Positive Whole Numbers Required'
                        }
                    ]
                },
                {
                    'label': 'Capped Discount',
                    'name': 'capDiscNbr',
                    'type': 'input',
                    'value': 0,
                    'required': true,
                    'inputType': 'number',
                    'validations': [
                        {
                            'name': 'required',
                            'validator': '',
                            'message': 'Minimum Value Required'
                        },
                        {
                            'name': 'pattern',
                            'validator': '^[1-9]+[0-9]*$',
                            'message': 'Only Positive Whole Numbers Required'
                        }
                    ]
                },
                {
                    'label': 'Effective Date',
                    'name': 'effectiveDate',
                    'type': 'date',
                    'required': true,
                    'defaultValueRef': 'filteredAvailableDates',
                    'utilFieldNm': 'availableDates',
                    'disabled': true,
                    'value': 0,
                    'inputType': 'date',
                    'validations': [
                        {
                            'name': 'required',
                            'validator': '',
                            'message': 'Effective Date Required'
                        }
                    ]
                },
                {
                    'type': 'button',
                    'styleColor': 'primary',
                    'styleClass': 'float-right',
                    'label': 'Add Setting'
                }
            ]
        }
    }
}
