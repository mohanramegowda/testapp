/*
 * SonarQube, open source software quality management tool.
 * Copyright (C) 2008-2013 SonarSource
 * mailto:contact AT sonarsource DOT com
 *
 * SonarQube is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or (at your option) any later version.
 *
 * SonarQube is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */


export class STConfig {
    static config = {
        'title': 'Standard Tariff Settings',
        'subTitle': 'Configure Standard Tariff',
        'advancedFilterTitle': 'Filter Standard Tariff',
        'isInlineEdit': true,
        'filters': [{
                'field': 'CTRY_NM',
                'displayName': 'Country',
                'defaultValue': '',
                'type': 'dropdown',
                'values': [],
                'hierarchyRoot': true
            },
            {
                'field': 'CTRY_CD_NM',
                'displayName': 'Country Code',
                'defaultValue': '',
                'type': 'input',
                'disabled': true,
                'inputType': 'text',
                'hierarchyParent': 'CTRY_NM'
            },
            {
                'field': 'CURR_CD_NM',
                'displayName': 'Currency',
                'defaultValue': '',
                'type': 'input',
                'disabled': true,
                'inputType': 'text',
                'hierarchyParent': 'CTRY_NM'
            },
            {
                'field': 'availableDates',
                'displayName': 'Available Dates',
                'defaultValueField': 'currentDate',
                'defaultValue': '',
                'type': 'dropdown',
                'dateDropDown': true,
                'disabled': false,
                'hierarchyParent': 'CTRY_NM'
            },
            {
                'field': 'typNm',
                'displayName': 'Revenue Type',
                'defaultValueField': 0,
                'defaultValue': 'A',
                'type': 'dropdown',
                'disabled': false,
                'kvp': true,
                'values': [{
                    'name': 'All',
                    'value': 'A'
                }, {
                    'name': 'International',
                    'value': 'I'
                }, {
                    'name': 'Domestic',
                    'value': 'D'
                }],
                'hierarchyParent': 'CTRY_NM'
            }
        ],
        'ajaxUrls': {
            'defaultGet': {
                'url': 'countrySTSettings',
                'defaultParams': {
                    'type': 'GET'
                },
                'params': {
                    'CTRY_CD_NM': 'country',
                    'availableDates': 'startDate',
                    'typNm': 'typNm'
                }
            },
            'filterGet': {
                'url': 'postAdminDetl',
                'defaultParams': {
                    'type': 'GET'
                },
                'params': {
                    'CTRY_CD_NM': 'ctryCd',
                    'availableDates': 'startdate',
                    'typNm': 'typNm'
                }
            },
            'update': 'saveST',
            'add': 'saveST',
            'delete': 'deleteSTRow',
            'init': {
                'countryDetails': {
                    'url': 'CountryDetails',
                    'filterFieldMap': {
                        'CTRY_NM': 'CTRY_NM'
                    },
                    'defaultRequest': {
                        'type': 'ALL'
                    },
                    'dynamicParam': null
                },
                'availableDates': {
                    'url': 'stSettingsAvailableDates',
                    'dynamicFieldMap': 'availableDates',
                    'filterFieldMap': {
                        'AVAILABLE_DATE_ARRAY': 'availableDates'
                    },
                    'defaultRequest': {
                        'type': 'GET'
                    },
                    'dynamicParam': {
                        'ctryCd': 'CTRY_CD_NM'
                    }
                },
                'closestDate': {
                    'url': 'closestStandardTariffDiscInfo',
                    'dynamicModelMap': {
                        'CLOSESTDATE': 'availableDates'
                    },
                    'defaultRequest': {
                        'type': 'GET'
                    },
                    'dynamicParam': {
                        'ctryCd': 'CTRY_CD_NM',
                        'inputValue': 'newOttFormatedDate'
                    }
                },
                'url': null
            }
        },
        'crudConfig': {},
        'table': [
            {
                'name': 'ID',
                'property': 'STD_TRF_DISC_ID_NBR',
                'visibleType': 'STD_TRF_DISC_ID_NBR',
                'type': 'number',
                'inputType': 'text',
                'visible': false,
                'editable': false,
                'isModelProperty': true,
                'showEdit': false,
                'isPrimaryKey': true
            },
            {
                'name': 'Display Order',
                'property': 'NET_REV_POS_NBR',
                'visibleType': 'doc',
                'type': 'number',
                'inputType': 'text',
                'visible': true,
                'editable': true,
                'isModelProperty': true
            },
            {
                'name': 'Type',
                'property': 'TYP_NM',
                'visibleType': 'type',
                'type': 'dropdown',
                'transformMap': {
                    'Domestic': 'D',
                    'International': 'I'
                },
                'values': [
                    {
                        'value': 'Domestic',
                        'name': 'Domestic'
                    },
                    {
                        'value': 'International',
                        'name': 'International'
                    }
                ],
                'visible': true,
                'editable': true,
                'isModelProperty': true,
                'showEdit': false
            },
            {
                'name': 'Minimum',
                'property': 'MIN_CURR_AMT',
                'visibleType': 'min_rev',
                'type': 'number',
                'inputType': 'text',
                'visible': true,
                'editable': true,
                'isModelProperty': true,
                'showEdit': false
            },
            {
                'name': 'Maximum',
                'property': 'MAX_CURR_AMT',
                'visibleType': 'max_rev',
                'inputType': 'text',
                'type': 'number',
                'visible': true,
                'editable': true,
                'isModelProperty': true
            },
            {
                'name': 'Rating Category',
                'property': 'RTNG_CTGY_ID_NM',
                'visibleType': 'cat',
                'inputType': 'text',
                'type': 'text',
                'visible': true,
                'editable': true,
                'isModelProperty': true
            },
            {
                'name': 'Description',
                'property': 'DESC_TXT',
                'visibleType': 'desc',
                'type': 'text',
                'inputType': 'text',
                'visible': true,
                'editable': true,
                'isModelProperty': true
            },
            {
                'name': 'Effective Date',
                'property': 'EFF_DT',
                'visibleType': 'EFF_DT',
                'type': 'date',
                'visible': true,
                'editable': true,
                'isModelProperty': true
            },
            {
                'name': 'Document',
                'property': 'FILE_EXT_TYP_NM',
                'visibleType': 'doc',
                'type': 'file',
                'inputType': 'file',
                'visible': true,
                'editable': true,
                'isModelProperty': true
            },
            {
                'name': 'Country',
                'property': 'CTRY_CD_NM',
                'visibleType': 'countryCode',
                'type': 'dropdown',
                'utilFieldNm': 'countryCodeArr',
                'values': [],
                'visible': false,
                'editable': true,
                'isModelProperty': true,
                'showEdit': true
            }
        ],
        'createUpdateForm': {
            'name': 'Test',
            'submitUrl': '',
            'form_name': 'sts',
            'entity': 'sts',
            'fields': [
                {
                    'label': 'Country',
                    'name': 'CTRY_CD_NM',
                    'type': 'select',
                    'required': true,
                    'inputType': 'text',
                    'value': '',
                    'utilFieldNm': 'countryCodeArr',
                    'defaultValueRef': 'filteredCountryCode',
                    'options': [],
                    'validations': [
                        {
                            'name': 'required',
                            'validator': '',
                            'message': 'country Required'
                        }
                    ]
                },
                {
                    'label': 'Type',
                    'name': 'TYP_NM',
                    'type': 'select',
                    'required': true,
                    'inputType': 'text',
                    'value': 'D',
                    'options': [
                        {
                            'value': 'D',
                            'name': 'Domestic'
                        },
                        {
                            'value': 'I',
                            'name': 'International'
                        }
                    ],
                    'validations': [
                        {
                            'name': 'required',
                            'validator': '',
                            'message': 'Tariff Type Required'
                        }
                    ]
                },
                {
                    'label': 'Rating Category',
                    'name': 'RTNG_CTGY_ID_NM',
                    'type': 'input',
                    'required': true,
                    'value': 0,
                    'inputType': 'text',
                    'validations': [
                        {
                            'name': 'required',
                            'validator': '',
                            'message': 'Rating Category Required'
                        }
                    ]
                },
                {
                    'label': 'Description',
                    'name': 'DESC_TXT',
                    'type': 'input',
                    'value': 0,
                    'required': true,
                    'inputType': 'text',
                    'validations': [
                        {
                            'name': 'required',
                            'validator': '',
                            'message': 'Description Required'
                        }
                    ]
                },
                {
                    'label': 'Minimum',
                    'name': 'MIN_CURR_AMT',
                    'type': 'input',
                    'required': true,
                    'inputType': 'number',
                    'value': 0,
                    'validations': [
                        {
                            'name': 'required',
                            'validator': '',
                            'message': 'Minimum value Required'
                        },
                        {
                            'name': 'pattern',
                            'validator': '^[0-9]+[0-9]*$',
                            'message': 'Only Positive Whole Numbers Required'
                        }
                    ]
                },
                {
                    'label': 'Maximum',
                    'name': 'MAX_CURR_AMT',
                    'type': 'input',
                    'required': true,
                    'value': 0,
                    'inputType': 'number',
                    'validations': [
                        {
                            'name': 'required',
                            'validator': '',
                            'message': 'Maximum Value Required'
                        },
                        {
                            'name': 'pattern',
                            'validator': '^[1-9]+[0-9]*$',
                            'message': 'Only Positive Whole Numbers Required'
                        }
                    ]
                },
                {
                    'label': 'Effective Date',
                    'name': 'EFF_DT',
                    'type': 'date',
                    'required': true,
                    'value': 0,
                    'inputType': 'date',
                    'validations': [{
                        'name': 'required',
                        'validator': '',
                        'message': 'Effective Date Required'
                    }]
                },
                {
                    'name': 'files',
                    'property': 'files',
                    'visibleType': 'doc',
                    'type': 'fileInput',
                    'inputType': 'file',
                    'visible': true,
                    'editable': true,
                    'isModelProperty': true,
                    'validations': [
                        {
                            'name': 'required',
                            'validator': '',
                            'message': 'File Required'
                        }
                    ]
                },
                {
                    'label': 'Display order',
                    'name': 'NET_REV_POS_NBR',
                    'type': 'input',
                    'required': true,
                    'value': 0,
                    'inputType': 'number',
                    'validations': [
                        {
                            'name': 'required',
                            'validator': '',
                            'message': 'Display order Required'
                        },
                        {
                            'name': 'pattern',
                            'validator': '^$|^([0-9]|[1-9][0-9]|[1][0][0])?',
                            'message': 'Only Positive Numbers Required'
                        }
                    ]
                },
                {
                    'type': 'button',
                    'inputType': 'submit',
                    'styleColor': 'primary',
                    'styleClass': 'float-right',
                    'label': 'Add Setting'
                }
            ]
        }
    }
}
