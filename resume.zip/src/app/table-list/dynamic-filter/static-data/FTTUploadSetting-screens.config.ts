/*
 * SonarQube, open source software quality management tool.
 * Copyright (C) 2008-2013 SonarSource
 * mailto:contact AT sonarsource DOT com
 *
 * SonarQube is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or (at your option) any later version.
 *
 * SonarQube is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */


export class FTTUploadConfig {
    static config = {
        // 'title': 'FTT Upload Setings',
        // 'subTitle': 'Configure FTT Upload Types',
        // 'advancedFilterTitle': 'Filter Upload Settings',
        'screen': 'FTTUpload',
        'staticConfig': true,
        'filters': [
            {
                'field': 'CTRY_NM',
                'displayName': 'Country',
                'defaultValue': '',
                'type': 'dropdown',
                'values': [],
                'hierarchyRoot': true
            },
            {
                'field': 'CTRY_CD_NM',
                'displayName': 'Country Code',
                'defaultValue': '',
                'type': 'input',
                'disabled': true,
                'inputType': 'text',
                'hierarchyParent': 'CTRY_NM'
            },
            {
                'field': 'langName',
                'displayName': 'Languages',
                'defaultValueField': 0,
                'defaultValue': 0,
                'type': 'dropdown',
                'dynamicKVP': {
                    name: 'langNm',
                    value: 'ctryLangIdNbr'
                },
                'values': [],
                'hierarchyParent': 'CTRY_NM'
            },
            {
                'field': 'CURR_NM',
                'displayName': 'Currency Name',
                'defaultValue': '',
                'type': 'input',
                'disabled': true,
                'inputType': 'text',
                'hierarchyParent': 'CTRY_NM'
            },
            {
                'field': 'RateCategoryCode',
                'displayName': 'Rate category Code',
                'defaultValueField': '',
                'defaultValue': '',
                'type': 'input',
                'disabled': false,
                'hierarchyParent': 'CTRY_NM'
            },
            {
                'field': 'startDate',
                'displayName': 'Start Date',
                'defaultValueField': '',
                'defaultValue': '',
                'type': 'date',
                'disabled': false,
                'hierarchyParent': 'CTRY_NM'
            },
            {
                'field': 'File',
                'displayName': 'Choose File',
                'defaultValueField': '',
                'defaultValue': '',
                'type': 'file',
                'disabled': false,
                'hierarchyParent': 'CTRY_NM'
            }
        ],
        'ajaxUrls': {
            'update': 'uploadFTT',
            'add': 'uploadFTT',
            'delete': '',
            'init': {
                'countryDetails': {
                    'url': 'CountryDetails',
                    'filterFieldMap': {
                        'CTRY_NM': 'CTRY_NM'
                    },
                    'defaultRequest': {
                        'type': 'ALL'
                    },
                    'dynamicParam': null
                },
                'adminCountryDetails': {
                    'url': 'adminCountryDetails',
                    'storeToGlobal': true,
                    'filterFieldMap': {
                        'langNm': 'langNm'
                    },
                    'dynamicFieldMap': 'langName',
                    'defaultRequest': {
                        'type': 'GET'
                    },
                    'dynamicParam': {
                        'ctryCd': 'CTRY_CD_NM'
                    }
                },
                'url': null
            }
        }
    }
}
