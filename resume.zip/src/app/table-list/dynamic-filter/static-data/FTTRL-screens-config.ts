/*
 * SonarQube, open source software quality management tool.
 * Copyright (C) 2008-2013 SonarSource
 * mailto:contact AT sonarsource DOT com
 *
 * SonarQube is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or (at your option) any later version.
 *
 * SonarQube is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */


export class FTTRLConfig {
    static config = {
        'title': 'FTT Revenue Level Setings',
        'subTitle': 'Configure FTT Revenue Level Types',
        'advancedFilterTitle': 'Filter Tariff Types',
        'filters': [
            {
                'field': 'CTRY_NM',
                'displayName': 'Country',
                'defaultValue': '',
                'type': 'dropdown',
                'values': [],
                'hierarchyRoot': true
            },
            {
                'field': 'CTRY_CD_NM',
                'displayName': 'Country Code',
                'defaultValue': '',
                'type': 'input',
                'disabled': true,
                'inputType': 'text',
                'hierarchyParent': 'CTRY_NM'
            },
            {
                'field': 'services',
                'displayName': 'Services',
                'defaultValueField': 0,
                'defaultValue': 0,
                'type': 'dropdown',
                'dateDropDown': false,
                'disabled': false,
                'kvp': true,
                'values': [{
                    'name': 'All',
                    'value': 0
                }],
                // 'dynamicKVP': {
                //     name: 'SVC_NM',
                //     value: 'SVC_ID_NBR'
                // },
                // 'values': [{
                //     'SVC_NM': 'All',
                //     'SVC_ID_NBR': 0
                // }],
                'hierarchyParent': 'CTRY_NM'
            },
            {
                'field': 'availableDates',
                'displayName': 'Available Dates',
                'defaultValueField': 'currentDate',
                'defaultValue': '',
                'type': 'dropdown',
                'dateDropDown': true,
                'disabled': false,
                'hierarchyParent': 'CTRY_NM'
            }
        ],
        'ajaxUrls': {
            'defaultGet': {
                'url': 'revenueLevelDetails',
                'defaultParams': {
                    'type': 'GET'
                },
                'params': {
                    'CTRY_CD_NM': 'ctryCd',
                    'services': 'svcIdNbr',
                    'availableDates': 'effDate'
                }
            },
            'filterGet': {
                'url': 'revenueLevelDetails',
                'defaultParams': {
                    'type': 'GET'
                },
                'params': {
                    'CTRY_CD_NM': 'ctryCd',
                    'services': 'svcIdNbr',
                    'availableDates': 'effDate'
                }
            },
            'update': 'revenueLevelSetting',
            'add': 'revenueLevelSetting',
            'delete': 'deleteRevenueLevelSetting',
            'init': {
                'countryDetails': {
                    'url': 'CountryDetails',
                    'filterFieldMap': {
                        'CTRY_NM': 'CTRY_NM'
                    },
                    'defaultRequest': {
                        'type': 'ALL'
                    },
                    'dynamicParam': null
                },
                'availableDates': {
                    'url': 'revenueLevelDetailsAvailableDates',
                    'dynamicFieldMap': 'availableDates',
                    'filterFieldMap': {
                        'AVAILABLE_DATE_ARRAY': 'availableDates'
                    },
                    'defaultRequest': {
                        'type': 'GET'
                    },
                    'dynamicParam': {
                        'ctryCd': 'CTRY_CD_NM'
                    }
                },
                'closestDate': {
                    'url': 'closestRevenueLevelDetails',
                    'dynamicModelMap': {
                        'CLOSESTDATE': 'availableDates'
                    },
                    'defaultRequest': {
                        'type': 'GET'
                    },
                    'dynamicParam': {
                        'ctryCd': 'CTRY_CD_NM',
                        'inputValue': 'newOttFormatedDate'
                    }
                },
                'serviceDropDown': {
                    'url': 'serviceDropDown',
                    'dynamicFieldMap': 'services',
                    'storeToGlobal': true,
                    'defaultRequest': {
                        'type': 'GET'
                    },
                    'dynamicParam': {
                        'ctryCd': 'CTRY_CD_NM'
                    }
                },
                'url': null
            }
        },
        'crudConfig': {},
        'table': [
            {
                'name': 'ID',
                'property': 'id',
                'visibleType': 'id',
                'type': 'number',
                'inputType': 'text',
                'visible': false,
                'editable': false,
                'isModelProperty': true,
                'showEdit': false,
                'isPrimaryKey': true
            },
            {
                'name': 'Service',
                'property': 'serviceNm',
                'visibleType': 'serviceNm',
                'type': 'text',
                'inputType': 'text',
                'visible': true,
                'editable': false,
                'isModelProperty': true,
                'showEdit': false
            },
            {
                'name': 'Revenue Min',
                'property': 'minTrfRevAmt',
                'visibleType': 'minTrfRevAmt',
                'type': 'number',
                'inputType': 'text',
                'visible': true,
                'editable': true,
                'isModelProperty': true,
                'showEdit': true
            },
            {
                'name': 'Revenue Max',
                'property': 'maxTrfRevAmt',
                'visibleType': 'maxTrfRevAmt',
                'type': 'number',
                'inputType': 'text',
                'visible': true,
                'editable': true,
                'isModelProperty': true,
                'showEdit': false
            },
            {
                'name': 'Min Discount - Group 1',
                'property': 'minDiscGrp1Amt',
                'visibleType': 'minDiscGrp1Amt',
                'type': 'number',
                'inputType': 'text',
                'visible': true,
                'editable': true,
                'isModelProperty': true,
                'showEdit': true
            },
            {
                'name': 'Max Discount - Group 1',
                'property': 'maxDiscGrp1Amt',
                'visibleType': 'maxDiscGrp1Amt',
                'type': 'number',
                'inputType': 'text',
                'visible': true,
                'editable': true,
                'isModelProperty': true
            }, {
                'name': 'Increment - Group 1',
                'property': 'discInctGrp1Nbr',
                'visibleType': 'idiscInctGrp1Nbrnc',
                'type': 'number',
                'inputType': 'text',
                'visible': true,
                'editable': true,
                'isModelProperty': true
            },
            {
                'name': 'Mini Discount - Group 2',
                'property': 'minDiscGrp2Amt',
                'visibleType': 'minDiscGrp2Amt',
                'type': 'number',
                'inputType': 'text',
                'visible': true,
                'editable': true,
                'isModelProperty': true,
                'showEdit': true
            },
            {
                'name': 'Max Discount - Group 2',
                'property': 'maxDiscGrp2Amt',
                'visibleType': 'maxDiscGrp2Amt',
                'type': 'number',
                'inputType': 'text',
                'visible': true,
                'editable': true,
                'isModelProperty': true
            }, {
                'name': 'Increment - Group 2',
                'property': 'discInctGrp2Nbr',
                'visibleType': 'discInctGrp2Nbr',
                'type': 'number',
                'inputType': 'text',
                'visible': true,
                'editable': true,
                'isModelProperty': true
            }, {
                'name': 'Recommended Discount',
                'property': 'recDiscAmt',
                'visibleType': 'recDiscAmt',
                'type': 'number',
                'inputType': 'text',
                'visible': true,
                'editable': true,
                'isModelProperty': true
            },
            {
                'name': 'Effective Date',
                'property': 'effDt',
                'visibleType': 'effDt',
                'type': 'date',
                'visible': true,
                'editable': true,
                'isModelProperty': true
            },
            {
                'name': 'Country',
                'property': 'ctryCd',
                'visibleType': 'ctryCd',
                'type': 'dropdown',
                'utilFieldNm': 'countryCodeArr',
                'values': [],
                'visible': true,
                'editable': true,
                'isModelProperty': true,
                'showEdit': true
            }
        ],
        'createUpdateForm': {
            'name': 'Test',
            'submitUrl': '',
            'form_name': 'fttrl',
            'entity': 'fttrl',
            'fields': [
                {
                    'label': 'Country',
                    'name': 'countryCode',
                    'type': 'select',
                    'required': true,
                    'inputType': 'text',
                    'value': '',
                    'utilFieldNm': 'countryCodeArr',
                    'defaultValueRef': 'filteredCountryCode',
                    'options': [],
                    'validations': [
                        {
                            'name': 'required',
                            'validator': '',
                            'message': 'Country Required'
                        }
                    ]
                },
                {
                    'label': 'Service',
                    'name': 'svcIdNbr',
                    'type': 'select',
                    'required': true,
                    'inputType': 'text',
                    'utilFieldNm': 'services',
                    'defaultValueRef': '',
                    'options': [],
                    'values': '',
                    'validations': [
                        {
                            'name': 'required',
                            'validator': '',
                            'message': 'Service Name Required'
                        }
                    ]
                },
                {
                    'label': 'Revenue Min Amount',
                    'name': 'revMinAmt',
                    'type': 'input',
                    'value': 0,
                    'required': true,
                    'inputType': 'number',
                    'validations': [
                        {
                            'name': 'required',
                            'validator': '',
                            'message': 'Minimum Value Required'
                        },
                        {
                            'name': 'pattern',
                            'validator': '^[1-9]+[0-9]*$',
                            'message': 'Only Positive Whole Numbers Required'
                        }
                    ]
                },
                {
                    'label': 'Revenue Max Amount',
                    'name': 'revMaxAmt',
                    'type': 'input',
                    'required': true,
                    'value': 0,
                    'inputType': 'number',
                    'validations': [
                        {
                            'name': 'required',
                            'validator': '',
                            'message': 'Maximum Value Required'
                        },
                        {
                            'name': 'pattern',
                            'validator': '^[0-9]+[0-9]*$',
                            'message': 'Only Positive Whole Numbers Required'
                        }
                    ]
                },
                {
                    'label': 'Recommended Discount',
                    'name': 'recDiscAmt',
                    'type': 'input',
                    'required': true,
                    'value': 0,
                    'inputType': 'number',
                    'validations': [
                        {
                            'name': 'required',
                            'validator': '',
                            'message': 'Maximum Value Required'
                        },
                        {
                            'name': 'pattern',
                            'validator': '^[0-9]+[0-9]*$',
                            'message': 'Only Positive Whole Numbers Required'
                        }
                    ]
                },
                {
                    'label': 'Min Discount Group1 Amount',
                    'name': 'minDiscGrp1Amt',
                    'type': 'input',
                    'required': true,
                    'value': 0,
                    'inputType': 'number',
                    'validations': [
                        {
                            'name': 'required',
                            'validator': '',
                            'message': 'Maximum Value Required'
                        },
                        {
                            'name': 'pattern',
                            'validator': '^[0-9]+[0-9]*$',
                            'message': 'Only Positive Whole Numbers Required'
                        }
                    ]
                },
                {
                    'label': 'Max Discount Group1 Amount',
                    'name': 'maxDiscGrp1Amt',
                    'type': 'input',
                    'required': true,
                    'value': 0,
                    'inputType': 'number',
                    'validations': [
                        {
                            'name': 'required',
                            'validator': '',
                            'message': 'Maximum Value Required'
                        },
                        {
                            'name': 'pattern',
                            'validator': '^[0-9]+[0-9]*$',
                            'message': 'Only Positive Whole Numbers Required'
                        }
                    ]
                },
                {
                    'label': 'Increment Group1',
                    'name': 'discInctGrp1Nbr',
                    'type': 'input',
                    'required': true,
                    'value': 0,
                    'inputType': 'number',
                    'validations': [
                        {
                            'name': 'required',
                            'validator': '',
                            'message': 'Maximum Value Required'
                        },
                        {
                            'name': 'pattern',
                            'validator': '^[0-9]+[0-9]*$',
                            'message': 'Only Positive Whole Numbers Required'
                        }
                    ]
                },
                {
                    'label': 'Min Discount Group2 Amount',
                    'name': 'minDiscGrp2Amt',
                    'type': 'input',
                    'required': true,
                    'value': 0,
                    'inputType': 'number',
                    'validations': [
                        {
                            'name': 'pattern',
                            'validator': '^[0-9]+[0-9]*$',
                            'message': 'Only Positive Whole Numbers Required'
                        }
                    ]
                },
                {
                    'label': 'Max Discount Group2 Amount',
                    'name': 'maxDiscGrp2Amt',
                    'type': 'input',
                    'value': 0,
                    'inputType': 'number',
                    'validations': [
                        {
                            'name': 'pattern',
                            'validator': '^[0-9]+[0-9]*$',
                            'message': 'Only Positive Whole Numbers Required'
                        }
                    ]
                },
                {
                    'label': 'Increment Group2',
                    'name': 'discInctGrp2Nbr',
                    'type': 'input',
                    'required': true,
                    'value': 0,
                    'inputType': 'number',
                    'validations': [
                        {
                            'name': 'pattern',
                            'validator': '^[0-9]+[0-9]*$',
                            'message': 'Only Positive Whole Numbers Required'
                        }
                    ]
                },
                {
                    'label': 'Effective Date',
                    'name': 'effectiveDate',
                    'type': 'date',
                    'required': true,
                    'value': 0,
                    'inputType': 'date',
                    'validations': [
                        {
                            'name': 'required',
                            'validator': '',
                            'message': 'Effective Date Required'
                        }
                    ]
                },
                {
                    'type': 'button',
                    'styleColor': 'primary',
                    'styleClass': 'float-right',
                    'label': 'Add Setting'
                }
            ]
        }
    }
}