/*
 * SonarQube, open source software quality management tool.
 * Copyright (C) 2008-2013 SonarSource
 * mailto:contact AT sonarsource DOT com
 *
 * SonarQube is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or (at your option) any later version.
 *
 * SonarQube is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */


export class UAConfig {
    static config = {
        'title': 'Manage User Access',
        'subTitle': 'Configure User Access',
        'advancedFilterTitle': 'Filter Users',
        'noDateConfiguration': true,
        'clientFilter': true,
        'filters': [
            {
                'field': 'userId',
                'displayName': 'User ID/LDAP ID',
                'type': 'input',
                'inputType': 'number',
                'hierarchyRoot': true
            },
            {
                'displayName': 'Role Name',
                'field': 'roleNm',
                'defaultValueField': 0,
                'defaultValue': 0,
                'type': 'dropdown',
                'disabled': false,
                'kvp': true,
                'values': [
                    {
                        'value': 0,
                        'name': 'ALL'
                    },
                    {
                        'value': 'FTT_PRICING_EUROPE',
                        'name': 'Pricing Europe'
                    },
                    {
                        'value': 'Pricing HQ',
                        'name': 'Pricing HQ'
                    },
                    {
                        'value': 'Pricing Manager',
                        'name': 'Pricing Manager'
                    },
                    {
                        'value': 'Pricing MD',
                        'name': 'Pricing MD'
                    },
                    {
                        'value': 'Pricing User',
                        'name': 'Pricing User'
                    },
                    {
                        'value': 'Sales User',
                        'name': 'Sales User'
                    }
                ]
            }
        ],
        'isInlineEdit': true,
        'ajaxUrls': {
            'defaultGet': {
                'url': 'getUserAccessDetails',
                'defaultParams': {
                    'type': 'GET',
                    'userId': '0',
                    'roleNm': 'Sales User'
                },
                'params': {
                    'userId': 'userId'
                },
                'storeData': true
            },
            'filterGet': {
                'url': 'getUserAccessDetails',
                'defaultParams': {
                    'type': 'GET',
                    'userId': '0',
                    'roleNm': 'Sales User'
                },
                'params': {
                    'userId': 'userId',
                    'roleNm': 'roleNm'
                }
            },
            'update': 'UpdateUserDetails',
            'add': 'saveUser',
            'delete': 'removeUser',
            'init': {
                'countryDetails': {
                    'url': 'CountryDetails',
                    'filterFieldMap': {
                        'CTRY_NM': 'CTRY_NM'
                    },
                    'defaultRequest': {
                        'type': 'ALL'
                    },
                    'dynamicParam': null
                },
                'url': null
            }
        },
        'crudConfig': {},
        'table': [
            {
                'name': 'ID',
                'property': 'userId',
                'visibleType': 'userId',
                'type': 'number',
                'inputType': 'text',
                'visible': true,
                'editable': false,
                'isModelProperty': true,
                'showEdit': false,
                'isPrimaryKey': true
            },
            {
                'name': 'Name',
                'property': 'fullName',
                'visibleType': 'userId',
                'type': 'text',
                'inputType': 'text',
                'visible': true,
                'editable': false,
                'isModelProperty': true,
                'showEdit': false,
                'isPrimaryKey': false
            },
            {
                'name': 'ROLE',
                'property': 'roleNm',
                'visibleType': 'roleNm',
                'type': 'text',
                'inputType': 'text',
                'visible': true,
                'editable': false,
                'isModelProperty': true,
                'showEdit': false,
                'isPrimaryKey': true
            },
            {
                'name': 'Country',
                'property': 'countryList',
                'visibleType': 'countryList',
                'type': 'dropdown',
                'utilFieldNm': 'countryCodeArr',
                'multiSelect': true,
                'values': [],
                'visible': true,
                'editable': true,
                'isModelProperty': true,
                'showEdit': true
            }
        ],
        'createUpdateForm': {
            'name': 'Test',
            'submitUrl': '',
            'form_name': 'UA',
            'entity': 'UA',
            'fields': [
                {
                    'label': 'User Name',
                    'name': 'userName',
                    'type': 'input',
                    'required': true,
                    'inputType': 'text',
                    'value': '',
                    'validations': []
                },
                {
                    'label': 'User ID',
                    'name': 'userId',
                    'type': 'input',
                    'required': true,
                    'inputType': 'number',
                    'value': '',
                    'validations': [
                        {
                            'name': 'required',
                            'validator': '',
                            'message': 'UserID Required'
                        },
                        {
                            'name': 'pattern',
                            'validator': '^[1-9]+[0-9]*$',
                            'message': 'Only Positive Whole Numbers Required'
                        }
                    ]
                },
                {
                    'label': 'Accesible Countries',
                    'name': 'countryCodes',
                    'type': 'select',
                    'multiSelect': true,
                    'required': true,
                    'inputType': 'text',
                    'value': [],
                    'utilFieldNm': 'countryCodeArr',
                    'options': [],
                    'validations': [
                        {
                            'name': 'required',
                            'validator': '',
                            'message': 'Country Required'
                        }
                    ]
                },
                {
                    'label': 'Role Name',
                    'name': 'roleName',
                    'type': 'select',
                    'required': true,
                    'inputType': 'text',
                    'value': 'Sales User',
                    'options': [
                        {
                            'value': 'Sales User',
                            'name': 'Sales User'
                        },
                        {
                            'value': 'Pricing User',
                            'name': 'Pricing User'
                        },
                        {
                            'value': 'Pricing MD',
                            'name': 'Pricing MD'
                        },
                        {
                            'value': 'Pricing Manager',
                            'name': 'Pricing Manager'
                        },
                        {
                            'value': 'FTT_PRICING_EUROPE',
                            'name': 'Pricing Europe'
                        },
                        {
                            'value': 'Pricing HQ',
                            'name': 'Pricing HQ'
                        }
                    ],
                    'validations': [
                        {
                            'name': 'required',
                            'validator': '',
                            'message': 'Role Name Required'
                        }
                    ]
                },
                {
                    'type': 'button',
                    'inputType': 'submit',
                    'styleColor': 'primary',
                    'styleClass': 'float-right',
                    'label': 'Add User'
                }
            ]
        }
    }
}
