/*
 * SonarQube, open source software quality management tool.
 * Copyright (C) 2008-2013 SonarSource
 * mailto:contact AT sonarsource DOT com
 *
 * SonarQube is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or (at your option) any later version.
 *
 * SonarQube is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */


export class CRCConfig {
    static config = {
        'title': 'Contract Configuration',
        'subTitle': 'Configure Contract Templates',
        'advancedFilterTitle': 'Filter Contract Templates',
        'filters': [
            {
                'field': 'CTRY_NM',
                'displayName': 'Country',
                'defaultValue': '',
                'type': 'dropdown',
                'values': [],
                'hierarchyRoot': true
            },
            {
                'field': 'CTRY_CD_NM',
                'displayName': 'Country Code',
                'defaultValue': '',
                'type': 'input',
                'disabled': true,
                'inputType': 'text',
                'hierarchyParent': 'CTRY_NM'
            },
            {
                'field': 'CURR_CD_NM',
                'displayName': 'Currency',
                'defaultValue': '',
                'type': 'input',
                'disabled': true,
                'inputType': 'text',
                'hierarchyParent': 'CTRY_NM'
            },
            {
                'field': 'availableDates',
                'displayName': 'Available Dates',
                'defaultValueField': 'currentDate',
                'defaultValue': '',
                'type': 'dropdown',
                'dateDropDown': true,
                'disabled': false,
                'hierarchyParent': 'CTRY_NM'
            }
        ],
        'ajaxUrls': {
            'defaultGet': {
                'url': 'getTariffTypes',
                'defaultParams': {
                    'type': 'ALL'
                },
                'params': {
                    'CTRY_CD_NM': 'country',
                    'availableDates': 'startDate',
                    'tariffType': 'tariffType',
                    'typNm': 'typNm'
                }
            },
            'filterGet': {
                'url': 'getTariffTypes',
                'defaultParams': {
                    'type': 'ALL'
                },
                'params': {
                    'CTRY_CD_NM': 'country',
                    'availableDates': 'startDate',
                    'tariffType': 'tariffType',
                    'typNm': 'typNm'
                }
            },
            'update': 'saveTariffTypes',
            'add': 'saveTariffTypes',
            'delete': 'deleteThreshold',
            'init': {
                'countryDetails': {
                    'url': 'CountryDetails',
                    'filterFieldMap': {
                        'CTRY_NM': 'CTRY_NM'
                    },
                    'defaultRequest': {
                        'type': 'ALL'
                    },
                    'dynamicParam': null
                },
                'availableDates': {
                    'url': 'CountryTTSAvlDts',
                    'dynamicFieldMap': 'availableDates',
                    'filterFieldMap': {
                        'AVAILABLE_DATE_ARRAY': 'availableDates'
                    },
                    'defaultRequest': {
                        'type': 'GET'
                    },
                    'dynamicParam': {
                        'ctryCd': 'CTRY_CD_NM'
                    }
                },
                'closestDate': {
                    'url': 'TTSClosestDate',
                    'dynamicModelMap': {
                        'CLOSESTDATE': 'availableDates'
                    },
                    'defaultRequest': {
                        'type': 'GET'
                    },
                    'dynamicParam': {
                        'ctryCd': 'CTRY_CD_NM',
                        'inputValue': 'newOttFormatedDate'
                    }
                },
                'url': null
            }
        },
        'crudConfig': {},
        'table': [
            {
                'name': 'ID',
                'property': 'STD_TRF_DISC_ID_NBR',
                'visibleType': 'STD_TRF_DISC_ID_NBR',
                'type': 'number',
                'inputType': 'text',
                'visible': false,
                'editable': false,
                'isModelProperty': true,
                'showEdit': false,
                'isPrimaryKey': true
            },
            {
                'name': 'Document',
                'property': 'FILE_EXT_TYP_NM',
                'visibleType': 'doc',
                'type': 'file',
                'inputType': 'file',
                'visible': true,
                'editable': true,
                'isModelProperty': true
            },
            {
                'name': 'Effective Date',
                'property': 'EFF_DT',
                'visibleType': 'EFF_DT',
                'type': 'date',
                'visible': true,
                'editable': true,
                'isModelProperty': true
            },
            {
                'name': 'Country',
                'property': 'CTRY_CD_NM',
                'visibleType': 'countryCode',
                'type': 'dropdown',
                'utilFieldNm': 'countryCodeArr',
                'values': [],
                'visible': true,
                'editable': true,
                'isModelProperty': true,
                'showEdit': true
            }
        ],
        'createUpdateForm': {
            'name': 'Test',
            'submitUrl': '',
            'form_name': 'tts',
            'entity': 'tts',
            'fields': [
                {
                    'label': 'Country',
                    'name': 'CTRY_CD_NM',
                    'type': 'select',
                    'required': true,
                    'inputType': 'text',
                    'value': '',
                    'utilFieldNm': 'countryCodeArr',
                    'defaultValueRef': 'filteredCountryCode',
                    'options': [],
                    'validations': [
                        {
                            'name': 'required',
                            'validator': '',
                            'message': 'country Required'
                        }
                    ]
                },
                {
                    'label': 'Effective Date',
                    'name': 'EFF_DT',
                    'type': 'date',
                    'required': true,
                    'value': 0,
                    'inputType': 'date',
                    'validations': [{
                        'name': 'required',
                        'validator': '',
                        'message': 'Effective Date Required'
                    }]
                },
                {
                    'name': 'files',
                    'property': 'files',
                    'visibleType': 'doc',
                    'type': 'fileInput',
                    'inputType': 'file',
                    'visible': true,
                    'editable': true,
                    'isModelProperty': true,
                    'validations': [
                        {
                            'name': 'required',
                            'validator': '',
                            'message': 'File Required'
                        }
                    ]
                },
                {
                    'type': 'button',
                    'inputType': 'submit',
                    'styleColor': 'primary',
                    'styleClass': 'float-right',
                    'label': 'Add Setting'
                }
            ]
        }
    }
}
