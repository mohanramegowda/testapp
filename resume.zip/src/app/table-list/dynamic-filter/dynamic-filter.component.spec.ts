/*
 * SonarQube, open source software quality management tool.
 * Copyright (C) 2008-2013 SonarSource
 * mailto:contact AT sonarsource DOT com
 *
 * SonarQube is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or (at your option) any later version.
 *
 * SonarQube is distributed in the hope that it will be useful, * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { BrowserDynamicTestingModule, platformBrowserDynamicTesting } from '@angular/platform-browser-dynamic/testing';
import { DynamicFilterComponent } from './dynamic-filter.component';
import { Utility } from '../../common/Utility';
import { Observable } from 'rxjs';
import { CommonService } from 'app/common/common.service';


const response = new Observable(observer => {
  observer.next(LOginRes);
});

const LOginRes = {
  'userId': '3535076',
  'userFirstName': 'Roel',
  'userLastName': 'Roeloffzen',
  'countryCode': 'NL',
  'userEmail': 'roel.roeloffzen@tnt.com',
  'authroizes': {
    'CountryLevelTariffHistory,Approve': false,
    'OwnTariffHistory,Approve': false,
    'PricingMD,Allow': false,
    'SalesInput,Write': false,
    'PricingAnalyst,Allow': false,
    'AllTariffHistory,Approve': true,
    'PricingManager,Allow': false,
    'ApplicationLogin,Login': true,
    'PricingEurope,Allow': false,
    'PricingHQ,Allow': true
  }
}



xdescribe('DynamicFilterComponent', () => {
  let component: DynamicFilterComponent;
  let fixture: ComponentFixture<DynamicFilterComponent>;
  let dynamicModel = {};
  let commonService: CommonService;
  // let ottUtility: OttUtility;

  beforeEach(async(() => {
    TestBed.resetTestEnvironment();
    TestBed.initTestEnvironment(BrowserDynamicTestingModule,
      platformBrowserDynamicTesting());

    TestBed.configureTestingModule({
      declarations: [DynamicFilterComponent]
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DynamicFilterComponent);
    component = fixture.componentInstance;
    dynamicModel = component.dynamicModel;
    commonService = TestBed.get(CommonService);
    console.log(JSON.parse(JSON.stringify(component)));
    fixture.detectChanges();
  });

  it('should create the app', () => {
    expect(component).toBeTruthy();
    // expect(OttUtility.urlParams).toBeUndefined();
  });

});
