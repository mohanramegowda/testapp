/*
 * SonarQube, open source software quality management tool.
 * Copyright (C) 2008-2013 SonarSource
 * mailto:contact AT sonarsource DOT com
 *
 * SonarQube is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or (at your option) any later version.
 *
 * SonarQube is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */


import { Component, OnInit, Input, OnChanges } from '@angular/core';
import { CommonService } from '../../common/common.service';
import { Utility } from '../../common/Utility';
import { DynamicFilterService } from './dynamic-filter.service';
import { AppDateAdapter, APP_DATE_FORMATS } from 'app/common/customDatePicker';
import { DateAdapter, MAT_DATE_FORMATS } from '@angular/material';


@Component({
  selector: 'app-dynamic-filter',
  templateUrl: './dynamic-filter.component.html',
  styleUrls: ['./dynamic-filter.component.css'],
  providers: [
    {
      provide: DateAdapter, useClass: AppDateAdapter
    },
    {
      provide: MAT_DATE_FORMATS, useValue: APP_DATE_FORMATS
    }]
})
export class DynamicFilterComponent implements OnInit, OnChanges {


  @Input() initConfig: any;
  @Input() config: any;

  isFilterEx = true;
  filterValues = {};
  tableNames = [];
  filterFieldMap = {};
  filterFieldArr = [];

  dynamicModel = {};
  workingConfig: any = {};
  workingFilterFieldMap: any = {};
  workingFilterFieldArr: any = [];

  component: any;

  dynamicHierarchy: any = {};
  dynamicFlatMap: any = {};
  dynamicEvents: any = {};
  loggedInCountryCode = '';

  countryNameDetailsMap = {};
  countryIdDetailsMap = {};
  countryCodeDetailsMap = {};
  countryFlatArr = [];

  avlDtsCntryNmeMap = {};
  avlDtsCntryCdMap = {};
  avlDtsCntryIdMap = {};
  profileConfigName: any;
  enableFilter = true;
  // TODO: Remove this
  currentCountryNm = '';
  currentCountryVal = {};
  countrySelected: any;
  languageList: any;
  langNameNew: any;
  ctrNm: any;
  hello: void;
  displayScreen: any;
  createRow: any;
  name: any;
  screenConfig: any;
  constructor(private commonService: CommonService, private dynamicFilterService: DynamicFilterService) {
    this.component = this;
    this.loggedInCountryCode = (Utility.userDetails && Utility.userDetails.countryCode) ?
    Utility.userDetails.countryCode : '';
    this.dynamicModel['ottFormatedDate'] = this.commonService.formatDateTime(new Date(), 'DD/MM/YYYY');
    this.dynamicModel['loggedInCountryCode'] = this.loggedInCountryCode;
    this.initFilterScreen();
  }

  ngOnInit() {

  }

  ngOnChanges() {
    this.initFilterScreen();
  }
  initFilterScreen() {
    if (!this.config) {
      return;
    }
    this.filterFieldMap = [];
    this.filterFieldArr = [];
    const fieldMap = this.filterFieldMap;
    const fieldArr = this.filterFieldArr;
    if (this.config.filters) {
      this.enableFilter = true;
      this.config.filters.map(function (cfg) {
        fieldMap[cfg.field] = cfg;
        fieldArr.push(cfg);
      });
    } else {
      this.enableFilter = false;
    }
    this.workingFilterFieldMap = JSON.parse(JSON.stringify(this.filterFieldMap)); // Deep Copy
    console.log(this.workingFilterFieldMap);
    this.workingConfig = JSON.parse(JSON.stringify(this.config)); // Deep Copy    
    this.workingFilterFieldArr = JSON.parse(JSON.stringify(this.filterFieldArr));
    this.displayScreen = this.workingConfig.screen;
    // if (this.config.eventConfig) {
    //   try {
    //     for (const i in this.config.eventConfig) {
    //       if (this.config.eventConfig[i]) {
    //         this.dynamicEvents[i] = this.config.eventConfig[i];
    //       }
    //     }
    //   } catch (e) {
    //     console.log(e);
    //   }
    // }
    this.getInitialData();
  }

  resetFilters() {
    this.getInitialData();
  }

  onSectionChange($event, filter) { // NOTE: Called if any changes in current Dynamic filters
    this.countrySelected = $event;
    let isUpdate = false;
    if (!$event && !filter) {
      if (!this.currentCountryNm) {
        this.getAvailableDates(false, true);
        if (this.config.noDateConfiguration) {
          this.filterData();
        }
        return;
      } else {
        isUpdate = true;
        $event = this.currentCountryNm;
        filter = this.currentCountryVal;
      }
    }
    if (filter.hierarchyRoot && this.dynamicHierarchy[filter.field]
      && this.dynamicHierarchy[filter.field][$event] && !isUpdate) {
      const filteredObj = this.dynamicHierarchy[filter.field][$event];
      for (const i in filteredObj) {
        if (filteredObj[i] && this.filterFieldMap[i]) {
          if (this.filterFieldMap[i].type === 'dropdown' && this.filterFieldMap[i].field !== filter.field) {
            this.filterFieldMap[i].values = filteredObj[i];
            if (this.filterFieldMap[i].defaultValueField) {
              this.dynamicModel[i] = filteredObj[this.filterFieldMap[i].defaultValueField];
            } else if (this.filterFieldMap[i].defaultValue) {
              this.dynamicModel[i] = filteredObj.defaultValue;
            }
          } else {
            this.dynamicModel[i] = filteredObj[i];
          }
        }
      }
      this.getAvailableDates(true, isUpdate);
    }
    // else if (this.dynamicHierarchy[filter.field]) {
    //   this.dynamicHierarchy[filter.field] = [$event];
    // }
    if (filter.field === 'CTRY_NM') {
      this.currentCountryNm = $event;
      this.currentCountryVal = filter;
      if (!isUpdate) {
        this.dynamicModel['availableDates'] = '';
        if (this.filterFieldMap['availableDates']) {
          this.filterFieldMap['availableDates'].values = [];
        }
      }
      Utility.commonStaticObject.languageName = $event;
      this.dynamicModel['adminCountryDetails'] = $event;
      if (filter.hierarchyRoot === true) {
        this.getAdditionalFilters()
      }
      const countryCode = this.countryNameDetailsMap[$event].CTRY_CD_NM;
      Utility.commonStaticObject.filteredCountryCode = this.countryNameDetailsMap[$event].CTRY_CD_NM;
    }
    if (filter.field === 'availableDates') { // NOTE: To change the effective date in the create form
      Utility.commonStaticObject.filteredAvailableDates = $event;
      this.dynamicModel['availableDates'] = $event;
      if (filter.hierarchyRoot === true) {
        this.getAdditionalFilters()
      }
    }
    // if (filter.field === 'langName') { // NOTE: To change the effective date in the create form
    //   OttUtility.commonStaticObject.languageName = $event;
    //   this.dynamicModel['adminCountryDetails'] = $event;
    //   if (filter.hierarchyRoot === true) {
    //     this.getAdditionalFilters()
    //   }
    // }
  }

  filterData(filterType = null) {
    let filterURL;
    if (filterType && filterType === 'init') {
      filterURL = 'defaultGet'
    } else {
      filterURL = 'filterGet'
    }
    const filterObj = this.config.ajaxUrls[filterURL];
    if (filterObj && filterObj.url &&
      Utility.urlParams[filterObj.url]) {
      let request: any = filterObj.defaultParams || {};
      if (filterObj.params) {
        for (const i in filterObj.params) {
          if (filterObj.params[i]) {
            request[filterObj.params[i]] = this.dynamicModel[i];
            if ([undefined, null].indexOf(this.dynamicModel[i]) > -1) {
              if (i === 'userId') {
                request[filterObj.params[i]] = 0;
              }
            }
          } else {
            request[i] = null;
          }
        }
      } else {
        request = this.dynamicModel;
      }
      if (filterObj.beforeFilter && this.dynamicFilterService.beforeFilterObject[this.config.screen]) {
        request = this.dynamicFilterService.beforeFilterObject[this.config.screen](this, request);
      }
      if (this.config.clientFilter && filterURL === 'filterGet') {
        let clientFilterData = JSON.parse(JSON.stringify(Utility.commonStaticObject[this.config.ajaxUrls[filterURL].url]));
        for (const i in request) {
          if (request[i] && ['type'].indexOf(i) === -1) {
            clientFilterData = clientFilterData.filter((ele) => {
              if (ele[i]) {
                // tslint:disable-next-line: triple-equals
                return ele[i] == request[i]
              } else {
                return true;
              }
            });
          }
        }
        if (clientFilterData && clientFilterData.length === 0) {
          this.commonService.showNotifier('No Data found!', 'warning');
        }
        this.commonService.updateFilteredResults(clientFilterData);
      } else {
        const url = Utility.urlParams[this.config.ajaxUrls[filterURL].url].url;
        const type = Utility.urlParams[this.config.ajaxUrls[filterURL].url].type;
        this.commonService.getAPIResponse(url, request, type)
          .subscribe((data: any) => {
            if (!data) {
              return;
            }
            if (data && data.status === 'EXCEPTION') {
              this.commonService.showNotifier(data.message, 'error');
              return;
            }
            if (data && data.length === 0) {
              this.commonService.showNotifier('No Data Found!', 'warning');
            }
            if (this.config.ajaxUrls[filterURL].storeData) {
              Utility.commonStaticObject[this.config.ajaxUrls[filterURL].url] = data;
            }
            this.commonService.updateFilteredResults(data);
          }, (error) => {
            console.log(error);
            this.commonService.showNotifier('An error occurred while filtering data.', 'error');
          })
      }
    } else {
      this.commonService.showNotifier('Filter config is incorrect!', 'error');
    }
  }

  getInitialData() {
    this.initializeScreen();
    const countryCodeDetailsMap = this.countryCodeDetailsMap = {};
    const countryFlatArr = this.countryFlatArr = [];
    const countryIdDetailsMap = this.countryIdDetailsMap = {};
    const countryNameDetailsMap = this.countryNameDetailsMap = {};
    if (this.config && this.config.ajaxUrls && this.config.ajaxUrls.init) {
      if (this.config.ajaxUrls && this.config.ajaxUrls.init.countryDetails) {
        const url = Utility.urlParams[this.config.ajaxUrls.init.countryDetails.url].url;
        const type = Utility.urlParams[this.config.ajaxUrls.init.countryDetails.url].type;
        const request = this.config.ajaxUrls.init.countryDetails.defaultRequest || null;
        const loggedInCountryCode = this.loggedInCountryCode;
        const dynamicModel = this.dynamicModel;
        this.commonService.getAPIResponse(url, request, type).subscribe((data) => {
          if (data && data.length > 0) {
            Utility.commonStaticObject.countryCodeArr = [];
            data.map((country) => {
              countryCodeDetailsMap[country.CTRY_CD_NM] = country;
              countryFlatArr.push(country);
              countryIdDetailsMap[country.CTRY_ID_NBR] = country;
              countryNameDetailsMap[country.CTRY_NM] = country;
              if (!Utility.commonStaticObject.countryNameDetailsMap) {
                Utility.commonStaticObject.countryNameDetailsMap = {};
              }
              if (!Utility.commonStaticObject.countryCodeArr) {
                Utility.commonStaticObject.countryCodeArr = [];
              }
              Utility.commonStaticObject.countryCodeArr.push({ value: country.CTRY_CD_NM, name: country.CTRY_NM });
              Utility.commonStaticObject.countryNameDetailsMap[country.CTRY_NM] = country;
              if ((country.CTRY_CD_NM === loggedInCountryCode)) {
                dynamicModel['CTRY_NM'] = country.CTRY_NM;
                dynamicModel['CTRY_CD_NM'] = country.CTRY_CD_NM;
                dynamicModel['CURR_CD_NM'] = country.CURR_CD_NM;
                dynamicModel['CURR_NM'] = country.CURR_NM;
                dynamicModel['RateCategoryCode'] = country.RateCategoryCode;

                Utility.commonStaticObject.filteredCountryCode = country.CTRY_CD_NM;
              }
            });
            this.dynamicHierarchy['CTRY_NM'] = countryNameDetailsMap;
            if (this.filterFieldMap['CTRY_NM']) {
              this.filterFieldMap['CTRY_NM'].values = Object.keys(countryNameDetailsMap);
            }


            if (this.config.ajaxUrls.init.availableDates) {
              this.avlDtsCntryNmeMap = {};
              this.avlDtsCntryCdMap = {};
              this.avlDtsCntryIdMap = {};
              this.getAvailableDates(true);
            } else {
              if (this.config.noDateConfiguration) {
                this.filterData('init');
              } else if (this.config.staticConfig) {
                this.getAdditionalFilters();
              } else {
                this.commonService.showNotifier('No Available Dates Configured!', 'warning');
              }
            }
          } else {
            this.commonService.showNotifier('No Country Level Details Found!', 'error');
          }
        }, (error) => {
          console.log(error);
          this.commonService.showNotifier('An error occurred while getting filters.', 'error');
        });
      } else {
        this.commonService.showNotifier('No Country Level Details Found!', 'warning');
      }
    }



  }



  getAvailableDates(isInit = false, isUpdate = false) {
    if (this.config.ajaxUrls.init.availableDates) {
      const url = Utility.urlParams[this.config.ajaxUrls.init.availableDates.url].url;
      const type = Utility.urlParams[this.config.ajaxUrls.init.availableDates.url].type;
      const request = this.config.ajaxUrls.init.availableDates.defaultRequest || null;
      const paramCountryCode = this.dynamicModel['CTRY_CD_NM'];
      if (this.config.ajaxUrls.init.availableDates.dynamicParam) {
        const params = this.config.ajaxUrls.init.availableDates.dynamicParam;
        for (const i in params) {
          if (params[i]) {
            request[i] = this.dynamicModel[params[i]];
          }
        }
      }
      this.commonService.getAPIResponse(url, request, type).subscribe((availableDateData: any) => {
        if (availableDateData && availableDateData.length > 0 &&
          availableDateData[0].AVAILABLE_DATE_ARRAY && availableDateData[0].AVAILABLE_DATE_ARRAY.length > 0) {
          this.avlDtsCntryNmeMap[this.countryCodeDetailsMap[paramCountryCode].CTRY_NM] = availableDateData[0].AVAILABLE_DATE_ARRAY;
          this.avlDtsCntryCdMap[paramCountryCode] = availableDateData[0].AVAILABLE_DATE_ARRAY;
          this.avlDtsCntryIdMap[this.countryCodeDetailsMap[paramCountryCode].CTRY_ID_NBR] = availableDateData[0].AVAILABLE_DATE_ARRAY;
          const availableDates = this.config.ajaxUrls.init.availableDates.dynamicFieldMap;
          // if (availableDates.storeToGlobal) {
          //   OttUtility.commonStaticObject[availableDates] = JSON.parse(JSON.stringify(availableDateData));
          //   console.log(OttUtility.commonStaticObject[availableDates]);
          // }
          // if (this.filterFieldMap[availableDates]) {
          //   this.filterFieldMap[availableDates].values = [...this.filterFieldMap[availableDates].values, ...availableDateData];
          // }
          const existingDate = this.dynamicModel[availableDates];
          if (this.filterFieldMap[availableDates]) {
            this.filterFieldMap[availableDates].values = availableDateData[0].AVAILABLE_DATE_ARRAY;
          }
          if (this.config.ajaxUrls.init.closestDate) {
            if (isUpdate && availableDateData[0].AVAILABLE_DATE_ARRAY
              && availableDateData[0].AVAILABLE_DATE_ARRAY.indexOf(existingDate) === -1) {
              isUpdate = false;
              isInit = true;
            }
            if (isUpdate) {
              this.dynamicModel[availableDates] = existingDate;
              this.filterData();
            } else {
              this.dynamicModel[availableDates] = availableDateData[0].AVAILABLE_DATE_ARRAY;
              // this.dynamicModel['availableDates'] = '';
              this.getClosestDate(isInit);
            }
          } else {
            this.commonService.showNotifier('No Closest Date Configured!', 'warning');
          }
        } else {
          this.commonService.showNotifier('No Available Dates found!', 'error');
        }
      });


    }
  }

  getClosestDate(isInit = false) {
    const url = Utility.urlParams[this.config.ajaxUrls.init.closestDate.url].url;
    const type = Utility.urlParams[this.config.ajaxUrls.init.closestDate.url].type;
    const request = this.config.ajaxUrls.init.closestDate.defaultRequest || null;
    if (this.config.ajaxUrls.init.closestDate.dynamicParam) {
      const params = this.config.ajaxUrls.init.closestDate.dynamicParam;
      for (const i in params) {
        if (params[i]) {
          request[i] = this.dynamicModel[params[i]];
        }
      }
    }
    this.commonService.getAPIResponse(url, request, type).subscribe((closestData: any) => {
      if (closestData && closestData.length > 0) {
        this.dynamicModel['availableDates'] = closestData[0].CLOSESTDATE;
        Utility.commonStaticObject.filteredAvailableDates = closestData[0].CLOSESTDATE;
        if (isInit) {
          this.getAdditionalFilters();
        }
      } else {
        this.commonService.showNotifier('No Closest Date found!', 'error');
      }
    });
  }
  // NOTE: To get additional filter options in dynamic filters (Other than 'countryDetails', 'availableDates', 'closestDate')
  getAdditionalFilters() {
    if (this.config && this.config.ajaxUrls && this.config.ajaxUrls.init) {
      Object.keys(this.config.ajaxUrls.init).map((call) => {
        const fieldconf = this.config.ajaxUrls.init[call];
        if (!['countryDetails', 'availableDates', 'closestDate'].includes(call) && fieldconf) {
          const url = Utility.urlParams[fieldconf.url].url;
          const type = Utility.urlParams[fieldconf.url].type;
          const request = fieldconf.defaultRequest || null;
          if (fieldconf.dynamicParam) {
            const params = fieldconf.dynamicParam;
            for (const i in params) {
              if (params[i]) {
                request[i] = this.dynamicModel[params[i]];
              }
            }
          }
          this.commonService.getAPIResponse(url, request, type).subscribe((data) => {
            // console.log(data);
            // data.forEach(element=>{
            //      console.log(element.languages);
            //     //  element.languages.forEach(element=>{
            //     //    console.log(element.langNm);
            //     //    this.langNameNew = element.langNm;
            //     //    console.log(this.langNameNew);
            //     //  });

            // });
            if (fieldconf.dynamicFieldMap) {
              const fieldname = fieldconf.dynamicFieldMap;
              // this.dynamicModel[fieldname] = this.filterFieldMap[fieldname].defaultValue;
              if (fieldconf.storeToGlobal) {
                Utility.commonStaticObject[fieldname] = JSON.parse(JSON.stringify(data));
              }
              if (fieldname === 'langName') {
                let languages = data.filter((filterLangValue) => {
                  return filterLangValue.countryName === this.dynamicModel['CTRY_NM'];
                });
                languages = languages[0].languages;
                this.filterFieldMap[fieldname].values = languages;
                this.dynamicModel[fieldname] = languages[0].ctryLangIdNbr;
              } else if (this.filterFieldMap[fieldname]) {
                this.filterFieldMap[fieldname].values = [...[{
                  'name': 'All',
                  'value': 0
                }], ...data];
              }

            }
          });
        }
      });
      if (!this.config.staticConfig) {
        this.filterData();
      }
    }
  }

  formatDate(date) {
    return this.commonService.formatDateTime(new Date(date), 'DD/MM/YYYY');
  }

  initializeScreen() {
    for (const i in this.filterFieldMap) {
      if (this.filterFieldMap[i]) {
        this.dynamicModel[this.filterFieldMap[i].field] = this.filterFieldMap[i].defaultValue;
      }
    }
    this.dynamicModel['ottFormatedDate'] = this.commonService.formatDateTime(new Date(), 'DD/MM/YYYY');
    this.dynamicModel['newOttFormatedDate'] = this.commonService.formatDateTime(new Date(), 'YYYY-MM-DDThh:mm:ss');
    this.dynamicModel['loggedInCountryCode'] = this.loggedInCountryCode;
  }

  uploadData() {
    if (this.dynamicModel['RateCategoryCode'] === undefined) {
      this.commonService.showNotifier('Rate Category Code cannot be empty', 'error');
    }
    const request = {
      ctryIdNbr: Utility.countryIdCodeMap.CTRY_ID_NBR,
      // startDate:;
    }
    const url = Utility.urlParams.uploadFTT.url;
    const type = Utility.urlParams.uploadFTT.type;
    this.commonService.getAPIResponse(url, request, type).subscribe((response: any) => {
      console.log(response);
      if (response && response.status === 'EXCEPTION') {
        if (response.message) {
          if (response.message.indexOf('No records found for criteria') > -1) {
            this.commonService.showNotifier('No records found ', 'error');
          } else {
            this.commonService.showNotifier(response.message, 'error');
          }
        } else {
          this.commonService.showNotifier('Error occurred while getting data.', 'error');
        }
        return;
      }

    })
  }

  fileSelected(files: any) {
   files = files[0];
  }
}
