/*
 * SonarQube, open source software quality management tool.
 * Copyright (C) 2008-2013 SonarSource
 * mailto:contact AT sonarsource DOT com
 *
 * SonarQube is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or (at your option) any later version.
 *
 * SonarQube is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */


import { Injectable } from '@angular/core';
import { Utility } from 'app/common/Utility';
import { CommonService } from 'app/common/common.service';
import { Jsonp } from '@angular/http';
@Injectable()
export class DynamicFilterService {
    beforeFilterObject = {
        'TTS': (component, params) => {
        },
        'STS': (component, params) => {
        },
        'FTT': (component, params) => { },
        'PTS': (component, params) => { },
        'UA': (component, params) => {
        },
        'FTTDISC': (component, params) => {
            const request = JSON.parse(JSON.stringify(params));
            if (request && component && component.filterFieldMap && component.filterFieldMap.weightLevels) {
                component.filterFieldMap.weightLevels.values.map((ele) => {
                    if (request.wgtLblId === ele.value) {
                        request['svcIdNbr'] = ele.svcIdNbr;
                    }
                });
                if (!request['svcIdNbr']) {
                    request.svcIdNbr = 0;
                }
            }
            return request
        },
        'FTTRL': (component, params) => { },
        'FTTWL': (component, params) => { },
        'FTTUploadConfig': (component, params) => { }
    }
    constructor(private commonService: CommonService) { }
}
