import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { CommonService } from 'app/common/common.service';

@Component({
  selector: 'app-add-comment',
  templateUrl: './add-comment.component.html',
  styleUrls: ['./add-comment.component.scss']
})
export class AddCommentComponent implements OnInit {

  @Input() commentsList;
  @Input() hideDelete;
  @Output() onAddComment: EventEmitter<any> = new EventEmitter<any>();
  @Output() onRemoveComment: EventEmitter<any> = new EventEmitter<any>();
  comment = '';

  constructor(private commonService: CommonService) { }

  ngOnInit() { }

  gridChangeFormatDateTime(dateTime) {
    return this.commonService.formatDateTime(new Date(dateTime), 'DD/MM/YYYY HH:mm:ss');
  }

  addComment() {
    if (!this.comment) {
      this.commonService.showNotifier('Please add a comment.', 'error');
      return;
    }
    if (this.comment) {
      this.onAddComment.emit(this.comment);
    }
    this.comment = '';
  }

  removeComment(index: number, comment) {
    this.onRemoveComment.emit({ index: index, comment: comment })
  }
}
