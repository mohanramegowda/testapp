import { TestBed } from '@angular/core/testing';
import { HttpHandler } from '@angular/common/http';
import { HttpRequest } from '@angular/common/http';
import { Router } from '@angular/router';
import { PendingInterceptorService } from './pending-interceptor.service';
describe('PendingInterceptorService', () => {
  let service: PendingInterceptorService;
  beforeEach(() => {
    const httpHandlerStub = { handle: customRequest => ({ pipe: () => ({}) }) };
    const httpRequestStub = { clone: object => ({}), url: {} };
    const routerStub = { events: { subscribe: () => ({}) } };
    TestBed.configureTestingModule({
      providers: [
        PendingInterceptorService,
        { provide: HttpHandler, useValue: httpHandlerStub },
        { provide: HttpRequest, useValue: httpRequestStub },
        { provide: Router, useValue: routerStub }
      ]
    });
    service = TestBed.get(PendingInterceptorService);
  });
  it('can load instance', () => {
    expect(service).toBeTruthy();
  });
  describe('intercept', () => {
    it('makes expected calls', () => {
      const httpHandlerStub: HttpHandler = TestBed.get(HttpHandler);
      const httpRequestStub = TestBed.get(HttpRequest);
      spyOn(httpHandlerStub, 'handle').and.callThrough();
      spyOn(httpRequestStub, 'clone').and.callThrough();
      service.intercept(httpRequestStub, httpHandlerStub);
      expect(httpHandlerStub.handle).toHaveBeenCalled();
      expect(httpRequestStub.clone).toHaveBeenCalled();
    });
  });
});
