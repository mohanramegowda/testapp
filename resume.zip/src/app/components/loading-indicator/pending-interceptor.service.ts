/*
 * SonarQube, open source software quality management tool.
 * Copyright (C) 2008-2013 SonarSource
 * mailto:contact AT sonarsource DOT com
 *
 * SonarQube is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or (at your option) any later version.
 *
 * SonarQube is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */


import { HttpEvent, HttpHandler, HttpInterceptor, HttpRequest } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { NavigationCancel, NavigationEnd, NavigationError, NavigationStart, Router } from '@angular/router';
import { Observable } from 'rxjs/internal/Observable';
import { throwError } from 'rxjs/internal/observable/throwError';
import { ReplaySubject } from 'rxjs/internal/ReplaySubject';
import { catchError, finalize, map } from 'rxjs/operators';
import { Utility } from 'app/common/Utility';
import { environment } from '../../../environments/environment';

@Injectable()
export class PendingInterceptorService implements HttpInterceptor {
  private _pendingRequests = 0;

  get pendingRequests(): number {
    return this._pendingRequests;
  }

  private _pendingRequestsStatus: ReplaySubject<boolean> = new ReplaySubject<boolean>(1);

  get pendingRequestsStatus(): Observable<boolean> {
    return this._pendingRequestsStatus.asObservable();
  }

  private _filteredUrlPatterns: RegExp[] = [];

  get filteredUrlPatterns(): RegExp[] {
    return this._filteredUrlPatterns;
  }

  constructor(router: Router) {
    router.events.subscribe(event => {
      if (event instanceof NavigationStart) {
        this._pendingRequestsStatus.next(true);
      }

      if ((event instanceof NavigationError || event instanceof NavigationEnd || event instanceof NavigationCancel)) {
        this._pendingRequestsStatus.next(false);
      }
    });
  }

  setPendingRequest() {
    this._pendingRequestsStatus.next(true);
  }

  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    const headerOpt: any = {
      'LDAP': (Utility.userDetails.userId) ? Utility.userDetails.userId : '',
      'USER_ROLE': (Utility.roleActions.roleName) ? Utility.roleActions.roleName : '',
      'Cache-Control': 'Cache-Control',
      'Pragma': 'no-cache'
    };
    if (Utility.isVpn && Utility.isLocal && environment.vpnConfig) {
      headerOpt['Çookie'] = environment.vpnConfig.Cookie;
      headerOpt['Accpet'] = 'application/json, text/plain, */*';
      headerOpt['Content-Type'] = 'application/json';
    }
    const customRequest = req.clone({
      setHeaders: headerOpt
    })
    const shouldBypass = this.shouldBypass(req.url);
    if (!shouldBypass) {
      this._pendingRequests++;

      this._pendingRequestsStatus.next(true);
    }

    return next.handle(customRequest).pipe(
      map((event: any) => {
        return event;
      }),
      catchError(error => {
        return throwError(error);
      }),
      finalize(() => {
        if (!shouldBypass) {
          this._pendingRequests--;

          if (0 === this._pendingRequests) {
            this._pendingRequestsStatus.next(false);
          }
        }
      })
    );
  }

  private shouldBypass(url: string): boolean {
    return this._filteredUrlPatterns.some(e => {
      return e.test(url);
    });
  }
}

export function PendingInterceptorServiceFactory(router: Router) {
  return new PendingInterceptorService(router);
}

export let PendingInterceptorServiceFactoryProvider = {
  provide: PendingInterceptorService,
  useFactory: PendingInterceptorServiceFactory,
  deps: [Router]
};
