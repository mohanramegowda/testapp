import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { SelectComponent } from './select.component';
import { FormGroup, FormGroupDirective } from '@angular/forms';
describe('SelectComponent', () => {
  let component: SelectComponent;
  let fixture: ComponentFixture<SelectComponent>;
  beforeEach(() => {
    const formGroupStub = {
      controls: {},
      get: field => ({ markAsTouched: () => ({}) })
    };
    const FormGroupDirectiveStub = {
      controls: {},
      get: field => ({ markAsTouched: () => ({}) })
    };
    TestBed.configureTestingModule({
      schemas: [NO_ERRORS_SCHEMA],
      declarations: [SelectComponent],
      providers: [
        { provide: FormGroup, useValue: formGroupStub },
        { provide: FormGroupDirective, useValue: FormGroupDirectiveStub }]
    });
    fixture = TestBed.createComponent(SelectComponent);
    component = fixture.componentInstance;
  });
  it('can load instance', () => {
    expect(component).toBeTruthy();
  });
});
