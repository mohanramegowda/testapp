/*
 * SonarQube, open source software quality management tool.
 * Copyright (C) 2008-2013 SonarSource
 * mailto:contact AT sonarsource DOT com
 *
 * SonarQube is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or (at your option) any later version.
 *
 * SonarQube is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */


import { Component, OnInit, OnChanges, SimpleChanges } from '@angular/core';
import { FormGroup, FormGroupDirective, FormControl } from '@angular/forms';
import { FieldConfig, CustomStyle } from '../field.interface';
declare var $: any;

@Component({
    selector: 'app-dynamic-select',
    template: `
<div [class]="(selectStyle && selectStyle.selectMainDiv) ? selectStyle.selectMainDiv : 'fdx-c-form-group fdx-c-form-group--select fdx-c-form-group--float-label'">
    <span [class]="(selectStyle && selectStyle.selectSubDiv) ? selectStyle.selectSubDiv :'fdx-c-form-group__item'">
        <select id="{{field.styleId}}" [class]="(selectStyle && selectStyle.selectOption) ? selectStyle.selectOption : 'fdx-c-form-group__select'" name="carlist" id="dropdown" class="dropdown-options-purple" [required]="required"
        [formControl]="control">
            <option *ngFor="let item of field.options" [value]="item.value">{{item.name}}</option>
        </select>
      <mat-icon>
            <svg class="fdx-c-icon" aria-hidden="true" focusable="false" role="presentation">
                <use xlink:href="#chevron"></use>
            </svg>
      </mat-icon>
      <label [class]="(selectStyle && selectStyle.selectLabel) ? selectStyle.selectLabel : 'fdx-c-form-group__label'" for="INPUT">{{field.label}}</label>
    </span>

    <div role="alert" id="alertID" class="fdx-c-form-group__message fdx-c-form-group__message--has-message"
    *ngFor="let validation of field?.validations;">
        <span *ngIf="control.touched && control.hasError(validation.name)">{{validation.message}}</span>
    </div>
</div>
`,
    styles: []
})
export class SelectComponent implements OnInit, OnChanges {
    field: FieldConfig;
    group: FormGroup;
    control: FormControl;
    required: boolean;
    customStyle: CustomStyle;
    selectStyle: any;
    constructor(private formGroupDir: FormGroupDirective) { }

    ngOnChanges(changes: SimpleChanges) {
        if(changes.customStyle && changes.customStyle.currentValue) {
            this.selectStyle = this.customStyle.select;
        }
    }

    ngOnInit() {
        this.control = this.formGroupDir.control.get(this.field.name) as FormControl;
        this.control.setValue(this.field.value);
    }

    selectAll(fieldName, arr, select, event) {
        this.group.get(fieldName).patchValue([]);
        if (select) {
            const row = [];
            arr.map((val) => {
                if (val.value) {
                    row.push(val.value);
                }
            });
            this.group.get(fieldName).patchValue(row);
            $(event.target).parents().find('.mat-select-panel').find('mat-pseudo-checkbox').addClass('mat-pseudo-checkbox-checked');
            return;
        }
        $(event.target).parents().find('.mat-select-panel').find('mat-pseudo-checkbox').removeClass('mat-pseudo-checkbox-checked');
    }
}

/**
 * old classes
 * fdx-c-form-group fdx-c-form-group--select fdx-c-form-group--float-label {{field.styleClass}}
 */