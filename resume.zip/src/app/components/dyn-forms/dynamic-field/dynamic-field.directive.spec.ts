import { ComponentFixture, TestBed } from '@angular/core/testing';
import { Component, DebugElement } from '@angular/core';
import { By } from '@angular/platform-browser';
import { ComponentFactoryResolver } from '@angular/core';
import { ViewContainerRef } from '@angular/core';
import { DynamicFieldDirective } from './dynamic-field.directive';
import { FormGroup, FormGroupDirective } from '@angular/forms';

@Component({
  template: `
    <div>Without Directive</div>
    <div dynamicField>Default</div>
  `
})
class TestComponent {}

describe('DynamicFieldDirective', () => {
  let fixture: ComponentFixture<TestComponent>;
  let elementsWithDirective: Array<DebugElement>;
  let bareElement: DebugElement;
  beforeEach(() => {
    const componentFactoryResolverStub = {
      resolveComponentFactory: arg => ({})
    };
    const formGroupStub = {
      controls: {},
      get: field => ({ markAsTouched: () => ({}) })
    };
    const FormGroupDirectiveStub = {
      controls: {},
      get: field => ({ markAsTouched: () => ({}) })
    };
    const viewContainerRefStub = { createComponent: factory => ({}) };
    const field =  {
      name: 'fedexContactNm',
      inputType: 'text',
      type: 'input',
      label: 'FedEx Contact Name',
      styleClass: 'protract-fedex-contact',
      defaultValueRef: 'fullName',
      utilFieldNm: 'fullName',
      opco: 'both',
      validations: [{
          name: 'required',
          value: '',
          message: 'FedEx Contact Name is Required'
      }]
  }
    TestBed.configureTestingModule({
      declarations: [DynamicFieldDirective, TestComponent],
      providers: [
        { provide: FormGroup, useValue: formGroupStub },
        { provide: FormGroupDirective, useValue: FormGroupDirectiveStub }]
    });
    fixture = TestBed.createComponent(TestComponent);
    fixture.detectChanges();
    elementsWithDirective = fixture.debugElement.queryAll(
      By.directive(DynamicFieldDirective)
    );
    bareElement = fixture.debugElement.query(By.css(':not([dynamicField])'));
  });
  // it('should have bare element', () => {
  //   expect(bareElement).toBeTruthy();
  // });
  // it('should have 1 element(s) with directive', () => {
  //   expect(elementsWithDirective.length).toBe(1);
  // });
  describe('ngOnInit', () => {
    // it('makes expected calls', () => {
    //   const componentFactoryResolverStub: ComponentFactoryResolver = TestBed.get(
    //     ComponentFactoryResolver
    //   );
    //   const viewContainerRefStub: ViewContainerRef = TestBed.get(
    //     ViewContainerRef
    //   );
    //   spyOn(
    //     componentFactoryResolverStub,
    //     'resolveComponentFactory'
    //   ).and.callThrough();
    //   spyOn(viewContainerRefStub, 'createComponent').and.callThrough();
    //   pipe.ngOnInit();
    //   expect(
    //     componentFactoryResolverStub.resolveComponentFactory
    //   ).toHaveBeenCalled();
    //   expect(viewContainerRefStub.createComponent).toHaveBeenCalled();
    // });
  });
});
