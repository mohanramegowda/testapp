/*
 * SonarQube, open source software quality management tool.
 * Copyright (C) 2008-2013 SonarSource
 * mailto:contact AT sonarsource DOT com
 *
 * SonarQube is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or (at your option) any later version.
 *
 * SonarQube is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */

import {
    ComponentFactoryResolver,
    ComponentRef,
    Directive,
    Input,
    OnInit,
    ViewContainerRef,
    Output,
    EventEmitter
} from '@angular/core';
import { FormGroup } from '@angular/forms';
import { FieldConfig, CustomStyle } from '../field.interface';
import { InputComponent } from '../input/input.component';
import { ButtonComponent } from '../button/button.component';
import { SelectComponent } from '../select/select.component';
import { DateComponent } from '../date/date.component';
import { RadiobuttonComponent } from '../radiobutton/radiobutton.component';
import { CheckboxComponent } from '../checkbox/checkbox.component';
import { FileInputComponent } from '../file-input/file-input.component';
import { LabelDescComponent } from '../label-desc/label-desc.component';
import { TabComponent } from '../tab/tab.component';

const componentMapper = {
    input: InputComponent,
    button: ButtonComponent,
    select: SelectComponent,
    date: DateComponent,
    radiobutton: RadiobuttonComponent,
    checkbox: CheckboxComponent,
    fileInput: FileInputComponent,
    labelDesc: LabelDescComponent,
    tabTable: TabComponent
};
@Directive({
    // tslint:disable-next-line:directive-selector
    selector: '[dynamicField]'
})
export class DynamicFieldDirective implements OnInit {
    @Input() field: FieldConfig;
    @Input() group: FormGroup;
    @Input() disabled: boolean;
    @Input() required: boolean;
    @Input() customStyle: CustomStyle;
    @Output() onClick: EventEmitter<any> = new EventEmitter<any>();
    componentRef: any;
    constructor(
        private resolver: ComponentFactoryResolver,
        private container: ViewContainerRef
    ) { }
    ngOnInit() {
        if (!componentMapper[this.field.type]) {
            return;
        }
        const factory = this.resolver.resolveComponentFactory(
            componentMapper[this.field.type]
        );
        this.componentRef = this.container.createComponent(factory);
        this.componentRef.instance.field = this.field;
        this.componentRef.instance.disabled = this.disabled;
        this.componentRef.instance.required = this.required;
        this.componentRef.instance.customStyle = this.customStyle;
        this.componentRef.instance.onClick = (event) => {
            this.onClick.emit({ event, field: this.field });
        }
        this.componentRef.instance.onDateInput = (event) => {
            this.onClick.emit({ event, field: this.field });
        }
    }
}
