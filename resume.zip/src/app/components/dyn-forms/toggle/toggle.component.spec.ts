import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { ToggleComponent } from './toggle.component';
import { FormGroup, FormGroupDirective } from '@angular/forms';
describe('ToggleComponent', () => {
  let component: ToggleComponent;
  let fixture: ComponentFixture<ToggleComponent>;
  beforeEach(() => {
    const formGroupStub = {
      controls: {},
      get: field => ({ markAsTouched: () => ({}) })
    };
    const FormGroupDirectiveStub = {
      controls: {},
      get: field => ({ markAsTouched: () => ({}) })
    };
    TestBed.configureTestingModule({
      schemas: [NO_ERRORS_SCHEMA],
      declarations: [ToggleComponent],
      providers: [
        { provide: FormGroup, useValue: formGroupStub },
        { provide: FormGroupDirective, useValue: FormGroupDirectiveStub }]
    });
    fixture = TestBed.createComponent(ToggleComponent);
    component = fixture.componentInstance;
  });
  it('can load instance', () => {
    expect(component).toBeTruthy();
  });
});
