/*
 * SonarQube, open source software quality management tool.
 * Copyright (C) 2008-2013 SonarSource
 * mailto:contact AT sonarsource DOT com
 *
 * SonarQube is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or (at your option) any later version.
 *
 * SonarQube is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */


import { Component, OnInit, EventEmitter, Output, ChangeDetectorRef, ViewChild } from '@angular/core';
import { FormGroup, FormControl, FormGroupDirective } from '@angular/forms';
import { FieldConfig } from '../field.interface';
import { Utility } from 'app/common/Utility';
@Component({
    selector: 'app-dynamic-file-input',
    template: `<div class="{{field.styleClass}}">
    <input type="file" #file [formControl]="control" (change)="onFileChange($event)" id="{{field.styleId}}"
    [placeholder]="field.label" [type]="field.inputType" accept="{{(field.accept) ? field.accept : '*/*'}}"><br />
    <mat-error>{{validationMessage}}</mat-error>
    </div>`,
    styles: []
})
export class FileInputComponent implements OnInit {
    field: FieldConfig;
    group: FormGroup;
    files: any;
    control: FormControl;
    validationMessage: String;
    @ViewChild('file', { static: false }) fileInput;

    constructor(private cd: ChangeDetectorRef, private formGroupDir: FormGroupDirective) { }
    ngOnInit() {
        this.control = this.formGroupDir.control.get(this.field.name) as FormControl;
        this.control.valueChanges.subscribe(() => {
            const currentValidation = this.field.validations.filter(validation => this.control.hasError(validation.name))[0];
            this.validationMessage = currentValidation ? currentValidation.message : '';
        })
        this.control.setValue(this.field.value);
    }

    onFileChange(event) {
        const reader = new FileReader();
        if (event.target.files && event.target.files.length) {
            const [file] = event.target.files;
            Utility.files = (this.fileInput && this.fileInput.nativeElement) ? this.fileInput.nativeElement.files : [];
            reader.readAsDataURL(file);
            const obj = {};
            reader.onload = () => {
                obj[this.field.name] = reader.result;
                if (!this.group.contains(this.field.name + '_file_content')) {
                    this.group.addControl(this.field.name + '_file_content', new FormControl());
                }
                this.group.controls[this.field.name + '_file_content'].setValue(reader.result);
                // this.group.patchValue(obj);

                // need to run CD since file load runs outside of zone
                this.cd.markForCheck();
            };
        }
    }
}
