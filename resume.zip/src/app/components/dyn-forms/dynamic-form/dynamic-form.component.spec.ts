import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { NgZone } from '@angular/core';
import { ChangeDetectorRef } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { FormBuilder } from '@angular/forms';
import { DynamicFormComponent } from './dynamic-form.component';
describe('DynamicFormComponent', () => {
  let component: DynamicFormComponent;
  let fixture: ComponentFixture<DynamicFormComponent>;
  beforeEach(() => {
    const ngZoneStub = { run: function0 => ({}) };
    const changeDetectorRefStub = {};
    const formGroupStub = {
      controls: {},
      get: field => ({ markAsTouched: () => ({}) })
    };
    const formBuilderStub = {
      group: object => ({ addControl: () => ({}) }),
      control: (value, arg) => ({ disable: () => ({}), enable: () => ({}) })
    };
    TestBed.configureTestingModule({
      schemas: [NO_ERRORS_SCHEMA],
      declarations: [DynamicFormComponent],
      providers: [
        { provide: NgZone, useValue: ngZoneStub },
        { provide: ChangeDetectorRef, useValue: changeDetectorRefStub },
        { provide: FormGroup, useValue: formGroupStub },
        { provide: FormBuilder, useValue: formBuilderStub }
      ]
    });
    fixture = TestBed.createComponent(DynamicFormComponent);
    component = fixture.componentInstance;
  });
  // it('can load instance', () => {
  //   expect(component).toBeTruthy();
  // });
  // it('fields defaults to: []', () => {
  //   expect(component.fields).toEqual([]);
  // });
  // describe('validateAllFormFields', () => {
  //   it('makes expected calls', () => {
  //     const formGroupStub: FormGroup = fixture.depabugElement.injector.get(
  //       FormGroup
  //     );
  //     spyOn(formGroupStub, 'get').and.callThrough();
  //     component.validateAllFormFields(formGroupStub);
  //     expect(formGroupStub.get).toHaveBeenCalled();
  //   });
  // });
  // describe('ngOnInit', () => {
  //   it('makes expected calls', () => {
  //     const ngZoneStub: NgZone = fixture.debugElement.injector.get(NgZone);
  //     spyOn(component, 'createControl').and.callThrough();
  //     spyOn(ngZoneStub, 'run').and.callThrough();
  //     component.ngOnInit();
  //     expect(component.createControl).toHaveBeenCalled();
  //     expect(ngZoneStub.run).toHaveBeenCalled();
  //   });
  // });
  // describe('createControl', () => {
  //   it('makes expected calls', () => {
  //     const formBuilderStub: FormBuilder = fixture.debugElement.injector.get(
  //       FormBuilder
  //     );
  //     spyOn(component, 'bindValidations').and.callThrough();
  //     spyOn(formBuilderStub, 'group').and.callThrough();
  //     spyOn(formBuilderStub, 'control').and.callThrough();
  //     component.createControl();
  //     expect(component.bindValidations).toHaveBeenCalled();
  //     expect(formBuilderStub.group).toHaveBeenCalled();
  //     expect(formBuilderStub.control).toHaveBeenCalled();
  //   });
  // });
});
