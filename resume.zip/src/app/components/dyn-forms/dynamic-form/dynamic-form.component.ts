/*
 * SonarQube, open source software quality management tool.
 * Copyright (C) 2008-2013 SonarSource
 * mailto:contact AT sonarsource DOT com
 *
 * SonarQube is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or (at your option) any later version.
 *
 * SonarQube is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */


import {
    Component,
    Input,
    OnInit,
    NgZone,
    OnDestroy,
    forwardRef,
    EventEmitter,
    Output
} from '@angular/core';
import {
    FormGroup,
    FormBuilder,
    Validators,
    NG_VALUE_ACCESSOR
} from '@angular/forms';
import { FieldConfig, Validator, CustomStyle } from '../field.interface';
import { Subscription } from 'rxjs';
import { ControlValueBase } from 'app/common/control-value.base';

@Component({
    exportAs: 'app-dynamic-form',
    selector: 'app-dynamic-form',
    template: `
    <form class="dynamic-form {{styleClass}}" [formGroup]="form">
    <div class="{{styleSubClass}}" *ngFor="let field of fields;">
    <ng-container dynamicField [required]="isRequired(field)" [disabled]="disabled" [field]="field" [group]="form" 
    [customStyle]="customStyle" (onClick)="onValueChange($event)">
    </ng-container>
    </div>
    <ng-content></ng-content>
    </form>
    `,
    styles: [],
    providers: [
        {
            provide: NG_VALUE_ACCESSOR,
            useExisting: forwardRef(() => DynamicFormComponent),
            multi: true
        },
    ]
})

export class DynamicFormComponent extends ControlValueBase implements OnInit, OnDestroy {

    @Input() fields: FieldConfig[] = [];
    @Input() styleClass = '';
    @Input() styleSubClass = '';
    @Input() formName = '';
    @Input() customStyle: CustomStyle;
    @Output() valueChange: EventEmitter<any> = new EventEmitter<any>();
    formSubscription: Subscription;

    get value() {
        return this.form.value;
    }
    constructor(private fb: FormBuilder, private zone: NgZone) {
        super();
    }

    ngOnInit() {
        this.zone.run(() => {
            this.form = this.createControl();
            this.formSubscription = this.form.valueChanges.subscribe(val => {
                this.writeValue(val);
            });
        });
    }

    createControl() {
        const group = this.form ? this.form : this.fb.group({});
        this.fields.forEach(field => {
            if (field.type === 'button') { return; }
            const control = this.fb.control(
                field.value,
                this.bindValidations(field.validations || [])
            );
            if (field.disabled) {
                control.disable();
            } else {
                control.enable();
            }
            group.addControl(field.name, control);
        });
        return group;
    }

    bindValidations(validations: any) {
        if (validations.length > 0) {
            const validList = [];
            validations.forEach(valid => {
                validList.push(valid.validator);
            });
            return Validators.compose(validList);
        }
        return null;
    }

    isRequired(field) {
        let required = false;
        if (field && field.validations) {
            field.validations.map((validation) => {
                required = validation.name === 'required' ? true : false;
            });
        }
        return required;
    }

    validateAllFormFields(formGroup: FormGroup) {
        Object.keys(formGroup.controls).forEach(field => {
            const control = formGroup.get(field);
            control.markAsTouched({ onlySelf: true });
            if (!this.form.controls[field].valid) {
                console.log(field);
            }
        });
    }

    onValueChange($event) {
        this.valueChange.emit($event);
    }

    ngOnDestroy() {
        this.formSubscription.unsubscribe();
    }
}
