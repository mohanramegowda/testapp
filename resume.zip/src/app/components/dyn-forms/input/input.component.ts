/*
 * SonarQube, open source software quality management tool.
 * Copyright (C) 2008-2013 SonarSource
 * mailto:contact AT sonarsource DOT com
 *
 * SonarQube is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or (at your option) any later version.
 *
 * SonarQube is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */


import { Component, OnInit, OnChanges, SimpleChanges } from '@angular/core';
import { FormGroup, FormGroupDirective, FormControl } from '@angular/forms';
import { FieldConfig, CustomStyle } from '../field.interface';
@Component({
    selector: 'app-dynamic-input',
    template: `
    <div [class]="(inputStyle && inputStyle.mainDiv) ? inputStyle.mainDiv : 'fdx-c-form-group fdx-c-form-group  fdx-c-form-group--float-label'"
     [hidden]="field.hidden" [ngClass]="{'fdx-c-form-group--is-invalid' : (control.touched && control.invalid) ? true : false}">
    <div [class]="(inputStyle && inputStyle.subDiv) ? inputStyle.subDiv : 'fdx-c-form-group__item'">
        <input type="{{field.inputType}}" class="input-purple-form-group {{field.styleClass}}" id="{{field.styleId}}" value="" aria-describedby="alertID"
        [required]="required" onkeydown="return event.keyCode !== 69" *ngIf="field.inputType === 'number' && field.inputType !== 'textarea'" maxlength="200" [formControl]="control"
        [type]="field.inputType" >

        <input type="{{field.inputType}}" class="input-purple-form-group {{field.styleClass}}" id="{{field.styleId}}" value="" aria-describedby="alertID"
        [required]="required" *ngIf="field.inputType !== 'number' && field.inputType !== 'textarea'" maxlength="200" [formControl]="control"
        [type]="field.inputType">

        <label [class]="(inputStyle && inputStyle.labelStyleClass) ? inputStyle.labelStyleClass : 'label-purple-input'" for="INPUT">{{field.label}}</label>
    </div>
    <div role="alert" id="alertID" class="fdx-c-form-message fdx-c-form-message--error"
    *ngFor="let validation of field?.validations;">
        <span *ngIf="control.touched && control.hasError(validation.name)">{{validation.message}}</span>
    </div>
</div>
`,
    styles: []
})
export class InputComponent implements OnInit, OnChanges {
    field: FieldConfig;
    group: FormGroup;
    required: boolean;
    control: FormControl;
    customStyle: CustomStyle;
    inputStyle: any;
    validationMessage: String;

    constructor(private formGroupDir: FormGroupDirective) { }

    ngOnChanges(changes: SimpleChanges) {
        if (changes.customStyle && changes.customStyle.currentValue && changes.customStyle.currentValue.input) {
            this.inputStyle = this.customStyle.input;
        }
    }

    ngOnInit() {
        this.control = this.formGroupDir.control.get(this.field.name) as FormControl;
        this.control.setValue(this.field.value);
        this.control.valueChanges.subscribe(() => {
            if (this.field.validations) {
                const currentValidation = this.field.validations ?
                    this.field.validations.filter(validation => this.control.hasError(validation.name))[0] : null;
                this.validationMessage = currentValidation ? currentValidation.message : '';
            }
        });
        if (this.field.validations && this.field.validations.length) {
            this.field.validations.map((ele) => {
                if (ele.name === 'required') {
                    this.required = true;
                }
            })
        } else {
            this.required = false;
        }
    }
}
