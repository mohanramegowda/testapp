import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { InputComponent } from './input.component';
import { FormGroup, FormGroupDirective } from '@angular/forms';
describe('InputComponent', () => {
  let component: InputComponent;
  let fixture: ComponentFixture<InputComponent>;
  beforeEach(() => {
    const formGroupStub = {
      controls: {},
      get: field => ({ markAsTouched: () => ({}) })
    };
    const FormGroupDirectiveStub = {
      controls: {},
      get: field => ({ markAsTouched: () => ({}) })
    };
    TestBed.configureTestingModule({
      schemas: [NO_ERRORS_SCHEMA],
      declarations: [InputComponent],
      providers: [
        { provide: FormGroup, useValue: formGroupStub },
        { provide: FormGroupDirective, useValue: FormGroupDirectiveStub }]
    });
    fixture = TestBed.createComponent(InputComponent);
    component = fixture.componentInstance;
  });
  it('can load instance', () => {
    expect(component).toBeTruthy();
  });
});
