import { Component, OnInit } from '@angular/core';
import { FieldConfig } from '../field.interface';

@Component({
  selector: 'app-tab',
  templateUrl: './tab.component.html',
  styles: []
})
export class TabComponent implements OnInit {
  field: FieldConfig;
  constructor() {}
  ngOnInit() {}

}
