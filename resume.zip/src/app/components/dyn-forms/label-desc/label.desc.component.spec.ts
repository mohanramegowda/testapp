import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { LabelDescComponent } from './label-desc.component';
import { FormGroup, FormGroupDirective } from '@angular/forms';
describe('LabelDescComponent', () => {
  let component: LabelDescComponent;
  let fixture: ComponentFixture<LabelDescComponent>;
  beforeEach(() => {
    const formGroupStub = {
      controls: {},
      get: field => ({ markAsTouched: () => ({}) })
    };
    const FormGroupDirectiveStub = {
      controls: {},
      get: field => ({ markAsTouched: () => ({}) })
    };
    TestBed.configureTestingModule({
      schemas: [NO_ERRORS_SCHEMA],
      declarations: [LabelDescComponent],
      providers: [
        { provide: FormGroup, useValue: formGroupStub },
        { provide: FormGroupDirective, useValue: FormGroupDirectiveStub }]
    });
    fixture = TestBed.createComponent(LabelDescComponent);
    component = fixture.componentInstance;
  });
  it('can load instance', () => {
    expect(component).toBeTruthy();
  });
});
