/*
 * SonarQube, open source software quality management tool.
 * Copyright (C) 2008-2013 SonarSource
 * mailto:contact AT sonarsource DOT com
 *
 * SonarQube is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or (at your option) any later version.
 *
 * SonarQube is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */


import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormGroupDirective } from '@angular/forms';
import { FieldConfig } from '../field.interface';
@Component({
    selector: 'app-dynamic-radiobutton',
    template: `
<div class="demo-full-width margin-top {{field.styleClass}}">
<label class="radio-label-padding" *ngIf="field.label">{{field.label}}:</label>
<mat-radio-group *ngIf="field.options" [formControl]="control" id="{{field.styleId}}">
<mat-radio-button [disabled]="disabled" *ngFor="let item of field.options"
 [value]="(item.value) ? item.value : item"> {{(item.name) ? item.name : item}}
</mat-radio-button>
</mat-radio-group>
<mat-error>{{validationMessage}}</mat-error>
</div>
`,
    styles: []
})
export class RadiobuttonComponent implements OnInit {
    field: FieldConfig;
    group: FormGroup;
    control: FormControl;
    disabled: boolean;
    validationMessage: String;
    constructor(private formGroupDir: FormGroupDirective) { }
    ngOnInit() {
        this.control = this.formGroupDir.control.get(this.field.name) as FormControl;
        this.control.valueChanges.subscribe(() => {
            const currentValidation = this.field.validations.filter(validation => this.control.hasError(validation.name))[0];
            this.validationMessage = currentValidation ? currentValidation.message : '';
        })
        this.control.setValue(this.field.value);
    }
}
