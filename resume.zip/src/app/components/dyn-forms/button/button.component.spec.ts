import { ComponentFixture, TestBed } from '@angular/core/testing';
import { NO_ERRORS_SCHEMA } from '@angular/core';
import { ButtonComponent } from './button.component';
import { FormGroup, FormGroupDirective } from '@angular/forms';
describe('ButtonComponent', () => {
  let component: ButtonComponent;
  let fixture: ComponentFixture<ButtonComponent>;
  beforeEach(() => {
    const formGroupStub = {
      controls: {},
      get: field => ({ markAsTouched: () => ({}) })
    };
    const FormGroupDirectiveStub = {
      controls: {},
      get: field => ({ markAsTouched: () => ({}) })
    };
    TestBed.configureTestingModule({
      schemas: [NO_ERRORS_SCHEMA],
      declarations: [ButtonComponent],
      providers: [
        { provide: FormGroup, useValue: formGroupStub },
        { provide: FormGroupDirective, useValue: FormGroupDirectiveStub }]
    });
    fixture = TestBed.createComponent(ButtonComponent);
    component = fixture.componentInstance;
  });
  it('can load instance', () => {
    expect(component).toBeTruthy();
  });
});
