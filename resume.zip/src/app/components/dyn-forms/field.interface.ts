/*
 * SonarQube, open source software quality management tool.
 * Copyright (C) 2008-2013 SonarSource
 * mailto:contact AT sonarsource DOT com
 *
 * SonarQube is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or (at your option) any later version.
 *
 * SonarQube is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */


export interface Validator {
    name: string;
    validator: any;
    message: string;
}
export interface FieldConfig {
    dateFilter?: (d: Date) => boolean;
    label?: string;
    name?: string;
    inputType?: string;
    options?: any[];
    collections?: any;
    type: string;
    value?: any;
    styleClass?: any;
    styleColor?: any;
    min?: any;
    max?: any;
    disabled?: boolean;
    multiSelect?: boolean;
    validations?: Validator[];
    accept?: string;
    styleId?: string;
}

export interface CustomStyle {
    labelStyleClass?: string;
    input?: {
        mainDiv?: string;
        subDiv?: string;
    }
    select?: {
        selectOption?: string;
        selectMainDiv?: string;
        selectSubDiv?: string;
        selectLabel?: string;
    }
}
