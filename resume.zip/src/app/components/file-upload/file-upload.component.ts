import { Component, OnInit, Output, EventEmitter, Input, ViewChild, OnChanges } from '@angular/core';
import { CommonService } from 'app/common/common.service';

@Component({
  selector: 'app-file-upload',
  templateUrl: './file-upload.component.html',
  styleUrls: ['./file-upload.component.scss']
})
export class FileUploadComponent implements OnInit {


  @Output() onUpload: EventEmitter<any> = new EventEmitter<any>();
  @Output() onDownload: EventEmitter<any> = new EventEmitter<any>();
  @Output() onDelete: EventEmitter<any> = new EventEmitter<any>();
  @Input() fileList;
  @Input() showUpload;
  @Input() hideExisting;
  @Input() hideDelete;
  @Input() hideDownload;
  @Output() existingFiles: EventEmitter<any> = new EventEmitter<any>();
  @Input() fileOnCancel: Array<any> = [];
  @Input() buttonLabelChange;
  @Input() allowMultiple: boolean;
  @Input() accept: string;
  @Input() hideDownloadAll: boolean;

  @ViewChild('uploadFiles', { static: false }) uploadFiles;
  files: Array<any> = [];
  updatedFiles: any[];
  constructor(private commonService: CommonService) {
    this.files = [];
  }

  ngOnInit() {
    this.files = this.fileOnCancel;
  }

  triggerUploadFile() {
    const filedata = { filesList: this.files, type: 'saved' }
    if (this.files) {
      this.onUpload.emit(filedata);
    } else {
      this.onUpload.emit([]);
    }
    this.uploadFiles.nativeElement.value = '';
    this.files = [];
  }

  triggerDownloadFile(id) {
    if (id === 'All') {
      this.onDownload.emit('All');
    } else if (id === 'Latest') {
      this.onDownload.emit('Latest');
    } else {
      this.onDownload.emit(id);
    }
  }

  gridChangeFormatDateTime(dateTime) {
    return this.commonService.formatDateTime(new Date(dateTime), 'DD/MM/YYYY HH:mm:ss');
  }
  showFiles() {
    if (this.uploadFiles && this.uploadFiles.nativeElement) {
      const filesCopy = this.uploadFiles.nativeElement.files;
      if (this.fileOnCancel === undefined) {
        this.files = [];
      }
      if (filesCopy.length > 15) {
        this.commonService.showNotifier('Number of files can not be greater than 15', 'error');
        this.files = [];
        return false;
      }
      const fileLength = filesCopy.length;
      if (!this.allowMultiple && this.files.length > 0) {
        this.files = [];
      }
      for (let i = 0; i < fileLength; i += 1) {
        this.files.push(filesCopy[i]);
      }
    } else {
      this.files = [];
    }
  }

  removeFile(index, id = null) {
    // if (this.fileList.length === 1 && id) {
    //   this.commonService.showNotifier('Atleast one file is required.', 'error');
    //   return;
    // }
    if (this.files && id === null) {
      this.files.splice(index, 1);
    }
    if (this.fileList && id !== null) {
      this.onDelete.emit(id);
      this.fileList.splice(index, 1);
      // const filedata = { filesList: this.files, type: 'beforesave' }
      // this.onUpload.emit(filedata);
    }
  }

}
