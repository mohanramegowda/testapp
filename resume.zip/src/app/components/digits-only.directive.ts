/*
 * SonarQube, open source software quality management tool.
 * Copyright (C) 2008-2013 SonarSource
 * mailto:contact AT sonarsource DOT com
 *
 * SonarQube is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or (at your option) any later version.
 *
 * SonarQube is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; if not, write to the Free Software Foundation,
 * Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
 */


import { Directive, ElementRef, HostListener, Input, OnInit, Renderer2, Optional, NgZone } from '@angular/core';
import { MatInput, ErrorStateMatcher } from '@angular/material';
import { Platform } from '@angular/cdk/platform';
import { NgControl, NgForm, FormGroupDirective } from '@angular/forms';
import { AutofillMonitor } from '@angular/cdk/text-field';

@Directive({
    selector: '[appDigitsOnly]'
})
export class DigitsOnlyDirective implements OnInit {
    private navigationKeys = [
        'Backspace',
        'Delete',
        'Tab',
        'Escape',
        'Enter',
        'Home',
        'End',
        'ArrowUp',
        'ArrowDown',
        'ArrowLeft',
        'ArrowRight',
        'Clear',
        'Copy',
        'Paste'
    ];
    inputElement: HTMLElement;

    @Input() defaultLimit: any;
    @Input() setLimit: any;
    // constructor(protected _elementRef: ElementRef,
    //     protected _renderer: Renderer2,
    //     protected _platform: Platform,
    //     @Optional() public ngControl: NgControl,
    //     @Optional() public _parentForm: NgForm,
    //     @Optional() public _parentFormGroup: FormGroupDirective,
    //     _defaultErrorStateMatcher: ErrorStateMatcher,
    //     _autoFillMonitor: AutofillMonitor,
    //     protected _zone: NgZone
    // ) {
    //     // const _inputValueAccessor: any = null;
    //     super(_elementRef, _platform, ngControl, _parentForm,
    //         _parentFormGroup, _defaultErrorStateMatcher, null, _autoFillMonitor, _zone);
    //     console.log('initing');
    // }

    constructor(public el: ElementRef) {
        // console.log('initing');
        this.inputElement = el.nativeElement;
    }

    ngOnInit() {
        // console.log('on Init');
    }

    @HostListener('keydown', ['$event'])
    onKeyDown(e: KeyboardEvent) {
        if (
            this.navigationKeys.indexOf(e.key) > -1 || // Allow: navigation keys: backspace, delete, arrows etc.
            (e.key === 'a' && e.ctrlKey === true) || // Allow: Ctrl+A
            (e.key === 'c' && e.ctrlKey === true) || // Allow: Ctrl+C
            (e.key === 'v' && e.ctrlKey === true) || // Allow: Ctrl+V
            (e.key === 'x' && e.ctrlKey === true) || // Allow: Ctrl+X
            (e.key === 'a' && e.metaKey === true) || // Allow: Cmd+A (Mac)
            (e.key === 'c' && e.metaKey === true) || // Allow: Cmd+C (Mac)
            (e.key === 'v' && e.metaKey === true) || // Allow: Cmd+V (Mac)
            (e.key === 'x' && e.metaKey === true) // Allow: Cmd+X (Mac)
        ) {
            // let it happen, don't do anything
            return;
        }

        if (this.defaultLimit === 'false' && this.setLimit) {
            if (e.target['value'].length > (this.setLimit - 0)) {
                console.log(e);
                e.stopPropagation();
                e.preventDefault();
            }
        }
        // Ensure that it is a number and stop the keypress
        if (this.defaultLimit !== 'false') {
            if (e.target['value'].length > 8) {
                console.log(e);
                e.stopPropagation();
                e.preventDefault();
            }
        }

        if (e.target['value'] < 0) {
            e.preventDefault();
        }
        if (isNaN(e.target['value'])) {
            e.target['value'] = e.target['value'].replace(/\D/g, '');
        }
        if (
            (e.shiftKey || (e.keyCode < 48 || e.keyCode > 57)) &&
            (e.keyCode < 96 || e.keyCode > 105)
        ) {
            e.preventDefault();
        }
    }

    @HostListener('keypress', ['$event'])
    onKeyPress(event: KeyboardEvent) {
        const pattern = /[0-9\+\-\ ]/;
        const inputChar = String.fromCharCode(event.charCode);
        if (!pattern.test(inputChar)) {
            event.preventDefault();
        }
    }

    // @HostListener('paste', ['$event'])
    // onPaste(event: ClipboardEvent) {
    //     event.preventDefault();
    //     const pastedInput: string = event.clipboardData
    //         .getData('text/plain')
    //         .replace(/\D/g, ''); // get a digit-only string
    //     document.execCommand('insertText', false, pastedInput);
    // }

    // @HostListener('drop', ['$event'])
    // onDrop(event: DragEvent) {
    //     event.preventDefault();
    //     const textData = event.dataTransfer.getData('text').replace(/\D/g, '');
    //     this.inputElement.focus();
    //     document.execCommand('insertText', false, textData);
    // }
}
