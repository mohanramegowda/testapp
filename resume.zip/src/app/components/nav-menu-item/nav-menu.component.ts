/*
* SonarQube, open source software quality management tool.
* Copyright (C) 2008-2013 SonarSource
* mailto:contact AT sonarsource DOT com
*
* SonarQube is free software; you can redistribute it and/or
* modify it under the terms of the GNU Lesser General Public
* License as published by the Free Software Foundation; either
* version 3 of the License, or (at your option) any later version.
*
* SonarQube is distributed in the hope that it will be useful,
* but WITHOUT ANY WARRANTY; without even the implied warranty of
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
* Lesser General Public License for more details.
*
* You should have received a copy of the GNU Lesser General Public License
* along with this program; if not, write to the Free Software Foundation,
* Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.
*/


import { Component, OnInit, } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { Utility } from 'app/common/Utility';
import { CommonService } from 'app/common/common.service';
import {TranslateService} from '@ngx-translate/core';

declare const $: any;
declare const window: any;
declare interface RouteInfo {
    path: string;
    title: string;
    icon: string;
    class: string;
    isOld: boolean;
    show: boolean;
    children: RouteInfo1[];
    translate: string;
}

declare interface RouteInfo1 {
    path: string;
    title: string;
    icon: string;
    class: string;
    isOld: boolean;
    show: boolean;
    children: RouteInfo[];
    translate: string;
}

declare interface ParentRouteInfo {
    path: string;
    title: string;
    icon: string;
    name: string;
    class: string;
    isOld: boolean;
    children: RouteInfo[];
    show: boolean;
    actions: string[];
    translate: string;
}
export const ROUTES: ParentRouteInfo[] = [
    {
        path: '/activity',
        isOld: false,
        name: 'activity',
        title: 'Activity View',
        // icon: 'add',
        icon: '',
        class: 'nav-link',
        children: null,
        show: true,
        actions: [],
        translate: 'NAVBAR_ACTIVITY',
    },
    {
        path: '/proposal/create',
        isOld: false,
        name: 'create',
        title: 'Create Proposal',
       // icon: 'add',
        icon: '',
        translate: 'NAVBAR_CREATEPROPOSAL',
        class: 'href-purple-secondary-outline-purple',
        children: null,
        show: true,
        actions: []
    }
    // {
    //         path: '',
    //         isOld: false,
    //         name: 'language',
    //         title: 'Language',
    //         icon: 'layers',
    //         class: '',
    //         show: false,
    //         actions: [],
    //         translate: 'NAVBAR_ADMIN',
    //         children: [{
    //             path: '/list/PRC',
    //             isOld: false,
    //             title: 'Pricing Config',
    //             icon: 'content_paste',
    //             class: '',
    //             translate: 'NAVBAR_PRICING',
    //             children: null,
    //             show: true,
    //         },
    //         {
    //             path: '/list/PRC',
    //             isOld: false,
    //             title: 'Pricing Config',
    //             icon: 'content_paste',
    //             class: '',
    //             translate: 'NAVBAR_PRICING',
    //             children: null,
    //             show: true,
    //         }]
    //     }
];



@Component({
    selector: 'nav-menu',
    templateUrl: './nav-menu.component.html',
    styleUrls: ['./nav-menu.component.css']
})
export class NavMenuItemComponent implements OnInit {
    menuItems: any[];
    fullOriginPath: any = '';

    constructor(
        private route: ActivatedRoute,
        private router: Router,
        private commonservice: CommonService,
        public translate: TranslateService
    ) {
    }

    ngOnInit() {
        this.getOldAdminScreenPath();
        this.menuItems = ROUTES.filter(menuItem => menuItem);
        const actions = Utility.roleActions.actions;
        this.menuItems.map((menuItem) => {
            if (Utility.isLocal || (Utility.roleActions && Utility.roleActions.actions
                && Utility.roleActions.actions.indexOf(menuItem.name) > -1)) {
                menuItem.show = true;
                menuItem.actions = actions;
            } else {
                menuItem.show = false;
                menuItem.actions = [];
            }
        });
    }

    isMobileMenu() {
        if ($(window).width() > 991) {
            return false;
        }
        return true;
    }

    getOldAdminScreenPath() {
        // const fullPath = OttUtility.fullOriginPath;
        // this.fullOriginPath = fullPath + window.location.pathname.substring(0, window.location.pathname.indexOf('/', 2));
        // this.fullOriginPath += '/old';
    }

    routeTo(path) {
        this.router.navigate(path);
    }
}
