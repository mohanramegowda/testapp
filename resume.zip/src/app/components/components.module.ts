import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';

import { MaterialModule } from './material.module';
import { FooterComponent } from './footer/footer.component';
import { NavbarComponent } from './navbar/navbar.component';
import { SidebarComponent } from './sidebar/sidebar.component';
import { NavMenuItemComponent } from './nav-menu-item/nav-menu.component';
import { LoadingIndicatorComponent } from './loading-indicator/loading-indicator-component';
import {TranslateModule} from '@ngx-translate/core';
import { FileUploadComponent } from './file-upload/file-upload.component';
import { AddCommentComponent } from './add-comment/add-comment.component';
import { FormsModule } from '@angular/forms';
@NgModule({
  imports: [
    CommonModule,
    RouterModule,
    MaterialModule,
    TranslateModule,
    FormsModule
  ],
  declarations: [
    FooterComponent,
    NavbarComponent,
    SidebarComponent,
    LoadingIndicatorComponent,
    FileUploadComponent,
    AddCommentComponent,
    NavMenuItemComponent
  ],
  exports: [
    FooterComponent,
    NavbarComponent,
    SidebarComponent,
    LoadingIndicatorComponent,
    MaterialModule,
    TranslateModule,
    FileUploadComponent,
    AddCommentComponent
  ]
})
export class ComponentsModule { }
