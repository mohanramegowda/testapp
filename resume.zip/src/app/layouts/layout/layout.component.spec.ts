import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LayoutComponent } from './layout.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientModule } from '@angular/common/http';
import { RouterTestingModule } from '@angular/router/testing';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { TableListRoutesModule } from 'app/table-list/table-list.routing';
import { ComponentsModule } from 'app/components/components.module';
import { TableListDetailModule } from 'app/table-list/table-list-detail/table-list-detail.module';
import { CommonService } from 'app/common/common.service';
import { TableListService } from 'app/table-list/table-list.service';
import { DynamicFilterService } from 'app/table-list/dynamic-filter/dynamic-filter.service';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';
import { RouterModule } from '@angular/router';
import { LayoutRoutes } from './layout.routing';
import { PendingInterceptorModule } from 'app/components/loading-indicator/pending-interceptor.module';
import { DashboardModule } from 'app/dashboard/dashboard.module';

xdescribe('AdminLayoutComponent', () => {
  let component: LayoutComponent;
  let fixture: ComponentFixture<LayoutComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      imports: [
        BrowserAnimationsModule,
        HttpClientModule,
        RouterTestingModule,
        CommonModule,
        FormsModule,
        ReactiveFormsModule,
        CommonModule,
        RouterModule.forChild(LayoutRoutes),
        FormsModule,
        ReactiveFormsModule,
        PendingInterceptorModule,
        ComponentsModule,
        DashboardModule,
      ],
      declarations: [
        LayoutComponent,
      ],
      providers: [
        CommonService,
      ],
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LayoutComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
