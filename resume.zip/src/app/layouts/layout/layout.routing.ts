import { Routes } from '@angular/router';

import { DashboardComponent } from '../../dashboard/dashboard.component';
import { TableListComponent } from '../../table-list/table-list.component';

export const LayoutRoutes: Routes = [
    // {
    //   path: '',
    //   children: [ {
    //     path: 'dashboard',
    //     component: DashboardComponent
    // }]}, {
    // path: '',
    // children: [ {
    //   path: 'userprofile',
    //   component: UserProfileComponent
    // }]
    // }, {
    //   path: '',
    //   children: [ {
    //     path: 'icons',
    //     component: IconsComponent
    //     }]
    // }, {
    //     path: '',
    //     children: [ {
    //         path: 'notifications',
    //         component: NotificationsComponent
    //     }]
    // }, {
    //     path: '',
    //     children: [ {
    //         path: 'maps',
    //         component: MapsComponent
    //     }]
    // }, {
    //     path: '',
    //     children: [ {
    //         path: 'typography',
    //         component: TypographyComponent
    //     }]
    // }, {
    //     path: '',
    //     children: [ {
    //         path: 'upgrade',
    //         component: UpgradeComponent
    //     }]
    // }
    // { path: 'dashboard',      component: DashboardComponent },
    // { path: 'table-list',     component: TableListComponent },

    {
        path: 'create',
        loadChildren: '../../workflow/workflow.module#WorkFlowModule'
    },
    {
        path: 'proposal',
        loadChildren: '../../workflow/workflow.module#WorkFlowModule'
    },
    // {
    //     path: 'update',
    //     loadChildren: '../../workflow/workflow.module#WorkFlowModule'
    // },
    {
        path: '',
        loadChildren: '../../activity-view/activity-view.module#ActivityViewModule'
        // loadChildren: '../../dashboard/dashboard.module#DashboardModule'
    },
    {
        path: 'activity',
        loadChildren: '../../activity-view/activity-view.module#ActivityViewModule'
    },
    // {
    //     path: 'sneakpreview',
    //     loadChildren: '../../sneak-preview/sneak-preview.module#SneakPreviewModule'
    // },
    {
        path: 'list',
        loadChildren: '../../table-list/table-list.module#TableListModule'
    }
];
