import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { LayoutRoutes } from './layout.routing';
import { PendingInterceptorModule } from 'app/components/loading-indicator/pending-interceptor.module';

import { DashboardModule } from '../../dashboard/dashboard.module';
import { ComponentsModule } from 'app/components/components.module';

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(LayoutRoutes),
    FormsModule,
    ReactiveFormsModule,
    PendingInterceptorModule,
    ComponentsModule,
    DashboardModule
  ],
  declarations: [    
  ]
})

export class LayoutModule {}
