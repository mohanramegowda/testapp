import { Injectable } from '@angular/core';
import { CommonService } from '../common/common.service';
import { Utility } from '../common/Utility';
import { Router, ActivatedRoute } from '@angular/router';

@Injectable()
export class ActivityViewService {
    activityViewComponent;
    downloadAllowed = Utility.commonStaticObject.downloadAllowed;
    editAllowed = Utility.commonStaticObject.editAllowed;
    searchSortConfig = {
        status: (value, filterObj) => {
            if (filterObj && filterObj.searchCriteria) {
                filterObj.searchCriteria.status = value;
            }
            return filterObj;
        },
        trfTyp: (value, filterObj) => {
            if (filterObj && filterObj.searchCriteria) {
                filterObj.searchCriteria.trfTypNm = value;
            }
            return filterObj;
        },
        country: (value, filterObj) => {
            if (filterObj && filterObj.searchCriteria) {
                filterObj.searchCriteria.countryId = value;
            }
            return filterObj;
        },
        ldapIdNbr: (value, filterObj) => {
            if (filterObj && filterObj.searchCriteria) {
                filterObj.searchCriteria.ldapIdNbr = Utility.userDetails.userId;
            }
            return filterObj;
        },
        revenueType: (value, filterObj) => {
            if (filterObj && filterObj.searchCriteria) {
                filterObj.searchCriteria.revenueType = value;
            }
            return filterObj;
        },
        revenueStart: (value, filterObj) => {
            if (filterObj && filterObj.searchCriteria) {
                filterObj.searchCriteria.revenueStart = value;
            }
            return filterObj;
        },
        revenueEnd: (value, filterObj) => {
            if (filterObj && filterObj.searchCriteria) {
                filterObj.searchCriteria.revenueEnd = value;
            }
            return filterObj;
        },
        ldapList: (value, filterObj) => {
            if (filterObj && filterObj.searchCriteria) {
                filterObj.searchCriteria.ldapList = value;
            }
            return filterObj;
        },
        sort: (value, filterObj) => {
            if (filterObj && filterObj.sortCriteria && value && value.select && value.values) {
                filterObj.sortCriteria = {};
                filterObj.sortCriteria[value.select] = (value.values[value.select]) ? value.values[value.select].value : '0';
            }
            return filterObj;
        }
    }

    errorMessages = {
        errPastDate: 'The Tariff you try to download is based on an older version of the Tariff Guide template and is not applicable'
            + 'any more.'
            + 'List prices, weight structure, zoning and surcharges have been updated. Please re-create your Tariff using the'
            + 'current settings.',
        noPTdoc: 'No documents have been uploaded for this Personalised tariff.',
        noDoc: 'No tariffs generated/downloaded for this tariff.',
        noStatus: 'No Status selected to update.',
        noEdit: 'The Tariff you try to edit is based on an older version. Please re-create your Tariff'
            + ' using the current settings.'
    };
    private staticCmprDt = new Date('03/09/2018'); // MM/DD/YYYY
    private filterConfig = {
        status: (value) => {
            if (value === 'All') {
                return null;
            }
            return value;
        },
        ldapIdNbr: (value) => {
            if (!value) {
                return 0;
            }
            return value;
        },
        trfTypNm: (value) => {
            if (value === 'All') {
                return null;
            }
            return value;
        },
        countryId: (value) => {
            if (!value && value !== 0) {
                return null;
            }
            return value;
        },
        revenueType: (value) => {
            return value;
        },
        revenueEnd: (value) => {
            return value;
        },
        revenueStart: (value) => {
            return value;
        },
        ldapList: (value) => {
            if (!value || value.length === 0) {
                return null;
            }
            const users = [];
            value.map((userName) => {
                users.push(parseInt(Utility.commonStaticObject['reporteeDetails'][userName], 0));
            });
            return users;
        }
    }

    constructor(
        private router: Router,
        private activatedRoute: ActivatedRoute,
        private commonService: CommonService
    ) {

    }

    generateInitSearch() {
        const reqArr = [];
        // Get Statuses
        const requestStatus = {
            url: (Utility.urlParams.getStatuses.url),
            param: { type: 'ALL' },
            type: Utility.urlParams.getStatuses.type
        }
        reqArr.push(requestStatus);
        // const searchStatuses = {
        //     url: (Utility.urlParams.getStatusOptionsForActivityView.url),
        //     param: {
        //         type: 'GET',
        //         customerType: Utility.roleActions.roleName
        //     },
        //     type: Utility.urlParams.getStatusOptionsForActivityView.type
        // }
        // reqArr.push(searchStatuses);

        return reqArr;
    }

    processRequestFilter(filterObj) {
        if (filterObj && filterObj.searchCriteria
            && !this.commonService.checkNullOrUndefined(filterObj.searchCriteria.referenceOrCompanyName)) {
            if (new RegExp('^[0-9]{1,}$').test(filterObj.searchCriteria.referenceOrCompanyName)) {
                filterObj.searchCriteria.salesFeedNumber = filterObj.searchCriteria.referenceOrCompanyName;
                filterObj.searchCriteria.companyName = null;
            } else {
                filterObj.searchCriteria.salesFeedNumber = null;
                filterObj.searchCriteria.companyName = filterObj.searchCriteria.referenceOrCompanyName;
            }
            filterObj.searchCriteria.referenceOrCompanyName = null;
        }
        if (filterObj && filterObj.searchCriteria) {
            // tslint:disable-next-line:forin
            for (const i in filterObj.searchCriteria) {
                if (typeof this.filterConfig[i] === 'function') {
                    filterObj.searchCriteria[i] = this.filterConfig[i](filterObj.searchCriteria[i]);
                }
                if (!filterObj.searchCriteria[i] && ([0, false].indexOf(filterObj.searchCriteria[i]) === -1)) {
                    delete filterObj.searchCriteria[i];
                }
            }
        }
        return filterObj;
    }

    resetFilters(filterObj: any) {
        const basicDetails = {
            countryId: (Utility.loggedInCountryDetails && Utility.loggedInCountryDetails.countryInfo &&
                Utility.loggedInCountryDetails.countryInfo.ctryIdNbr) ?
                Utility.loggedInCountryDetails.countryInfo.ctryIdNbr : 0,
            ldapIdNbr: (Utility.userDetails && Utility.userDetails.userId) ?
                Utility.userDetails.userId : '0',
            customerType: (Utility.roleActions && Utility.roleActions.roleName) ?
                Utility.roleActions.roleName : ''
        };
        filterObj = {
            // countryId: basicDetails.countryId,
            customerType: basicDetails.customerType,
            pageNum: 1,
            pageSize: '20',
            searchCriteria: {
                ldapIdNbr: basicDetails.ldapIdNbr,
                status: 'All',
                companyName: null,
                salesFeedNumber: null,
                trfTypNm: 'All',
                countryId: 0,
                revenueType: 'A',
                revenueStart: 1,
                revenueEnd: 99999999
            },
            sortCriteria: {
                updateDate: '0',
                effectiveDate: undefined,
                proposalDate: undefined
            }
        };
        return filterObj;
    }

    setPagination(pageObj, updatedPageObj, updateFilter = false, filterObj = null) {
        if (pageObj && updatedPageObj) {
            pageObj.pageIndex = (updatedPageObj.pageIndex + 1);
            pageObj.pageSize = updatedPageObj.pageSize;

            if (updateFilter && filterObj) {
                filterObj.pageSize = '' + updatedPageObj.pageSize;
                filterObj.pageNum = updatedPageObj.pageIndex + 1;
            }
        }
        return updatedPageObj;
    }

    resetPagination(pageObj: any) {
        if (pageObj) {
            pageObj.length = 0;
            pageObj.pageSize = 20;
            pageObj.pageSizeOptions = [10, 20, 50];
            pageObj.pageIndex = 0;
            pageObj.showFirstLastButtons = true;
        }
        return pageObj;
    }

    getTariffTypeColor(type) {
        const color = 'light';
        const badgeType = {
            'Pre Approved': 'primary',
            'Strategic': 'success',
            'Special Request': 'secondary',
            'Fast Track Tariff': 'warning',
            'Band': 'info',
            'NEW': 'info',
            'IN PROG': 'primary',
            'AGREEMENT GENERATED': 'primary',
            'READY FOR IMPLEMENTATION': 'warning',
            'PENDING CONTRACT VALIDATION': 'secondary',
            'IMPLEMENTED': 'success',
            'REJECTED': 'error'
        };
        return (badgeType[type]) ? badgeType[type] : color;
    }

    checkDisabledField(elementType, obj) {
        const elementDecision = {
            'EffectiveDate': (param = null) => {
                if (param && param.STATUS === 'Implemented') {
                    return true;
                }
                return false;
            },
            'disableEdit': (param) => {
                if (param && (this.editAllowed.indexOf(param.STATUS) !== -1)) {
                    return true;
                }
                return false;
            },
            'implementation': (param) => {
                if (param && param.STATUS !== 'Agreement Generated') {
                    return true;
                }
                return false;
            },
            'DownloadTariff': (param) => {
                if (param && (this.downloadAllowed.indexOf(param.salesStatusNm) !== -1)) {
                    return true;
                }
                return false;
            },
            'sm_view': (element) => {
                // if (Utility.roleActions && Utility.roleActions.actions.indexOf('reportes_view') > -1
                //     || Utility.roleActions.actions.indexOf('reassign_sales_feed') > -1) {
                //     return true;
                // }
                return false;
            }
        };
        return (elementDecision[elementType]) ? elementDecision[elementType](obj) : false;
    }
    checkResponse(response, errorMSg) {
        if (response && (response.status === 'EXCEPTION' || response.status === 'VALIDATION_FAILED')) {
            if (response.message) {
                this.commonService.showNotifier(response.message, 'error');
            } else {
                this.commonService.showNotifier(errorMSg, 'error');
            }
            return false;
        }
        return true;
    }
    CheckValidity(element) {
        if (new Date(element.savedOn) <= this.staticCmprDt
            || new Date(element.trfCreationDate) <= this.staticCmprDt) {
            this.commonService.showNotifier(this.errorMessages.errPastDate, 'error');
            return false;
        }
        return true;
    }
    performAction(obj, type, templates, component) {
        const roleName = Utility.roleActions.roleName;
        const userId = Utility.userDetails.userId;
        const actions = {
            'edit': (consolidatedElement) => {
                if (obj.element && obj.element.slsTrfTypNm === 'D') {
                    if (obj.element.savedOn || obj.element.trfCreationDate) {
                        if (!this.CheckValidity(obj.element)) { return; }
                    }
                }
                const element = consolidatedElement.element;
                const isReset = consolidatedElement.isReset;
                if (element.trfTypNm === 'Personalised Tariff'
                    && element.status === 'Submitted'
                    && Utility.roleActions.actions.indexOf('approve_confirm') > -1) {
                    if (isReset) {
                        this.performAction({
                            element: element,
                            otherRequestElement: { ptDetl: { roleName: '' } },
                            toUpdateStatus: 'Solution Design'
                        }, 'statusDrpdwn', templates, component);
                        if (component) {
                            component.navigate(`/create/${element.reference}/true`, null);
                            return;
                        }
                        return;
                    }
                    const url = `/create/${element.reference}`;
                    return { modal: templates.editOrReset, data: { element: element, url: url } };
                } else {
                    if (component) {
                        // component.navigate('/update', element.PROPOSAL_ID);
                        this.router.navigate(['/proposal/update', element.PROPOSAL_ID], {relativeTo: this.activatedRoute});
                        console.log(element.status);
                        return;
                    }
                }
            },
            'DownloadTariff': (element) => {
                if (!this.CheckValidity(element)) { return; }
                if (element.trfTypNm === 'Personalised Tariff') {
                    if (!element.ptfileAvailable) {
                        this.commonService.showNotifier(this.errorMessages.noPTdoc, 'error');
                        return;
                    }
                    let url = '';
                    url = `${Utility.urlParams.downloadPT.url}${element.reference}/PT?&roleNm=${roleName}`;
                    url = `&usrsLdapIdNbr=${userId}
                     &usrsEmalNm=${encodeURIComponent(Utility.userDetails.userEmail)}`;
                    if (element.UI_latest) {
                        url = `&latestFile=true`;
                    } else if (element.UI_isSingleDownload) {
                        url = '';
                        url = `${Utility.urlParams.downloadPTFile.url}${element.reference}/PT?&roleNm=${roleName}`;
                        url = `&usrsLdapIdNbr=${userId}
                         &usrsEmalNm=${encodeURIComponent(Utility.userDetails.userEmail)}`;
                        url = `&id=${element.UI_fileId}`;
                    } else {
                        url = `&latestFile=false`;
                    }

                    window.open(url);
                    if (component && !element.UI_isSingleDownload) {
                        component.closeModal();
                    }
                    return;
                }
                if (element.trfTypNm === 'Fast Track Tariff') {
                    const languages = [];
                    let defaultLanguage: any = null;
                    if (element.countryLangInfos) {
                        const basePdf = Utility.urlParams.generatePDF.url;
                        const baseXL = Utility.urlParams.generateExcel.url;

                        const userEmail = encodeURIComponent(Utility.userDetails.userEmail);
                        const languageMap = {};
                        element.countryLangInfos.map((country) => {
                            let paramUrl = `?salesFeedNbr=${element.reference}&langIdNbr=${country.ctryLangIdNbr}`;
                            paramUrl = `&roleNm=${roleName}&usrsLdapIdNbr=${userId}&usrsEmalNm=${userEmail}`
                            const pdfUrl = `${basePdf}${paramUrl}`;
                            const excelUrl = `${baseXL}${paramUrl}`;
                            const langObj = {
                                langNm: country.langNm, ctryLangIdNbr: country.ctryLangIdNbr,
                                pdfUrl: pdfUrl, excelUrl: excelUrl
                            };
                            if (!defaultLanguage) {
                                defaultLanguage = country.langNm;
                            }
                            languageMap[country.langNm] = langObj;
                            languages.push(langObj);
                        });
                        return {
                            modal: templates.fileTypeDownloadFTT,
                            data: {
                                languages: languages, selectedLanguage: defaultLanguage,
                                languageMap: languageMap, status: element.status,
                                griTariff: element.parentFeed ? element.reference : false
                            }
                        };
                    } else {
                        return {};
                    }
                } else {
                    const selectedRates = { I: [], D: [] };
                    if (element.selectedRates && element.selectedRates.length > 0) {
                        let baseUrl = '';
                        baseUrl = (element.slsTrfTypNm === 'D') ? Utility.urlParams.getBandDownloadTrf.url
                            : Utility.urlParams.genStdTariff.url;
                        baseUrl = `?salesFeedNbr=${element.reference}`;
                        element.selectedRates.map((rate) => {
                            const downloadType = (element.slsTrfTypNm === 'D') ? '&typ=download' : `&type=${rate.type}`;
                            let url = (element.slsTrfTypNm === 'D') ? `${baseUrl}&bandCd=${rate.rtngCtgryCd}${downloadType}`
                                : `${baseUrl}&rtCtgyCd=${rate.rtngCtgryCd}${downloadType}`;
                            url = `&roleNm=${roleName}&usrsLdapIdNbr=${userId}`;
                            selectedRates[rate.type].push({ rtCode: rate.rtngCtgryCd, url: url });
                        });
                        return { modal: templates.fileTypeDownload, data: selectedRates }
                    } else {
                        this.commonService.showNotifier(this.errorMessages.noDoc, 'error');
                        return;
                    }
                }
            },


            'openAuditLog': (consolidatedElement) => {
                const element = consolidatedElement;
                const url = Utility.urlParams.auditDetails.url;
                const request = {
                    'type': 'GET',
                    'salesIdNbr': element.reference
                }
                if (component) {
                    component.openModal(templates.auditLog, {
                        salesFeedId: element.reference
                    });
                }
                
                // this.commonService.getAPIResponse(url, request, Utility.urlParams.auditDetails.type)
                //     .subscribe((response: any) => {
                //         if (!this.checkResponse(response, 'Error occurred while getting Info.')) {
                //             return;
                //         }
                //         response.forEach(ele => {
                //             if (ele.roleName === 'FTT_PRICING_EUROPE') {
                //                 ele.roleName = 'Pricing Europe';
                //             }
                //         });
                //         if (component && response) {
                //             component.openModal(templates.auditLog, {
                //                 auditInfo: response, pageSize: 5, pageIndex: 0,
                //                 filterData: JSON.parse(JSON.stringify(response)),
                //                 salesFeedId: element.reference
                //             });
                //         }
                //     }, (error) => {
                //         console.log(error);
                //         this.commonService.showNotifier('Error occurred while getting Info.', 'error');
                //     });

                // const getComments = Utility.urlParams.commentDetails.url;
                // this.commonService.getAPIResponse(getComments, request, Utility.urlParams.commentDetails.type)
                //     .subscribe((response: any) => {
                //         let salesComments = '';
                //         let pricingComments = '';
                //         if (response) {
                //             response = response.sort((a, b) => {
                //                 const sortOrder = 0, property = 'commentDate',
                //                     prev = new Date(a[property]).getTime(),
                //                     next = new Date(b[property]).getTime();
                //                 const result = (prev < next) ? -1 : (prev > next) ? 1 : 0;
                //                 return result * sortOrder;
                //             });
                //             let sales = false; let pricing = false;
                //             response.map(commentsObj => {
                //                 if (commentsObj && commentsObj.comments) {
                //                     if (commentsObj.commentsTypNm === 'SC' && !sales) {
                //                         salesComments = commentsObj.comments;
                //                         sales = true;
                //                     } else if (commentsObj.commentsTypNm === 'PC' && !pricing) {
                //                         pricingComments = commentsObj.comments;
                //                         pricing = true;
                //                     }
                //                 }
                //             });
                //             component.salesComments = salesComments.length > 0 ? salesComments : '';
                //             component.pricingComments = pricingComments.length > 0 ? pricingComments : '';
                //             return;
                //         }
                //     });
            }
        };
        return (actions[type]) ? actions[type](obj) : null;
    }

}
