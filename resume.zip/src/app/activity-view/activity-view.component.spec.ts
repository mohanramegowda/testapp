import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ComponentsModule } from 'app/components/components.module';
import { CommonService } from 'app/common/common.service';
import { HttpClientModule } from '@angular/common/http';
import { RouterModule, ActivatedRoute, Params } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { Subject } from 'rxjs';
import { ActivityViewComponent } from './activity-view.component';
import { ActivityViewRoutingModule } from './activity-view.routing.module';
import { ActivityViewService } from './activity-view-service';
import { PendingInterceptorModule } from 'app/components/loading-indicator/pending-interceptor.module';
import { TranslateService } from '@ngx-translate/core';
import { TranslateServiceStub } from 'app/common/stubs/translate.stub';

xdescribe('AcivityViewComponent', () => {
    let component: ActivityViewComponent;
    let fixture: ComponentFixture<ActivityViewComponent>;
    // tslint:disable-next-line: prefer-const
    let params: Subject<Params>;
    const methods: any = {
        populateDynamicEventsMethod: null,
    }

    beforeEach(async(() => {
        params = new Subject<Params>();
        TestBed.configureTestingModule({
            imports: [
                BrowserAnimationsModule,
                HttpClientModule,
                RouterTestingModule,
                CommonModule,
                FormsModule,
                ReactiveFormsModule,
                ActivityViewRoutingModule,
                ComponentsModule,
                PendingInterceptorModule
            ],
            declarations: [
                ActivityViewComponent,
            ],
            providers: [
                CommonService,
                ActivityViewService,
                { provide: ActivatedRoute, useValue: { params: params } },
                { provide: TranslateService, useClass: TranslateServiceStub }
            ],
        })
            .compileComponents();
    }), 30000);

    beforeEach(() => {
        fixture = TestBed.createComponent(ActivityViewComponent);
        component = fixture.componentInstance;
        fixture.detectChanges();
        // params.next({ 'profileConfig': 'PRC' });
        // methods.populateDynamicEventsMethod = spyOn(component, 'populateDynamicEvents');
        // methods.processTableHeaders = spyOn(component, 'processTableHeaders');
    });

    it('should create', () => {
        expect(component).toBeTruthy();
    });

    //   it('should populate have screen Config', () => {
    //     expect(component.title).toBeTruthy();
    //   });

    //   it('should populate have screen Config', () => {
    //     expect(component.subTitle).toBeTruthy();
    //   });

    //   it('should populate have screen Config', () => {
    //     component.populateDynamicEvents();
    //     expect(methods.populateDynamicEventsMethod).toHaveBeenCalled();
    //   });

    //   it('should call Process Table Headers', () => {
    //     component.processTableHeaders(null);
    //     expect(methods.processTableHeaders).toHaveBeenCalled();
    //   });

    //   it('should contain resultSubscription', () => {
    //     expect(component.resultSubscription).toBeTruthy();
    //   });

    //   it('should contain resultSubscription', () => {
    //     expect(component.resultSubscription).toBeTruthy();
    //   });
});
