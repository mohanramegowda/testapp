import { Component, OnInit, Input, ViewChild, OnDestroy, ContentChild, ViewContainerRef, ElementRef } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { filter } from 'rxjs/operators';
import {
    MatDialog, MatPaginator, MatSort, MatTableDataSource,
    DateAdapter, MAT_DATE_FORMATS, MatChipInputEvent, MatAutocompleteSelectedEvent
} from '@angular/material';
// import { MomentDateAdapter } from '@angular/material-moment-adapter';
import { CommonService } from '../common/common.service';
import { Utility } from '../common/Utility';
import { ActivityViewService } from './activity-view-service';
import { AppDateAdapter, MOMENT_DATE_FORMATS, APP_DATE_FORMATS } from 'app/common/customDatePicker';
import { FormControl } from '@angular/forms';
import { PendingInterceptorService } from 'app/components/loading-indicator/pending-interceptor.service';
import { PagerService } from './pager-service';

declare interface SortCriteria {
    updateDate: string;
    effectiveDate: string;
    proposalDate: string;
}

declare interface SearchCriteria {
    status: string;
    referenceOrCompanyName: string;
    salesFeedNumber: number;
    trfTypNm: string;
    countryId: number;
    revenueType: string;
    revenueEnd: number;
    revenueStart: number;
    ldapList?: number[];
    ldapIdNbr: string;
}

declare interface FilterInfo {
    countryId: number;
    customerType: string;
    ldapIdNbr: string;
    pageNum: number;
    pageSize: string;
    searchCriteria: SearchCriteria;
    sortCriteria: SortCriteria;
}

declare interface Pagination {
    length: number;
    pageSize: number;
    pageSizeOptions: number[];
    pageIndex: number;
    showFirstLastButtons: boolean;
}

@Component({
    selector: 'app-activity-view',
    templateUrl: './activity-view.component.html',
    styleUrls: ['./activity-view.component.scss'],
    providers: [
        {
            provide: MAT_DATE_FORMATS, useValue: MOMENT_DATE_FORMATS
        }]
})

export class ActivityViewComponent implements OnInit {

    @ViewChild(MatPaginator, { static: false }) paginator: MatPaginator;

    @ViewChild('fileTypeDownload', { static: false })
    fileTypeDownload: ViewContainerRef;

    @ViewChild('tariffHistInfo', { static: false })
    tariffHistInfo: ViewContainerRef;

    @ViewChild('editOrReset', { static: false })
    editOrReset: ViewContainerRef;

    @ViewChild('auditLog', { static: false })
    auditLog: ViewContainerRef;

    @ViewChild('fileupload', { static: false })
    fileupload: ViewContainerRef;

    filter: FilterInfo;
    tariffStatuses: any = [];
    tariffTypes: any = [];
    opCountries: any = [];
    paginationObj: Pagination;
    proposals: any = [];
    tariffStatusMap: any = {};
    getTariffTypeColor: any;
    dialogRef: any;
    dialogData: any;
    component: any;
    resetpagination: any;
    consolidatedResponse: any;
    serviceResponse: any;
    commentsList: any = [];
    uploadedFiles: any = [];
    documentTypes: any = [];
    documentDesc = '';
    documentType = '';
    pKey = '';

    sortSteps = {
        effectiveDate: { displayName: 'Effective Date', value: '0' },
        proposalDate: { displayName: 'Proposal Date', name: '', value: '0' },
    };
    sortName = 'effectiveDate';
    pager: any = {};


    constructor(private commonService: CommonService, private route: ActivatedRoute,
        private dialog: MatDialog, private activityService: ActivityViewService,
        private router: Router, private pendingInterceptorService: PendingInterceptorService,
        private paginatorService: PagerService) {
        this.resetFilters();
        this.pendingInterceptorService.setPendingRequest();
        this.route.params.subscribe(params => {
            if (params && params.salesFeedNumber) {
                this.filter.searchCriteria.salesFeedNumber = params.salesFeedNumber;
                this.filter.searchCriteria.referenceOrCompanyName = params.salesFeedNumber;
                this.pKey = params.salesFeedNumber;
                if (params.countryId
                    && Utility.countryAccessMap[Utility.countryIdCodeMap[params.countryId]]) {
                    this.filter.searchCriteria.countryId = parseInt(params.countryId, 0);
                } else {
                    this.filter.searchCriteria.salesFeedNumber = undefined;
                    this.filter.searchCriteria.referenceOrCompanyName = undefined;
                    this.commonService.showNotifier('You have no access to this sales feed', 'error');
                }
                this.activate();

            } else {

                this.resetpagination = this.activityService.resetPagination;
                this.paginationObj = this.activityService.resetPagination({});
                this.getTariffTypeColor = this.activityService.getTariffTypeColor;
                this.component = this;

                this.activate();
            }
        });

        this.resetpagination = this.activityService.resetPagination;
        this.paginationObj = this.activityService.resetPagination({});
        this.getTariffTypeColor = this.activityService.getTariffTypeColor;
        this.component = this;
    }
    ngOnInit() {
    }

    activate() {
        const reqArr = this.activityService.generateInitSearch();
        this.commonService.getGenericForkJoin(reqArr).subscribe(responseList => {
            let opCountryResponse = [];

            if (Utility.countryIdMap) {
                for (const i in Utility.countryAccessMap) {
                    if (Utility.countryAccessMap[i]) {
                        opCountryResponse.push({ CTRY_NM: Utility.countryAccessMap[i], CTRY_ID_NBR: Utility.countryIdMap[i] });
                    }
                }
            }
            // this.tariffTypes = [{ tariff: 'All', tariffTypeId: 0 }].concat(tariffResponse);
            if (opCountryResponse.length !== 1) {
                this.opCountries = JSON.parse(JSON.stringify(opCountryResponse));
                this.opCountries.sort((a, b) => a.CTRY_NM.localeCompare(b.CTRY_NM));
                this.opCountries = [{ CTRY_NM: 'All', CTRY_ID_NBR: 0 }].concat(this.opCountries);
            } else {
                this.opCountries = [{ CTRY_NM: opCountryResponse[0].CTRY_NM, CTRY_ID_NBR: opCountryResponse[0].CTRY_ID_NBR }];
                this.filter.searchCriteria.countryId = opCountryResponse[0].CTRY_ID_NBR;
            }
            this.tariffTypes.map((tariff) => {
                if (tariff.stsLst) {
                    this.tariffStatusMap[tariff.tariff] = tariff.stsLst.sort((a: any, b: any) => a.salesStatusId - b.salesStatusId);
                }
            });
            const statusesResponse: any = responseList[0];
            let statusArr = [];
            statusArr = statusesResponse.map(({ STAT_CD, STAT_NM }) => {
                return { statusId: STAT_CD, statusName: STAT_NM }
            });
            this.tariffStatuses = [{ statusName: 'All', statusId: 0 }].concat(statusArr);
            this.filterData();
        }, (error) => {
            console.log('Error');
            console.log(error);
        });

    }

    filterData() {
        const request = this.activityService.processRequestFilter(JSON.parse(JSON.stringify(this.filter)));
        const url = Utility.urlParams.activityViewList.url;
        const type = Utility.urlParams.activityViewList.type;
        // TODO Remove the below code. Not required once we get the actual services
        request.type = 'ALL';
        this.commonService.getAPIResponse(url, request, type).subscribe((response: any) => {
            if (response && response.status === 'EXCEPTION') {
                this.proposals = null;
                if (response.message) {
                    if (response.message.indexOf('No records found for criteria') > -1) {
                        this.commonService.showNotifier('No records found ', 'error');
                    } else {
                        this.commonService.showNotifier(response.message, 'error');
                    }
                } else {
                    this.commonService.showNotifier('Error occurred while getting data.', 'error');
                }
                return;
            }
            this.paginationObj.length = response.length;
            this.paginationObj.pageIndex = 0;
            // this.paginationObj.pageIndex = (response.currentPage === 0) ? response.currentPage : (response.currentPage - 1);
            // this.paginationObj.pageSize = response.totalRecordsInCrtPage;
            this.serviceResponse = JSON.parse(JSON.stringify(response));
            this.consolidatedResponse = response;
            this.onPage(this.paginationObj, false);
        });
    }

    resetPaginationAndFilter() {
        const value = {
            length: 0,
            pageIndex: 0,
            pageSize: 20,
            previousPageIndex: 0
        };
        this.activityService.setPagination(this.activityService.resetPagination(this.paginationObj),
            value, true, this.filter);
        this.filterSearch();
        // this.filterData();
    }

    filterSearch() {
        const toBeFiltered = JSON.parse(JSON.stringify(this.serviceResponse));
        const filtered = [];
        toBeFiltered.map((tariff) => {
            let canPush = true;
            if (this.filter.searchCriteria.referenceOrCompanyName) {
                if (this.filter.searchCriteria.referenceOrCompanyName === `${tariff.PROPOSAL_ID}`
                    || this.filter.searchCriteria.referenceOrCompanyName === tariff.COMPANY_NAME) {
                    canPush = true;
                } else {
                    canPush = false;
                }
            }
            if (this.filter.searchCriteria.status && this.filter.searchCriteria.status !== 'All' && canPush) {
                if (this.filter.searchCriteria.status === tariff.STATUS) {
                    canPush = true;
                } else {
                    canPush = false;
                }
            }
            if (canPush) {
                filtered.push(tariff);
            }
        });
        this.consolidatedResponse = filtered;
        this.onPage(this.paginationObj, false);
    }

    resetFilters(filterAfterReset = false) {
        this.filter = this.activityService.resetFilters(filter);
        if (filterAfterReset) {
            this.filterData();
        }
    }

    onFilterChange(value, type, filterOnChange = false) {
        if (!this.commonService.checkNullOrUndefined(value) && this.activityService.searchSortConfig[type]) {
            const obj = this.activityService.searchSortConfig[type](value, this.filter);
            this.filter = obj;
            if (filterOnChange) {
                this.filterData();
            }
        } else {
            this.commonService.showNotifier('No Filter Config found', 'error');
        }
    }

    onPage(value, setPagination = true) {
        if (setPagination) {
            this.activityService.setPagination(this.paginationObj, value, true, this.filter);
        }
        if (this.filter && this.filter.sortCriteria.effectiveDate) {
            this.consolidatedResponse.sort((a, b) => (a.EFFECTIVE_DATE > b.EFFECTIVE_DATE) ? 1
                : ((b.EFFECTIVE_DATE > a.EFFECTIVE_DATE) ? -1 : 0));
        }
        if (this.filter && this.filter.sortCriteria.proposalDate) {
            this.consolidatedResponse.sort((a, b) => (a.PROPOSAL_DATE > b.PROPOSAL_DATE) ? 1
                : ((b.PROPOSAL_DATE > a.PROPOSAL_DATE) ? -1 : 0));
        }
        // get pager object from service
        this.pager = this.paginatorService.getPager(this.consolidatedResponse.length, (this.paginationObj.pageIndex + 1),
            this.paginationObj.pageSize);

        // get current page of items
        this.proposals = this.consolidatedResponse.slice(this.pager.startIndex, this.pager.endIndex + 1);
        // this.filterData();
    }

    gridChangeFormat(date) {
        return this.commonService.formatDateTime(new Date(date), 'DD/MM/YYYY');
    }

    openModal(templateRef, data = null) {
        this.dialogData = data;
        this.dialogRef = this.dialog.open(templateRef, {});
        this.dialogRef.afterClosed().subscribe(result => {
            this.dialogData = null;
        });
    }

    closeModal() {
        try {
            this.dialogRef.close(null);
        } catch (e) {
            // Intentionally do nothing
        }
    }

    navigate(path, param) {
        if (param) {
            this.router.navigate([path, param]);
        } else {
            this.router.navigate([path]);
        }
    }

    onSliderChange(event) {
        this.filter.searchCriteria.revenueStart = event[0];
        this.filter.searchCriteria.revenueEnd = event[1];
    }

    getCountryName(countryName: string): string {
        return Utility.countryCodeNameMap[countryName];
    }

    performAction(element, type) {
        const templates = {
            fileTypeDownload: this.fileTypeDownload,
            editOrReset: this.editOrReset,
            auditLog: this.auditLog,
        }
        if ( type === 'openAuditLog') {
            const reqArr = [];
            reqArr.push({
                url: Utility.urlParams.getDocumentTypes.url,
                param: { type: 'ALL'},
                type: Utility.urlParams.getDocumentTypes.type
            });
            reqArr.push({
                url: Utility.urlParams.getComments.url,
                param: { prpsId: element.PROPOSAL_ID },
                type: Utility.urlParams.getComments.type
            });
            reqArr.push({
                url: Utility.urlParams.getAllFiles.url,
                param: { prpsId: element.PROPOSAL_ID },
                type: Utility.urlParams.getAllFiles.type
            });
            this.commonService.getGenericForkJoin(reqArr).subscribe((responses: any) => {
                if (responses) {
                    if (responses[0]) {
                        this.documentTypes = responses[0];
                    }
                    if (responses[1]) {
                        this.commentsList = responses[1].data;
                    }
                    if (responses[2]) {
                        this.uploadedFiles = responses[2].data;
                    }
                }
            }, (error) => {

            });
        }

        const response = this.activityService.performAction(element, type, templates, this.component);
        if (response && response.modal) {
            this.openModal(response.modal, response.data);
        }
    }

    checkDisabledField(elementType, obj) {
        return this.activityService.checkDisabledField(elementType, obj);
    }

    addComment(event) {
        const request = {
            prpsId: this.pKey,
            comment: event,
            userId: Utility.userDetails.userId
        }
        // WORST PART. API to be changed to handle JSON
        const str = `${Utility.urlParams.addComments.url}?prpsId=${request.prpsId}&comment=${request.comment}&userId=${request.userId}`;
        this.commonService.getAPIResponse(str, request,
            Utility.urlParams.getDocumentTypes.type).subscribe((response: any) => {
                if (response && response.data && response.data.length > 0) {
                    if (!this.commentsList) {
                        this.commentsList = [];
                    }
                    this.commentsList.push(response.data[response.data.length - 1]);
                    this.commonService.showNotifier('Comment Added Successfully', 'success');
                }
            });
    }

    removeComment(commentData) {
        this.commonService.getAPIResponse(Utility.urlParams.deleteComment.url, {
            prpsId: this.pKey,
            commentId: commentData.comment.commentId
        }, Utility.urlParams.deleteComment.type).subscribe((response: any) => {
            this.commentsList.splice(commentData.index, 1);
            this.commonService.showNotifier('Comment Deleted Successfully', 'success');
        });

    }

    onUpload() {
        const formData = new FormData();
        this.openModal(this.fileupload, { ptFiles: formData });
    }

    uploadfiles(val = null) {
        // this.dialogRef.close(val);
        const files: FileList = val.filesList;
        if (!files || (files && files.length <= 0)) {
            this.commonService.showNotifier('Please select file to upload', 'error')
            return;
        }
        if (!this.documentType || (this.documentType && this.documentType.length <= 0)) {
            this.commonService.showNotifier('Please select a document type', 'error')
            return;
        }
        const formData = new FormData();
        for (let i = 0; i < files.length; i += 1) {
            formData.append('fileUpload', files[i]);
            formData.append('prpsId', this.pKey);
            formData.append('userId', Utility.userDetails.userId);
            formData.append('documentType', this.documentType);
            formData.append('description', this.documentDesc)
        }

        this.commonService.getAPIResponse(Utility.urlParams.uploadDocument.url, formData,
            Utility.urlParams.uploadDocument.type).subscribe((response: any) => {
                this.commonService.showNotifier('Document Uploaded Successfully', 'success');
                this.uploadedFiles.push(response.data);
                this.documentDesc = '';
                this.documentType = '';
            });
    }

    downloadFile(val = null) {
        if (val) {
            window.open(`${Utility.urlParams.downloadDocument.url}/${this.pKey}/${val}`);
        }
    }

    removeFile(event) {
        console.log(event);
    }
}
