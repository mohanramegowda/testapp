const http = require('http');
const fs = require('fs');
const microFrontendMap = {
  customer: 'http://localhost:5001/main.js',
};

for (const i in microFrontendMap) {
  const file = fs.createWriteStream(`./src/app/third-party/${i}.js`);
  const request = http.get(microFrontendMap[i], function (response) {
    response.pipe(file);
  });
}



// 1) Download Micro Frontends
// 2) Inject them to Component
// 3) Recompile the same


// Sync File Download
// ng serve / ng build